
                

select xmlelement(name "QueryResult",
     xmlattributes(
      '34' as "order",
      'Statistics' as "name",
      'Time Slices' as "description",
      'Name' as "th1",
      'Count' as "th2"),
     xmlagg(xmlelement(name "Record", xmlforest("name", "count"))))
       .getclobval()
from (



select 'Slice ' || r.request_name as "name",
       (select count(*) from prj_blb_slices s where s.slice_request_id = r.id) as "count"
  from prj_blb_slicerequests r
 where r.table_name = 'PRJ_BLB_SLICES'

 ) t         


              