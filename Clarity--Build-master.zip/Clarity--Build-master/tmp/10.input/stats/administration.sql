
                
with install as
 (select min(installed_date) + 1 as installed_date
    from cmn_install_history
   where install_id in ('database', 'release_version')),
     install_csk as
 (select h.installed_date - 1 as min,
         h.installed_date as installed_date,
         h.installed_date + 1 as max
    from cmn_install_history h
   where h.install_id in ('contentPack::csk', 'csk'))


select xmlelement(name "QueryResult",
      xmlattributes(
        '32' as "order",
        'Statistics' as "name",
        'Administration Objects by navigation' as "description",
        'URI' as "th1",
        'Object' as "th2",
        'Count' as "th3"),
      xmlagg(xmlelement(name "Record", xmlforest("uri", "object", "count"))))
       .getclobval()
from (



--Organization and Access
select 'Organization and Access > Resources' as "uri",
       'User' as "object",
       count(*) as "count"
  from cmn_sec_users
 where last_updated_date >= (select installed_date from install)
union all
select 'Organization and Access > Groups',
       'Group',
       count(*)
  from cmn_sec_groups
 where group_role_type = 'GROUP'
   and last_updated_date >= (select installed_date from install)
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1)
union all
select 'Organization and Access > OBS',
       'OBS',
       count(*)
  from prj_obs_types

--Studio
union all
select 'Studio > Partition Models',
       'Partition',
       count(*)
  from cmn_partition_models
union all
select 'Studio > Objects',
       'Object',
       count(*)
  from odf_objects o
 where (o.is_custom = 1
    or (o.is_customizable = 1 and
       ((o.last_updated_date >= (select installed_date from install) or
       (select max(a.last_updated_date) from odf_custom_attributes a where a.object_name = o.code) >=
       (select installed_date from install)))))
    and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1)
union all
select 'Studio > Queries',
       'Query',
       count(*)
  from cmn_nsql_queries
 where last_updated_date >= (select installed_date from install)
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1)
union all
select 'Studio > Portlets',
       'Portlet',
       count(*)
  from cmn_portlets p
 where not p.principal_type = 'USER'
   and nvl(p.is_system, 0) = 0
   and (p.last_updated_date >= (select installed_date from install) or
       (select max(c.last_updated_date)
           from cmn_grid_cols c,
                cmn_grids     g
          where c.grid_id = g.id
            and g.portlet_id = p.id) >= (select installed_date from install))
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1)
union all
select 'Studio > Portlet Pages',
       'Page',
       count(*)
  from cmn_pages p
 where not p.principal_type = 'USER'
   and p.is_system = 0
   and p.page_type_code != 'template'
   and substr(lower(p.page_code), 1, 6) != 'system'
   and p.last_updated_date >= (select installed_date from install)
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1)
union all
select 'Studio > UI Themes',
       'UI Theme',
       count(*)
  from cmn_ui_themes
union all
select 'Studio > Views',
       'View',
       count(*)
  from odf_views
 where last_updated_date >= (select installed_date from install)

--Data Administration
union all
select 'Data Administration > Datamart Settings',
       'Datamart Setting',
      (select count(*) from (
      select 1 as tmp
        from cmn_options       op,
             cmn_option_values ov
       where ov.option_id = op.id
         and op.option_code in
             ('NBI_CURRENCY_CODE', 'NBI_ENTITY_CODE', 'NBI_EXTRACT_PM_PTFS', 'NBI_EXTRACT_FM_PTFS', 'NBI_EXTRACT_RTFS')
         and not ((op.option_code = 'NBI_CURRENCY_CODE' and ov.value is null) or
              (op.option_code = 'NBI_ENTITY_CODE' and ov.value is null) or
              (op.option_code = 'NBI_EXTRACT_PM_PTFS' and ov.value = 1) or
              (op.option_code = 'NBI_EXTRACT_FM_PTFS' and ov.value = 1) or
              (op.option_code = 'NBI_EXTRACT_RTFS' and ov.value = 1))
      union all
      select 1
        from nbi_cfg_obs_assignments c
       where c.object_type = 'PROJECT'
         and not (c.obs_type_id is null)
      union all
      select 1
        from nbi_cfg_obs_assignments c
       where c.object_type = 'RESOURCE'
         and not (c.obs_type_id is null)
      ) t)
from dual
union all
select 'Data Administration > Datamart Stoplights',
       'Datamart Stoplight',
       count(*)
  from nbi_cfg_stoplight_queries s
 where s.redsql is not null
union all
select 'Data Administration > Time Slices',
       'Time Slices',
       count(*)
  from prj_blb_slicerequests s
 where is_system = 0
   and is_template = 0
   and is_active = 1
   and last_updated_date >= (select installed_date from install)
union all
select 'Data Administration > Lookups',
       'Lookup',
       count(*)
  from cmn_lookup_types l
 where l.is_system = 0
   and lower(l.source) = 'customer'
   and (l.last_updated_date >= (select installed_date from install) or
       (select max(v.last_updated_date) from cmn_lookups v where v.lookup_type = l.lookup_type) >=
       (select installed_date from install))
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1)      
union all
select 'Data Administration > Incidents',
       'Incident Category',
       count(*)
  from imm_categories
union all
select 'Data Administration > Reports and Jobs',
       'Job',
       count(*)
  from cmn_sch_job_definitions
 where last_updated_date >= (select installed_date from install)
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1) 
union all
select 'Data Administration > Skills Hierarchy',
       'Skill',
       count(*)
  from rsm_skills
union all
select 'Data Administration > Processes',
       'Process',
       count(*)
  from bpm_def_processes p
 where (p.last_updated_date >= (select installed_date from install)
    or (select max(v.last_updated_date) from bpm_def_process_versions v where v.process_id = p.id) >=
       (select installed_date from install)
    or (select max(stage.last_updated_date)
          from bpm_def_process_versions v,
               bpm_def_stages           stage
         where stage.process_version_id = v.id
           and v.process_id = p.id) >= (select installed_date from install)
    or (select max(step.last_updated_date)
          from bpm_def_process_versions v,
               bpm_def_stages           stage,
               bpm_def_steps            step
         where stage.process_version_id = v.id
           and step.stage_id = stage.id
           and v.process_id = p.id) >= (select installed_date from install)
    or (select max(pa.last_updated_date)
          from bpm_def_process_versions v,
               bpm_def_stages           stage,
               bpm_def_steps            step,
               bpm_def_step_actions     pa
         where stage.process_version_id = v.id
           and step.stage_id = stage.id
           and pa.step_id = step.id
           and v.process_id = p.id) >= (select installed_date from install)
    or (select max(s.last_updated_date)
          from bpm_def_process_versions v,
               bpm_def_stages           stage,
               bpm_def_steps            step,
               bpm_def_step_actions     pa,
               cmn_custom_scripts       s
         where stage.process_version_id = v.id
           and step.stage_id = stage.id
           and pa.step_id = step.id
           and s.id = pa.script_id
           and v.process_id = p.id) >= (select installed_date from install))
   and not (exists (select 1 from install_csk where last_updated_date between min and max) and last_updated_by = 1) 
union all
select 'Data Administration > Audit Trail',
       'Audit Trail',
       count(*)
  from cmn_audits
union all
select 'Data Administration > Process Engines',
       'Process Engine',
       count(*)
  from bpm_run_process_engines
 
 --Finance
union all
select 'Finance > Processing',
       'Processing',
       (select count(*) from (
        select 1 as tmp
          from cmn_options       op,
               cmn_option_values ov
         where ov.option_id = op.id
           and op.option_code = 'CMN_RETAIN_CURRENCY_PRECISION'
           and not ov.value = '1'
        union all
        select 1
          from cmn_options       op,
               cmn_option_values ov
         where ov.option_id = op.id
           and op.option_code = 'CMN_IS_MULTI_CURRENCY_SYSTEM'
           and not ov.value = '0'
        union all
        select 1
          from nameoptions o
         where not o.allownonchargeableoverride = 1
        union all
        select 1
          from nameoptions o
         where not o.filter_financial_obs = 0
        union all
        select 1
          from nameoptions o
         where not o.entity_security = 0) t)
from dual
--Finance > WIP Settings TODO
--Finance > Setup [Defaults] TODO
union all
select 'Finance > Setup',
       'Entity',
       count(*)
  from entity
union all
select 'Finance > Setup',
       'Location',
       count(*)
  from locations
union all
select 'Finance > Setup',
       'Vendor',
       count(*)
  from apmaster
union all
select 'Finance > Setup',
       'Currency',
       count(*)
  from cmn_currencies
 where is_active = 1
union all
select 'Finance > Setup',
       'Foreign Exchange Rate',
       count(*)
  from cmn_exchange_rates
union all
select 'Finance > Setup',
       'Resource Class',
       count(*)
  from pac_fos_resource_class
union all
select 'Finance > Setup',
       'Company Class',
       count(*)
  from clntclass
union all
select 'Finance > Setup',
       'WIP Class',
       count(*)
  from wipclass
union all
select 'Finance > Setup',
       'Investment Class',
       count(*)
  from projclass
union all
select 'Finance > Setup',
       'Transaction Class',
       count(*)
  from transclass
 where id > 12
union all
select 'Finance > Cost Plus Codes',
       'Cost Plus Code',
       count(*)
  from costplus
union all
select 'Finance > Manage Matrix',
       'Matrix',
       count(*)
  from ppa_matrix
 where not matrixkey = 1
union all
select 'Finance > GL Accounts',
       'GL Account',
       count(*)
  from cbk_gl_account

--Chargebacks
union all
select 'Chargebacks > Standard Rules',
       'Standard Rule',
       count(*)
  from cbk_gl_allocation r
 where r.chargeback_type = 'DEBIT'
   and r.chargeback_subtype = 'STANDARD'
union all
select 'Chargebacks > Overhead Rules',
       'Overhead Rule',
       count(*)
  from cbk_gl_allocation r
 where r.chargeback_type = 'DEBIT'
   and r.chargeback_subtype = 'OVERHEAD'
union all
select 'Chargebacks > Credit Rules',
       'Credit Rule',
       count(*)
  from cbk_gl_allocation r
 where r.chargeback_type = 'CREDIT'
union all
select 'Chargebacks > Messages',
       'Message',
       count(*)
  from cbk_errors

--Project Management > Timesheet Options TODO
--Project Management
union all
select 'Project Management > Time Reporting Periods',
       'Time Reporting Period',
       count(*)
  from prtimeperiod
union all
select 'Project Management > Charge Codes',
       'Charge Code',
       count(*)
  from prchargecode
union all
select 'Project Management > Input Type Codes',
       'Input Type Code',
       count(*)
  from prtypecode
union all
select 'Project Management > Invalid Transactions',
       'Invalid Transaction',
       count(*)
  from imp_transactionimport
 where importstatus = 'E'
 --Project Management > Settings TODO
union all
select 'Project Management > Base Calendars',
       'Calendar',
       count(*)
  from prcalendar
 where prresourceid is null

--Project Management > Migrate Methods TODO
--Project Management > Risk Settings TODO
--Project Management > MSP Field Mappings TODO
--General Settings > System Options TODO

--General Settings
union all
select 'General Settings > Site Links',
       'Site Link',
       count(*)
  from prlink
 where prtablename = 'PRSite'

--Earned Value Management
union all
select 'Earned Value Management > Period Definitions',
       'EV Period',
       count(*)
  from evm_period_defs
 
 ) t
         


              