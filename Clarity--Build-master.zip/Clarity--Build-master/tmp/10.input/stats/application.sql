
                

with version as
 (select to_number(substr(replace(version, '.', ''), 1, 3)) as version
    from (select h.installed_version as version
            from cmn_install_history h
           where h.install_id in ('contentPack::clarityContent', 'database')
           order by h.installed_date desc)
   where rownum = 1)
select xmlelement(name "QueryResult",
      xmlattributes(
      '31' as "order",
      'Statistics' as "name",
      'Application Objects by navigation' as "description",
      'URI' as "th1",
      'Object' as "th2",
      'Count' as "th3"),
      xmlagg(xmlelement(name "Record", xmlforest("uri", "object", "count"))))
       .getclobval()
from (



--Personal
select 'Personal > Organizer' as "uri",
       'Action' as "object",
       count(*) as "count"
  from cal_action_items
union all
select 'Personal > Organizer',
       'Task',
       count(*)
  from prtask
union all
select 'Personal > Organizer',
       'Process',
       count(*)
  from bpm_run_processes
union all
select 'Personal > Organizer',
       'Notification',
       count(*)
  from clb_notifications
union all
select 'Personal > Dashboards',
       'Dashboard',
       count(*)
  from cmn_pages
 where principal_type = 'USER'
   and source = 'customer'
   and page_type_code = 'page'
union all
select 'Personal > Portlets',
       'Portlet',
       count(*)
  from cmn_portlets
 where principal_type = 'USER'
   and source = 'customer'
union all
select 'Personal > Timesheets',
       'Timesheet',
       count(*)
  from prtimesheet
union all
select 'Personal > Reports and Jobs',
       'Job',
       count(*)
  from cmn_sch_jobs

--Organization
union all
select 'Organization > Departments',
       'Department',
       count(*)
  from departments
union all
select 'Organization > Knowledge Store',
       'File',
       count(*)
  from clb_dms_files

--IT Service Management
union all
select 'IT Service Management > Services',
       'Service',
       count(*)
  from inv_services

--Portfolio Management

union all
select 'Portfolio Management > Portfolios',
       'Portfolio',
       (select num_rows
          from user_tables
         where table_name = (case
                 when version < 132 then
                  'PMA_PORTFOLIOS'
                 else
                  'PFM_PORTFOLIOS'
               end))
  from version


union all
select 'Portfolio Management > Programs',
       'Program',
       count(*)
  from srm_projects p
 where p.is_program = 1
union all
select 'Portfolio Management > Projects',
       'Project',
       count(*)
  from srm_projects p
 where p.is_program = 0
union all
select 'Portfolio Management > Applications',
       'Application',
       count(*)
  from inv_applications
union all
select 'Portfolio Management > Assets',
       'Asset',
       count(*)
  from inv_assets 
union all
select 'Portfolio Management > Products',
       'Product',
       count(*)
  from inv_products 
union all
select 'Portfolio Management > Other Work',
       'Other Work',
       count(*)
  from inv_others
union all
select 'Portfolio Management',
       'Cost Plan',
       count(*)
  from fin_plans p
 where p.plan_type_code = 'FORECAST'
union all
select 'Portfolio Management',
       'Benefit Plan',
       count(*)
  from fin_plans p
 where p.plan_type_code is null
union all
select 'Portfolio Management',
       'Budget Plan',
       count(*)
  from fin_plans p
 where p.plan_type_code = 'BUDGET'
union all
select 'Portfolio Management',
       'Scenario',
       count(*)
  from cap_scenarios

--Requirements Planning
union all
select 'Requirements Planning > Release Planning',
       'Release Planning',
       count(*)
  from rqp_release_plans 
union all
select 'Requirements Planning > Releases',
       'Release',
       count(*)
  from rqp_releases 
union all
select 'Requirements Planning',
       'Requirements',
       count(*)
  from rqp_requirements

--Demand Management
union all
select 'Demand Management > Ideas',
       'Idea',
       count(*)
  from inv_ideas
union all
select 'Demand Management > Incidents',
       'Incident',
       count(*)
  from imm_incidents

--Resource Management
union all
select 'Resource Management > Resources',
       'Resource',
       count(*)
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 0
union all
select 'Resource Management > Resources',
       'Role',
       count(*)
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 1
union all
select 'Resource Management > Resource Requisitions',
       'Requisition',
       count(*)
  from rsm_req_requisitions

--Financial Management
union all
select 'Financial Management > Transactions',
       'Transaction',
       count(*)
  from ppa_wip
union all
select 'Financial Management > Invoices',
       'Invoices',
       count(*)
  from cbk_invoice
union all
select 'Financial Management > Companies',
       'Companies',
       count(*)
  from srm_companies

 ) t
         


              