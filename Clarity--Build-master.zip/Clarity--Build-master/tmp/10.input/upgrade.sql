
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '40' as "order",
         'Upgrade' as "name",
         'Check List before Upgrading' as "description",
         'See that Every Flag is Set to OK or WARN before Upgrading' as "action",
         'Type' as "th1",
         'Rule' as "th2",
         'Value' as "th3",
         'Flag' as "th4",
         'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("type", "rule", "value", "flag", "script"))))
       .getclobval()
from (

--Clarity Version on 3 Digits
with version as
 (select to_number(substr(replace(installed_version, '.', ''), 1, 3)) as version
    from (select installed_version
            from cmn_install_history
           where install_id in ('database', 'release_version')
           order by installed_date desc)
   where rownum = 1)




--Login xtd_deploy must exist with the proper rights, otherwise use another user
select 'User' as "type",
       'Login xtd_deploy must exist with the proper rights, otherwise use another user' as "rule",
       ' ' as "value",
       case
         when count(*) = 1 then
          'OK'
         else
          'WARN'
       end as "flag",
       '<NikuDataBus xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../xsd/nikuxog_user.xsd">\n
  <Header action="write" externalSource="NIKU" objectType="user" version="12"/>\n
  <Users>\n
    <User externalId=" " isLDAP="false" uiThemeDefaultPartitionCode=" " userLanguage="English" userLocale="en_US" userName="xtd_deploy" userStatus="ACTIVE" userTimezone="Europe/Brussels" userType="EXTERNAL">\n
      <PersonalInformation emailAddress="centreservices@coprime.fr" firstName="Clarity" lastName="Deployment"/>\n
      <Resource resourceId="xtd_deploy"/>\n
    </User>\n
  </Users>\n
</NikuDataBus>' as "script"
  from cmn_sec_users u
 where u.user_name = 'xtd_deploy'

--Login xtd_deploy language must be english
union all
select 'User',
       'Login xtd_deploy language must be english',
       l.language_code,
       case
         when l.language_code = 'en' then
          'OK'
         else
          'NOK'
       end,
       '<NikuDataBus xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../xsd/nikuxog_user.xsd">\n
  <Header action="write" externalSource="NIKU" objectType="user" version="13"/>\n
  <Users>\n
    <User externalId="' || nvl(u.external_id, '') || '" userLanguage="English" userName="' || u.user_name || '">\n
      <PersonalInformation emailAddress="' || u.email_address || '" firstName="' || u.first_name || '" lastName="' || u.last_name || '"/>\n
    </User>\n
  </Users>\n
</NikuDataBus>'
  from cmn_sec_users u
 inner join cmn_languages l on u.language_id = l.id
 where u.user_name = 'xtd_deploy'

--Login xtd_deploy locale must be en_US English (United States)
union all
select 'User',
       'Login xtd_deploy locale must be en_US English (United States)',
       u.locale,
       case
         when u.locale = 'en_US' then
          'OK'
         else
          'NOK'
       end,
       '<NikuDataBus xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../xsd/nikuxog_user.xsd">\n
  <Header action="write" externalSource="NIKU" objectType="user" version="13"/>\n
  <Users>\n
    <User externalId="' || nvl(u.external_id, '') || '" userLocale="en_US" userName="' || u.user_name || '">\n
      <PersonalInformation emailAddress="' || u.email_address || '" firstName="' || u.first_name || '" lastName="' || u.last_name || '"/>\n
    </User>\n
  </Users>\n
</NikuDataBus>'     
  from cmn_sec_users u
 where u.user_name = 'xtd_deploy'

--Login xtd_deploy Must Have all Global Rights
union all
select 'User',
       'Login xtd_deploy Must Have all Global Rights',
       to_char((count(*))) || ' missing',
       case
         when count(*) = 0 then
          'OK'
         else
          'NOK'
       end,
       'Add Global Rights on User'     
  from cmn_sec_groups g,
       cmn_sec_users  u
 where u.user_name = 'xtd_deploy'
   and g.right_type = 'SYSTEM'
   and g.is_active = 1
   and g.id not in ( --Global Rights on User
                    select g.id
                      from cmn_sec_assgnd_right ar
                     inner join cmn_sec_groups_v g on g.id = ar.right_id
                                                  and g.language_code = 'en'
                     where ar.instance_type = 'SYSTEM'
                       and ar.principal_id = u.id
                       and ar.principal_type = 'USER'
                       and g.right_type = 'SYSTEM' --Global
                       and g.is_active = 1
                    union
                    --Global Rights through Group
                    select r.id
                      from cmn_sec_groups_v r
                     inner join cmn_sec_group_flat_hiers h on h.group_id = r.id
                     inner join cmn_sec_user_groups ug on ug.group_id = h.parent_group_id
                     inner join cmn_sec_groups g on g.id = ug.group_id
                                                and g.group_role_type = 'GROUP' --Group Only
                     where r.right_type = 'SYSTEM' --Global
                       and r.language_code = 'en' --Name en
                       and r.is_active = 1
                       and g.is_active = 1 --Group Active Only
                       and ug.user_id = u.id
                    )
                   
--Login admin language must be english
union all
select 'User',
       'Login admin language must be english',
       l.language_code,
       case
         when l.language_code = 'en' then
          'OK'
         else
          'NOK'
       end,
       '<NikuDataBus xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../xsd/nikuxog_user.xsd">\n
  <Header action="write" externalSource="NIKU" objectType="user" version="13"/>\n
  <Users>\n
    <User externalId="' || nvl(u.external_id, '') || '" userLanguage="English" userName="' || u.user_name || '">\n
      <PersonalInformation emailAddress="' || u.email_address || '" firstName="' || u.first_name || '" lastName="' || u.last_name || '"/>\n
    </User>\n
  </Users>\n
</NikuDataBus>'
  from cmn_sec_users u
 inner join cmn_languages l on l.id = u.language_id
 where u.user_name = 'admin'

--Login admin locale must be en_US English (United States)
union all
select 'User',
       'Login admin locale must be en_US English (United States)',
       u.locale,
       case
         when u.locale = 'en_US' then
          'OK'
         else
          'NOK'
       end,
       '<NikuDataBus xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../xsd/nikuxog_user.xsd">\n
  <Header action="write" externalSource="NIKU" objectType="user" version="13"/>\n
  <Users>\n
    <User externalId="' || nvl(u.external_id, '') || '" userLocale="en_US" userName="' || u.user_name || '">\n
      <PersonalInformation emailAddress="' || u.email_address || '" firstName="' || u.first_name || '" lastName="' || u.last_name || '"/>\n
    </User>\n
  </Users>\n
</NikuDataBus>'     
  from cmn_sec_users u
 where u.user_name = 'admin'

--Login admin Must Have all Global Rights
union all
select 'User',
       'Login admin Must Have all Global Rights',
       to_char((count(*))) || ' missing',
       case
         when count(*) = 0 then
          'OK'
         else
          'NOK'
       end,
       'Add Global Rights on User'     
  from cmn_sec_groups g
 where g.right_type = 'SYSTEM'
   and g.is_active = 1
   and g.id not in ( --Global Rights on User
                    select g.id
                      from cmn_sec_assgnd_right ar
                     inner join cmn_sec_groups_v g on g.id = ar.right_id
                                                  and g.language_code = 'en'
                     where ar.instance_type = 'SYSTEM'
                       and ar.principal_id = 1 --User Admin
                       and ar.principal_type = 'USER'
                       and g.right_type = 'SYSTEM' --Global
                       and g.is_active = 1
                    union
                    --Global Rights through Group
                    select r.id
                      from cmn_sec_groups_v r
                     inner join cmn_sec_group_flat_hiers h on h.group_id = r.id
                     inner join cmn_sec_user_groups ug on ug.group_id = h.parent_group_id
                     inner join cmn_sec_groups g on g.id = ug.group_id
                                                and g.group_role_type = 'GROUP' --Group Only
                     where r.right_type = 'SYSTEM' --Global
                       and r.language_code = 'en' --Name en
                       and r.is_active = 1
                       and g.is_active = 1 --Group Active Only
                       and ug.user_id = 1 --User Admin
                    )

--Reset Login admin Password to niku2000
union all
select 'User',
       'Reset Login admin Password to niku2000',
       ' ',
       'WARN',
       
       '--13.2-\n
begin\n
  dbms_output.put_line(''Reset admin password to niku2000.'');\n
  update cmn_sec_users\n
     set pwd = (select pwd from cmn_sec_users where user_name = ''xc_admin''),\n
         user_status_id = 200\n
   where user_name = ''admin''\n
     and not pwd = (select pwd from cmn_sec_users where user_name = ''xc_admin'');\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;\n
--13.3+\n
begin\n
  dbms_output.put_line(''Reset admin password to niku2000.'');\n
  update cmn_sec_users u\n
     set u.pwd          = ''b42405b42403535333865636532b1cb94e15b207275f64358b0d6d0d414'',\n
         u.salt         = ''[B@5538ece2'',\n
         user_status_id = 200\n
   where id = 1\n
     and not (u.pwd = ''b42405b42403535333865636532b1cb94e15b207275f64358b0d6d0d414'' or u.salt = ''[B@5538ece2'');\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;'
       
  from cmn_sec_users u
 where u.user_name = 'admin'
   and not (u.pwd = (select pwd from cmn_sec_users where user_name = 'xc_admin')
         or u.pwd = 'b42405b42403535333865636532b1cb94e15b207275f64358b0d6d0d414')

--Clean up Excessive Notifications older than 30 days
union all
select 'User',
       'Clean up Excessive Notifications older than 30 days',
       to_char(count(*)) || ' notification(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       
       'begin\n
  dbms_output.put_line(''Cleaning table clb_notifications, older than 30 days.'');\n
  delete from clb_notifications where created_date < sysdate - 30;\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  dbms_output.put_line(''Cleaning orphaned records in clb_notification_assocs.'');\n
  delete from clb_notification_assocs where instance_id not in (select id from clb_notifications);\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;'
       
  from clb_notifications n
 where n.created_date < sysdate - 30

--Locked Documents need to be unlocked
union all
select 'Document',
       'Locked Documents need to be unlocked',
       to_char(count(*)) || ' document(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'NOK'
       end,
       
       'begin\n
  dbms_output.put_line(''Updating clb_dms_files table...'');\n
  update clb_dms_files f set f.lock_owner_id = null, f.lock_time_stamp = null where f.lock_owner_id <> 0;\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;'
       
  from clb_dms_files f
 where f.lock_owner_id <> 0

--Locked Projects need to be unlocked (page security.locks)
union all
select 'Investment',
       'Locked Projects need to be unlocked on page ' || case
         when version >= 130 then 'nu#action:security.locks'
         else 'app?action=security.locks'
       end,
       to_char((select count(*) from prlock where prtablename = 'SRM_PROJECTS')) || ' project(s)',
       case
         when (select count(*) from prlock where prtablename = 'SRM_PROJECTS') = 0 then
          'OK'
         else
          'NOK'
       end,
       
       'begin\n
  dbms_output.put_line(''Deleting from prlock table...'');\n
  delete from prlock where prtablename = ''SRM_PROJECTS'';\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;'
       
  from version

--Closed and to-be-deleted Projects are properly closed
union all
select 'Investment',
       'Closed and to-be-deleted Projects are properly closed',
       to_char(count(*)) || ' project(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       null
  from inv_investments i
 where i.purge_flag = 1

--Fix for 13.3, Ideas financially enable are not stored in financial tables (Reference CA : CLRT-72828_POSTUPGRADE_IDEA_PAC_MNT_PROJECTS.xml)
union all


select 'Investment',
       'Fix 13.3, ideas not in pac_mnt_projects or odf_ca_npiofinproperties',
       count(*) || ' idea(s)',
       decode(count(*), 0, 'OK', 'NOK'),
       '--Reference support CA : CLRT-72828_POSTUPGRADE_IDEA_PAC_MNT_PROJECTS.xml\n
begin\n
  dbms_output.put_line(''Fix 13.3 - Inserting elements in pac_mnt_projects for ideas financially enable'');\n
  insert into pac_mnt_projects\n
    (id,\n
     status,\n
     approved,\n
     master_project_code,\n
     project_code,\n
     billing_currency_code,\n
     labor_exchange_rate_type,\n
     expense_exchange_rate_type,\n
     materials_exchange_rate_type,\n
     equipment_exchange_rate_type,\n
     odf_object_code,\n
     cost_type)\n
    select i.id,\n
           ''H'',\n
           1,\n
           upper(i.code),\n
           upper(i.code),\n
           i.currency_code,\n
           ''AVERAGE'',\n
           ''AVERAGE'',\n
           ''AVERAGE'',\n
           ''AVERAGE'',\n
           i.odf_object_code,\n
           ''OPERATING''\n
      from inv_investments i\n
     where odf_object_code = ''idea''\n
       and not exists (select 1 from pac_mnt_projects where id = i.id);\n
  dbms_output.put_line(sql%rowcount || '' insert(s) done'');\n
  commit;\n
  dbms_output.put_line(''Fix 13.3 - Inserting elements in odf_ca_npiofinproperties for ideas financially enable'');\n
  insert into odf_ca_npiofinproperties\n
    (id,\n
     created_date,\n
     created_by,\n
     last_updated_date,\n
     last_updated_by,\n
     odf_object_code)\n
    select i.id,\n
           sysdate,\n
           1,\n
           sysdate,\n
           1,\n
           i.odf_object_code\n
      from inv_investments i\n
     where odf_object_code = ''idea''\n
       and not exists (select 1 from odf_ca_npiofinproperties where id = i.id);\n
  dbms_output.put_line(sql%rowcount || '' insert(s) done'');\n
  commit;\n
end;'
  from inv_ideas i
 where (not exists (select 1 from pac_mnt_projects where id = i.id) or
        not exists (select 1 from odf_ca_npiofinproperties where id = i.id))
   and (select version from version) >= 133



--Financial Processing, check Invalid Transactions
union all
select 'Finance',
       'Financial Processing, check Invalid Transactions',
       to_char(count(*)) || ' transaction(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       
       'begin\n
  dbms_output.put_line(''Deleting invalid transactions in imp_transactionimport.'');\n
  delete from imp_transactionimport where importstatus = ''E'';\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;'
       
  from imp_transactionimport
 where importstatus = 'E'

--Financial Processing, check Pending Transactions
union all
select 'Finance',
       'Financial Processing, check Pending Transactions',
       to_char(count(*)) || ' transaction(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Run Financial Jobs'
  from imp_transactionimport
 where not importstatus = 'E'

--Financial Processing, check Adjusting Transactions
union all
select 'Finance',
       'Financial Processing, check Adjusting Transactions',
       to_char(count(*)) || ' transaction(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Approve Adjusting Transactions'
  from ppa_transwipadjust
 where transtype != 'A'
    or adjtype = 'R'

--Financial Processing, check Post to WIP Transactions
union all
select 'Finance',
       'Financial Processing, check Post to WIP Transactions',
       to_char(count(*)) || ' transaction(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Post to WIP Transactions'
  from ppa_transcontrol

--Processes Running or Aborting need to be paused (lookup BPM_PROCESS_INSTANCE_STATES)
union all
select 'Process',
       'Processes Running or Aborting need to be paused',
       to_char(count(*)) || ' process(es)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       null
  from bpm_run_processes p
 where p.status_code in ('BPM_PIS_ABORTING', 'BPM_PIS_RUNNING')

--Processes in Error older than 30 days need to be cancelled (lookup BPM_PROCESS_INSTANCE_STATES)
union all
select 'Process',
       'Processes in Error older than 30 days need to be cancelled',
       to_char(count(*)) || ' process(es)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'begin\n
  dbms_output.put_line(''Update bpm_run_processes.status_code to BPM_PIS_ABORTING.'');\n
  update bpm_run_processes p\n
     set p.user_action = ''BPM_PIA_ABORT'', p.status_code = ''BPM_PIS_ABORTING''\n
   where p.status_code = ''BPM_PIS_ERROR''\n
     and p.user_action is null;\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;'
  from bpm_run_processes p
 where p.status_code = 'BPM_PIS_ERROR'

--Clean up Processes completed - Delete Process Instance
union all
select 'Process',
       'Clean up Processes completed - Delete Process Instance',
       to_char(count(*)) || ' process(es)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Run Job "Delete Process Instance"'
  from bpm_run_processes p
 where p.status_code = 'BPM_PIS_DONE'

--Scheduled Job Datamart Extraction and Rollup Datamart must be created by an english user
union all
select 'Job',
       'Scheduled Job "' || j.name || '" should be created by an english user',
       u.user_name || ' ' || l.language_code,
       case
         when l.language_code = 'en' then
          'OK'
         else
          'NOK'
       end,
       '<NikuDataBus xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="../xsd/nikuxog_user.xsd">\n
  <Header action="write" externalSource="NIKU" objectType="user" version="13"/>\n
  <Users>\n
    <User externalId="' || nvl(u.external_id, '') || '" userLanguage="English" userName="' || u.user_name || '">\n
      <PersonalInformation emailAddress="' || u.email_address || '" firstName="' || u.first_name || '" lastName="' || u.last_name || '"/>\n
    </User>\n
  </Users>\n
</NikuDataBus>'
  from cmn_sch_jobs j
 inner join cmn_sch_job_definitions d on d.id = j.job_definition_id
 inner join cmn_sec_users u on u.id = j.created_by
 inner join cmn_languages l on l.id = u.language_id
 where d.job_code in ('Datamart_Extraction', 'Datamart_Rollup')
   and j.status_code = 'SCHEDULED'

--Jobs Processing or Scheduled need to be paused
union all
select 'Job',
       'Jobs Processing or Scheduled need to be paused',
       to_char(count(*)) || ' job(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Application > Reports and Jobs > [Scheduled Jobs] > Action Pause'
  from cmn_sch_jobs j
 where j.status_code in ('PROCESSING', 'SCHEDULED')
   and not (select job_code from cmn_sch_job_definitions d where d.id = j.job_definition_id) = 'job_check_heart_beat'

--Clean up Job completed - Remove Job Logs and Report Library entries (15 days)
union all
select 'Job',
       'Clean up Job completed - Remove Job Logs and Report Library entries older than 15 days',
       to_char(count(*)) || ' log(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Run Job "Remove Job Logs and Report Library"'
  from cmn_sch_jobs j
 inner join cmn_sch_job_logs l on l.job_run_id = j.id
 where j.status_code = 'COMPLETED'
   and l.created_date < sysdate - 15

--Datamart tables need to be cleaned Up NBI_CLEAN_DATAMART_SP
union all
select 'Job',
       'Datamart tables need to be cleaned up NBI_CLEAN_DATAMART_SP',
       to_char(count(*)) || ' records in nbi_dim_obs',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'begin\n\tdbms_output.put_line(''Cleaning Datamart tables...'');\n\tNBI_CLEAN_DATAMART_SP;\n\tdbms_output.put_line(''Done'');\nend;'
       
  from nbi_dim_obs o

--Orphaned Documents need to be Purged
union all
select 'Job',
       'Orphaned Documents need to be Purged',
       to_char(count(*)) || ' record(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Run Job "Purge Documents"'
  from clb_dms_files
 where parent_folder_id not in (select id from clb_dms_folders)

--Clean up Audit Trails - Purge Audit Trail
union all
select 'Object',
       'Clean up Audit Trails - Purge Audit Trail',
       to_char(count(*)) || ' value(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       'Run Job "Purge Audit Trail"'
  from cmn_audits a
 inner join odf_audited_attributes aa on aa.object_code = a.object_code
                                     and aa.attribute_code = a.attribute_code
 inner join odf_objects o on o.code = a.object_code
 where aa.is_active = 1
   and nvl(o.purge_audit_days_old, 0) <> 0
   and a.created_date < sysdate - (o.purge_audit_days_old + 1)

--Disable Audit trails
union all
select 'Object',
       'Disable Custom Audit Trails',
       to_char(count(*)) || ' attribute(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'NOK'
       end,
       null
  from odf_audited_attributes a
 where a.is_active = 1

--Set all Required Custom Attributes to be Not-Required
union all
select 'Object',
       'Set all Required Custom Attributes to be Not-Required',
       to_char(count(*)) || ' attribute(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'NOK'
       end,
       null
  from odf_custom_attributes a
 where a.is_custom = 1
   and a.is_required = 1
   and not (a.object_name =  'cop_prj_statusrpt' and a.column_name = 'cop_project_manager')

--Fix 13.2, Delete portfolio Objects
union all
select 'Object',
       'Fix 13.2, Delete portfolio Objects',
       ' ',
       case
         when version >= 132 and (select count(*) from odf_objects where code = 'portfolio') > 0 then
          'NOK'
         else
          'OK'
       end,
       null
  from version
  
--Standard Calendar must exist
union all
select 'Calendar',
       'Standard Calendar must exist',
       ' ',
       case
         when count(*) = 1 then
          'OK'
         else
          'NOK'
       end,
       'Recreate Standard Calendar'
  from prcalendar
 where prname = 'Standard'


--Tablespace of table PRJ_BLB_SLICES must have enough space during upgrade (table is copied)
union all
select 'DBMS',
       'Table ' || t.table_name || ' is copied during upgrade, tablespace ' || t.tablespace_name ||
       ' must have enough space',
       ' ',
       case
         when round(tb.max_size / (1024 * 1024)) >
              nvl(round((t.num_rows * t.avg_row_len) / (1024 * 1024)), 0) +
              (select round(sum(s.bytes) / (1024 * 1024))
                 from user_segments s
                where s.tablespace_name = t.tablespace_name) then
          'OK'
         else
          'WARN'
       end,
       'with tbl as\n
 (select t.owner as "owner",\n
         t.table_name as "table",\n
         t.tablespace_name as "tablespace",\n
         nvl(round((t.num_rows * t.avg_row_len) / (1024 * 1024)), 0) as "mb_needed",\n
         round(sum(f.bytes) / (1024 * 1024)) as "total_space",\n
         (select round(sum(s.bytes) / (1024 * 1024)) from dba_segments s where s.tablespace_name = t.tablespace_name) as "total_used_space",\n
         max(f.autoextensible) as "autoextensible",\n
         count(*) as "count_data_files",\n
         sum(f.maxbytes) / (1024 * 1024) * count(*) as "mb_max",\n
         sum(f.user_bytes) / (1024 * 1024) as "mb_used",\n
         round((sum(f.user_bytes) / (1024 * 1024)) / (sum(f.maxbytes) / (1024 * 1024)) * 100, 2) as "percent_used"\n
    from all_tables     t,\n
         dba_data_files f\n
   where f.tablespace_name = t.tablespace_name\n
     and t.table_name = ''PRJ_BLB_SLICES''\n
   group by t.owner,\n
            t.table_name,\n
            t.tablespace_name,\n
            nvl(round((t.num_rows * t.avg_row_len) / (1024 * 1024)), 0))\n
select ''Owner'' as "property",\n
       tbl."owner" as "value"\n
  from tbl\n
union all\n
select ''Table'',\n
       tbl."table"\n
  from tbl\n
union all\n
select ''Tablespace'',\n
       tbl."tablespace"\n
  from tbl\n
union all\n
select ''MB Needed'',\n
       to_char((tbl."mb_needed"))\n
  from tbl\n
union all\n
select ''MB Max'',\n
       to_char((tbl."mb_max"))\n
  from tbl\n
union all\n
select ''MB Used'',\n
       to_char((tbl."mb_used"))\n
  from tbl\n
union all\n
select ''Data Files'',\n
       to_char((tbl."count_data_files"))\n
  from tbl\n
union all\n
select ''MB Free'',\n
       to_char((tbl."total_space" - tbl."total_used_space")) as "mb_free"\n
  from tbl\n
union all\n
select ''Autoextensible'',\n
       tbl."autoextensible"\n
  from tbl\n
union all\n
select ''Flag'',\n
       case\n
         when tbl."autoextensible" = ''YES'' and tbl."mb_max" > (tbl."mb_needed" + tbl."mb_used") then\n
          ''OK''\n
         when tbl."autoextensible" = ''NO'' and tbl."mb_needed" < (tbl."total_space" - tbl."total_used_space") then\n
          ''OK''\n
         else\n
          ''NOK''\n
       end as "flag"\n
  from tbl'
  from user_tables t
 inner join user_tablespaces tb on tb.tablespace_name = t.tablespace_name
 where t.table_name = 'PRJ_BLB_SLICES'


--Orphaned records in table NMS_MESSAGE_DELIVERY need to be deleted
union all
select 'DBMS',
       'Orphaned records in table NMS_MESSAGE_DELIVERY need to be deleted',
       to_char(count(*)) || ' record(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       
       'begin\n
  dbms_output.put_line(''Deleting orphaned records in nms_message_delivery.'');\n
  delete from nms_message_delivery where message_id not in (select id from nms_messages);\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;'
       
  from nms_message_delivery
 where message_id not in (select id from nms_messages)

--Orphaned records in table CMN_SESSION_PROPERTIES need to be deleted
union all
select 'DBMS',
       'Orphaned records in table CMN_SESSION_PROPERTIES need to be deleted',
       to_char(count(*)) || ' record(s)',
       case
         when count(*) = 0 then
          'OK'
         else
          'WARN'
       end,
       
       'begin\n
  dbms_output.put_line(''Deleting orphaned records in cmn_session_properties.'');\n
  delete from cmn_session_properties\n
   where session_id not in (select id from cmn_sessions)\n
     and session_id not in (select session_id from cmn_session_audits);\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;'
       
  from cmn_session_properties
 where session_id not in (select id from cmn_sessions)
   and session_id not in (select session_id from cmn_session_audits)


--TEC1527468 ORA-01438: on Column PFM_INV_CONTRAINTS.PH_CURVE_SUM
union all
select 'DBMS',
       'TEC1527468 ORA-01438: on Column PFM_INV_CONTRAINTS.PH_CURVE_SUM',
       ' ',
       case
         when c.data_precision >= 32 then
          'OK'
         else
          'NOK'
       end,
       'alter table pfm_inv_constraint_sums modify (ph_curve_sum number(32,6));'
  from user_tab_columns c
 where c.table_name = 'PFM_INV_CONSTRAINT_SUMS'
   and c.column_name = 'PH_CURVE_SUM'

  
)


              