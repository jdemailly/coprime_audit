
                


select xmlelement(name "QueryResult",
       xmlattributes(
    '91' as "order",
    'Oracle Custom Objects' as "name",
    'Detect Custom Triggers on current schema' as "description",
    'Disable each trigger before upgrading and reactivate them' as "action",
    'Name' as "th1",
    'Type' as "th2",
    'Trigger Type' as "th3",
    'Object Type' as "th4",
    'Table' as "th5",
    'Status' as "th6",
    'Created' as "th7",
    'Flag' as "th8",
    'Script' as "th9"),
         xmlagg(xmlelement("Record", xmlforest("name", "type", "trigger_type", "base_object_type", "table_name", "status", "created", "flag", "script")))).getclobval()
from (

--Triggers
select o.object_name as "name",
       o.object_type as "type",
       t.trigger_type as "trigger_type",
       t.base_object_type as "base_object_type",
       t.table_name as "table_name",
       t.status as "status",
       to_char(o.created, 'yyyy-mm-dd') as "created",
       'WARN' as "flag",
       'alter trigger ' || lower(o.object_name) || ' disable;\nalter trigger ' || lower(o.object_name) || ' enable;' as "script"
  from user_objects o
 inner join user_triggers t on t.trigger_name = o.object_name
 where o.object_type = 'TRIGGER'
   and o.object_name not like 'T_PROJECT_%'
 order by o.object_name

)



              