
                


select xmlelement(name "QueryResult",
       xmlattributes(
        '93' as "order",
        'Oracle Source Code' as "name",
        'Potential Impact on Oracle objects during migration' as "description",
        'Analyze each Oracle Object and see if there is an impact during migration' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Line' as "th3",
        'Code' as "th4",
        'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "type", "line", "source_code", "script"))))
       .getclobval()
from (

--View : Use of function dbms_xmlgen.getxml to Get View Text and Search on It
select "name",
       "type",
       "line",
       "source_code",
       "script"
  from (select v1.view_name as "name",
               'VIEW' as "type",
               0 as "line",
               ' ' as "source_code",
               dbms_xmlgen.getxml('select text from user_views where view_name = ''' || v1.view_name || '''') as text,
               'select * from user_views where view_name = ''' || v1.view_name || ''';' as "script"
          from user_views v1
         where not v1.view_name like 'ODFSEC_%'
           and not v1.view_name like 'ODF_%'
           and not v1.view_name like 'RPT_%'
           and not v1.view_name like 'PRJ_%'
           and not v1.view_name like 'NBI_%'
           and not v1.view_name like 'CMN_%'
           and not v1.view_name like 'NTD_%'
           and not v1.view_name like 'CLB_%'
           and not v1.view_name like 'CAL_%'
           and not v1.view_name like 'INV_%'
           and not v1.view_name like 'OBS_%'
           and not v1.view_name like 'BPM_%'
           and not v1.view_name like 'BIZ_%') v
 where lower(v.text) like '%<plandata%'
    or lower(v.text) like '%odf_aud_value_fct%'
    or lower(v.text) like '%cal_events_get_nhresource_availability%'
    or lower(v.text) like '%pma_calc_present_value%'
    or lower(v.text) like '%pma_calc_pv_cost_for_inv%'
    or lower(v.text) like '%pma_trunc_month_fct%'
    or lower(v.text) like '%cmn_sql_trace%'
    or lower(v.text) like '%cal_event_nhresources%'
    or lower(v.text) like '%cal_nhresource_types%'
    or lower(v.text) like '%cal_nhresources%'
    or lower(v.text) like '%cmn_seq_pma_aggr_keys%'
    or lower(v.text) like '%cmn_seq_pma_aggr_values%'
    or lower(v.text) like '%cmn_seq_pma_aggr_values_validity%'
    or lower(v.text) like '%cmn_seq_pma_financial_values%'
    or lower(v.text) like '%cmn_seq_pma_pinned_investments%'
    or lower(v.text) like '%cmn_seq_pma_portfolio_contents%'
    or lower(v.text) like '%cmn_seq_pma_portfolio_roles%'
    or lower(v.text) like '%cmn_seq_pma_portfolios%'
    or lower(v.text) like '%cmn_seq_pma_priority_chart_conf%'
    or lower(v.text) like '%cmn_seq_pma_prtflio_incl_ctnt_types%'
    or lower(v.text) like '%odf_ca_contract%'
    or lower(v.text) like '%odf_ca_portfolio%'
    or lower(v.text) like '%pma_aggr_keys%'
    or lower(v.text) like '%pma_aggr_values%'
    or lower(v.text) like '%pma_aggr_values_validity%'
    or lower(v.text) like '%pma_ef_candidates%'
    or lower(v.text) like '%pma_ef_investments%'
    or lower(v.text) like '%pma_financial_values%'
    or lower(v.text) like '%pma_pinned_investments%'
    or lower(v.text) like '%pma_portfolio_contents%'
    or lower(v.text) like '%pma_portfolio_roles%'
    or lower(v.text) like '%pma_portfolios%'
    or lower(v.text) like '%pma_priority_chart_conf%'
    or lower(v.text) like '%pma_prtflio_incl_ctnt_types%'
    or lower(v.text) like '%odf_contract_v%'
    or lower(v.text) like '%odf_contract_v2%'
    or lower(v.text) like '%odf_portfolio_v%'
    or lower(v.text) like '%odf_portfolio_v2%'
    or lower(v.text) like '%odfsec_contract_v%'
    or lower(v.text) like '%odfsec_contract_v2%'
    or lower(v.text) like '%odfsec_portfolio_v%'
    or lower(v.text) like '%odfsec_portfolio_v2%'
    or (lower(v.text) like '%cap_scenarios%' and lower(v.text) like '%portfolio_id%')
    or (lower(v.text) like '%cmn_sec_right_v%' and (lower(v.text) like '%aop_id%' or lower(v.text) like '%id%'))
    or (lower(v.text) like '%cmn_sec_users%' and lower(v.text) like '%sqltrace_active%')
    or (lower(v.text) like '%cmn_ui_themes%' and lower(v.text) like '%folder%')
    or (lower(v.text) like '%cmn_user_session_v%' and lower(v.text) like '%sqltrace_active%')
    or (lower(v.text) like '%fin_cost_plan_details%' and
        (lower(v.text) like '%plan_detail_1_key%' or lower(v.text) like '%plan_detail_2_key%' or
         lower(v.text) like '%prchargecode_id%' or lower(v.text) like '%prrole_id%' or
         lower(v.text) like '%transclass_id%'))
    or (lower(v.text) like '%inv_projects%' and
        (lower(v.text) like '%prbasefinish%' or lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasetime%'))
    or (lower(v.text) like '%odf_application_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_application_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_asset_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_asset_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_assignment_v%' and
        (lower(v.text) like '%prbasefinish%' or lower(v.text) like '%prbasemax%' or
         lower(v.text) like '%prbasepattern%' or lower(v.text) like '%prbasepattern_caption%' or
         lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasesum%'))
    or (lower(v.text) like '%odf_assignment_v2%' and
        (lower(v.text) like '%prbasefinish%' or lower(v.text) like '%prbasemax%' or
         lower(v.text) like '%prbasepattern%' or lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasesum%'))
    or (lower(v.text) like '%odf_costplan_v%' and
        (lower(v.text) like '%plan_by_1_code_caption%' or lower(v.text) like '%plan_by_2_code_caption%'))
    or (lower(v.text) like '%odf_costplandetail_v%' and
        (lower(v.text) like '%cost_pctplan%' or lower(v.text) like '%object_id%' or
         lower(v.text) like '%plan_by_1_code%' or lower(v.text) like '%plan_by_1_code_caption%' or
         lower(v.text) like '%plan_by_2_code%' or lower(v.text) like '%plan_by_2_code_caption%' or
         lower(v.text) like '%plan_code%' or lower(v.text) like '%plan_detail_1%' or
         lower(v.text) like '%plan_detail_2%' or lower(v.text) like '%plan_name%' or
         lower(v.text) like '%prchargecode_id%' or lower(v.text) like '%prrole_id%' or
         lower(v.text) like '%transclass_id%'))
    or (lower(v.text) like '%odf_costplandetail_v2%' and
        (lower(v.text) like '%cost_pctplan%' or lower(v.text) like '%object_id%' or
         lower(v.text) like '%plan_by_1_code%' or lower(v.text) like '%plan_by_2_code%' or
         lower(v.text) like '%plan_code%' or lower(v.text) like '%plan_detail_1%' or
         lower(v.text) like '%plan_detail_2%' or lower(v.text) like '%plan_name%' or
         lower(v.text) like '%prchargecode_id%' or lower(v.text) like '%prrole_id%' or
         lower(v.text) like '%transclass_id%'))
    or (lower(v.text) like '%odf_department_v%' and lower(v.text) like '%last_updated_by%')
    or (lower(v.text) like '%odf_department_v2%' and lower(v.text) like '%last_updated_by%')
    or (lower(v.text) like '%odf_idea_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_idea_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_inv_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_inv_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_investmenthierarchy_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_investmenthierarchy_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_other_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_other_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_product_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_product_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_project_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasetime%' or
         lower(v.text) like '%schedule_variance%' or lower(v.text) like '%schedule_variance_color%' or
         lower(v.text) like '%schedule_variance_color_nls%' or lower(v.text) like '%schedule_variance_map%' or
         lower(v.text) like '%schedule_variance_map_nls%'))
    or (lower(v.text) like '%odf_project_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasetime%' or
         lower(v.text) like '%schedule_variance%'))
    or (lower(v.text) like '%odf_service_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_service_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_task_v%' and
        (lower(v.text) like '%prbaseduration%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbaseisfixed%' or lower(v.text) like '%prbaseisfixed_image%' or
         lower(v.text) like '%prbaseisfixed_image_nls%' or lower(v.text) like '%prbaseisfixed_map%' or
         lower(v.text) like '%prbaseisfixed_map_nls%' or lower(v.text) like '%prbasestart%' or
         lower(v.text) like '%prbasetime%'))
    or (lower(v.text) like '%odf_task_v2%' and
        (lower(v.text) like '%prbaseduration%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbaseisfixed%' or lower(v.text) like '%prbasestart%' or
         lower(v.text) like '%prbasetime%'))
    or (lower(v.text) like '%prassignment%' and
        (lower(v.text) like '%prbasemax%' or lower(v.text) like '%prbasepattern%' or lower(v.text) like '%prbasesum%'))
    or (lower(v.text) like '%prj_blb_slices%' and
        (lower(v.text) like '%created_by%' or lower(v.text) like '%id%' or lower(v.text) like '%last_updated_by%' or
         lower(v.text) like '%last_updated_date%' or lower(v.text) like '%unit%'))
    or (lower(v.text) like '%prnote%' and (lower(v.text) like '%prcreatedby%' or lower(v.text) like '%prmodby%'))
    or (lower(v.text) like '%prtask%' and (lower(v.text) like '%prbaseduration%' or lower(v.text) like '%prbasefinish%' or
                                           lower(v.text) like '%prbaseisfixed%' or lower(v.text) like '%prbasestart%' or
                                           lower(v.text) like '%prbasetime%'))

union all
--Procedure, Function, Package
select o.object_name as "name",
       o.object_type as "type",
       s.line        as "line",
       s.text        as "source_code",
       'select * from user_source where name = ''' || o.object_name || ''' and type = ''' || o.object_type || ''';' as "script"
  from user_objects o
 inner join user_source s on s.name = o.object_name
                         and s.type = o.object_type
 where lower(s.text) like '%<plandata%' or lower(s.text) like '%odf_aud_value_fct%' or lower(s.text) like '%cal_events_get_nhresource_availability%' or
       lower(s.text) like '%pma_calc_present_value%' or lower(s.text) like '%pma_calc_pv_cost_for_inv%' or
       lower(s.text) like '%pma_trunc_month_fct%' or lower(s.text) like '%cmn_sql_trace%' or
       lower(s.text) like '%cal_event_nhresources%' or lower(s.text) like '%cal_nhresource_types%' or
       lower(s.text) like '%cal_nhresources%' or lower(s.text) like '%cmn_seq_pma_aggr_keys%' or
       lower(s.text) like '%cmn_seq_pma_aggr_values%' or
       lower(s.text) like '%cmn_seq_pma_aggr_values_validity%' or
       lower(s.text) like '%cmn_seq_pma_financial_values%' or
       lower(s.text) like '%cmn_seq_pma_pinned_investments%' or
       lower(s.text) like '%cmn_seq_pma_portfolio_contents%' or
       lower(s.text) like '%cmn_seq_pma_portfolio_roles%' or lower(s.text) like '%cmn_seq_pma_portfolios%' or
       lower(s.text) like '%cmn_seq_pma_priority_chart_conf%' or
       lower(s.text) like '%cmn_seq_pma_prtflio_incl_ctnt_types%' or lower(s.text) like '%odf_ca_contract%' or
       lower(s.text) like '%odf_ca_portfolio%' or lower(s.text) like '%pma_aggr_keys%' or
       lower(s.text) like '%pma_aggr_values%' or lower(s.text) like '%pma_aggr_values_validity%' or
       lower(s.text) like '%pma_ef_candidates%' or lower(s.text) like '%pma_ef_investments%' or
       lower(s.text) like '%pma_financial_values%' or lower(s.text) like '%pma_pinned_investments%' or
       lower(s.text) like '%pma_portfolio_contents%' or lower(s.text) like '%pma_portfolio_roles%' or
       lower(s.text) like '%pma_portfolios%' or lower(s.text) like '%pma_priority_chart_conf%' or
       lower(s.text) like '%pma_prtflio_incl_ctnt_types%' or lower(s.text) like '%odf_contract_v%' or
       lower(s.text) like '%odf_contract_v2%' or lower(s.text) like '%odf_portfolio_v%' or
       lower(s.text) like '%odf_portfolio_v2%' or lower(s.text) like '%odfsec_contract_v%' or
       lower(s.text) like '%odfsec_contract_v2%' or lower(s.text) like '%odfsec_portfolio_v%' or
       lower(s.text) like '%odfsec_portfolio_v2%' or
       (lower(s.text) like '%cap_scenarios%' and lower(s.text) like '%portfolio_id%') or
       (lower(s.text) like '%cmn_sec_right_v%' and
       (lower(s.text) like '%aop_id%' or lower(s.text) like '%id%')) or
       (lower(s.text) like '%cmn_sec_users%' and lower(s.text) like '%sqltrace_active%') or
       (lower(s.text) like '%cmn_ui_themes%' and lower(s.text) like '%folder%') or
       (lower(s.text) like '%cmn_user_session_v%' and lower(s.text) like '%sqltrace_active%') or
       (lower(s.text) like '%fin_cost_plan_details%' and
       (lower(s.text) like '%plan_detail_1_key%' or lower(s.text) like '%plan_detail_2_key%' or
       lower(s.text) like '%prchargecode_id%' or lower(s.text) like '%prrole_id%' or
       lower(s.text) like '%transclass_id%')) or
       (lower(s.text) like '%inv_projects%' and
       (lower(s.text) like '%prbasefinish%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%')) or
       (lower(s.text) like '%odf_application_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_application_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_asset_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_asset_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_assignment_v%' and
       (lower(s.text) like '%prbasefinish%' or lower(s.text) like '%prbasemax%' or
       lower(s.text) like '%prbasepattern%' or lower(s.text) like '%prbasepattern_caption%' or
       lower(s.text) like '%prbasestart%' or lower(s.text) like '%prbasesum%')) or
       (lower(s.text) like '%odf_assignment_v2%' and
       (lower(s.text) like '%prbasefinish%' or lower(s.text) like '%prbasemax%' or
       lower(s.text) like '%prbasepattern%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasesum%')) or
       (lower(s.text) like '%odf_costplan_v%' and
       (lower(s.text) like '%plan_by_1_code_caption%' or lower(s.text) like '%plan_by_2_code_caption%')) or
       (lower(s.text) like '%odf_costplandetail_v%' and
       (lower(s.text) like '%cost_pctplan%' or lower(s.text) like '%object_id%' or
       lower(s.text) like '%plan_by_1_code%' or lower(s.text) like '%plan_by_1_code_caption%' or
       lower(s.text) like '%plan_by_2_code%' or lower(s.text) like '%plan_by_2_code_caption%' or
       lower(s.text) like '%plan_code%' or lower(s.text) like '%plan_detail_1%' or
       lower(s.text) like '%plan_detail_2%' or lower(s.text) like '%plan_name%' or
       lower(s.text) like '%prchargecode_id%' or lower(s.text) like '%prrole_id%' or
       lower(s.text) like '%transclass_id%')) or
       (lower(s.text) like '%odf_costplandetail_v2%' and
       (lower(s.text) like '%cost_pctplan%' or lower(s.text) like '%object_id%' or
       lower(s.text) like '%plan_by_1_code%' or lower(s.text) like '%plan_by_2_code%' or
       lower(s.text) like '%plan_code%' or lower(s.text) like '%plan_detail_1%' or
       lower(s.text) like '%plan_detail_2%' or lower(s.text) like '%plan_name%' or
       lower(s.text) like '%prchargecode_id%' or lower(s.text) like '%prrole_id%' or
       lower(s.text) like '%transclass_id%')) or
       (lower(s.text) like '%odf_department_v%' and lower(s.text) like '%last_updated_by%') or
       (lower(s.text) like '%odf_department_v2%' and lower(s.text) like '%last_updated_by%') or
       (lower(s.text) like '%odf_idea_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_idea_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_inv_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_inv_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_investmenthierarchy_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_investmenthierarchy_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_other_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_other_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_product_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_product_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_project_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbasestart%' or lower(s.text) like '%prbasetime%' or
       lower(s.text) like '%schedule_variance%' or lower(s.text) like '%schedule_variance_color%' or
       lower(s.text) like '%schedule_variance_color_nls%' or lower(s.text) like '%schedule_variance_map%' or
       lower(s.text) like '%schedule_variance_map_nls%')) or
       (lower(s.text) like '%odf_project_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbasestart%' or lower(s.text) like '%prbasetime%' or
       lower(s.text) like '%schedule_variance%')) or
       (lower(s.text) like '%odf_service_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_service_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_task_v%' and
       (lower(s.text) like '%prbaseduration%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbaseisfixed%' or lower(s.text) like '%prbaseisfixed_image%' or
       lower(s.text) like '%prbaseisfixed_image_nls%' or lower(s.text) like '%prbaseisfixed_map%' or
       lower(s.text) like '%prbaseisfixed_map_nls%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%')) or
       (lower(s.text) like '%odf_task_v2%' and
       (lower(s.text) like '%prbaseduration%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbaseisfixed%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%')) or
       (lower(s.text) like '%prassignment%' and
       (lower(s.text) like '%prbasemax%' or lower(s.text) like '%prbasepattern%' or
       lower(s.text) like '%prbasesum%')) or
       (lower(s.text) like '%prj_blb_slices%' and
       (lower(s.text) like '%created_by%' or lower(s.text) like '%id%' or
       lower(s.text) like '%last_updated_by%' or lower(s.text) like '%last_updated_date%' or
       lower(s.text) like '%unit%')) or
       (lower(s.text) like '%prnote%' and
       (lower(s.text) like '%prcreatedby%' or lower(s.text) like '%prmodby%')) or
       (lower(s.text) like '%prtask%' and
       (lower(s.text) like '%prbaseduration%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbaseisfixed%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%'))
      
      

)


              