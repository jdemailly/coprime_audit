
                


select xmlelement(name "QueryResult",
       xmlattributes(
        '93' as "order",
        'Oracle Custom Objects' as "name",
        'Detect Custom Indexes on Current Schema' as "description",
        'If the table is not custom, drop or disable index' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Table' as "th3",
        'Index Type' as "th4",
        'Status' as "th5",
        'Created' as "th6",
        'Flag' as "th7",
        'Script' as "th8"),
         xmlagg(xmlelement("Record", xmlforest("name", "type", "table_name", "index_type", "status", "created", "flag", "script")))).getclobval()
from (

--Indexes
select o.object_name as "name",
       o.object_type as "type",
       i.table_name as "table_name",
       i.index_type as "index_type",
       i.status as "status",
       to_char(o.created, 'yyyy-mm-dd') as "created",
       'WARN' as "flag",
       'alter index ' || o.object_name || ' disable;' as "script"
  from user_objects o
 inner join user_indexes i on i.index_name = o.object_name
 where o.object_type = 'INDEX'
   and not i.index_type = 'LOB' --Ignore LOB Type
   and not (o.object_name like 'ODF_CA_%' or o.object_name like 'ODFSEC_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%')
 order by o.object_name

)



              