
                


select xmlelement(name "QueryResult",
       xmlattributes(
        '92' as "order",
        'Oracle Custom Objects' as "name",
        'Detect Custom Tables on current schema' as "description",
        'Convert each table into an object Clarity' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Created' as "th3",
        'Flag' as "th4"),
         xmlagg(xmlelement("Record", xmlforest("name", "type", "created", "flag")))).getclobval()
from (

--Tables
select o.object_name as "name",
       o.object_type as "type",
       to_char(o.created, 'yyyy-mm-dd') as "created",
       'WARN' as "flag"
  from user_objects o
 where o.object_type = 'TABLE'
   and not (o.object_name like 'ODF_CA_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%')
 order by o.object_name

)



              