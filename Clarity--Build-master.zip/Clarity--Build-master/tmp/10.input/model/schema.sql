
                


select xmlelement(name "QueryResult",
       xmlattributes(
        '90' as "order",
        'Oracle Custom Objects' as "name",
        'Detect Custom Objects on current schema' as "description",
        'Review each object and see if there is an impact or not before upgrade' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Created' as "th3",
        'Script' as "th4"),
         xmlagg(xmlelement("Record", xmlforest("name", "type", "created", "script")))).getclobval()
from (
select o.object_name as "name",
       o.object_type as "type",
       to_char(o.created, 'yyyy-mm-dd') as "created",
       case
         when o.object_type in ('PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'TRIGGER', 'FUNCTION', 'TYPE') then
          'select text from user_source where name = ''' || o.object_name || ''' and type = ''' || o.object_type || ''''
         when o.object_type = 'TABLE' then
          'select * from user_tables where table_name = ''' || o.object_name ||
          ''';\nselect * from user_tab_columns where table_name = ''' || o.object_name || ''';'
         when o.object_type = 'VIEW' then
          'select text from user_views where view_name = ''' || o.object_name || ''''
         when o.object_type = 'INDEX' then
          'select * from user_indexes where index_name = ''' || o.object_name || ''''
         when o.object_type = 'SEQUENCE' then
          'select * from user_sequences where sequence_name = ''' || o.object_name || ''''
       end as "script"
  from user_objects o
 where not (o.object_type = 'INDEX' and (o.object_name like 'ODF_CA_%' or o.object_name like 'ODFSEC_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%' or o.object_name like 'SYS%'))
   and not (o.object_type = 'LOB' and o.object_name like 'SYS_LOB%')
   and not (o.object_type = 'SEQUENCE' and o.object_name like 'ODF_CA_%')
   and not (o.object_type = 'TABLE' and (o.object_name like 'ODF_CA_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%'))
   and not (o.object_type = 'TYPE' and o.object_name like 'SYS_PLSQL_%')
   and not (o.object_type = 'VIEW' and (o.object_name like 'ODFSEC_%' or o.object_name like 'ODF_%'))
   and not (o.object_type = 'FUNCTION' and o.object_name like 'ODF_AUD_%')
   and not (o.object_type = 'TRIGGER' and o.object_name like 'T_PROJECT_%')
 order by o.object_name
)




              