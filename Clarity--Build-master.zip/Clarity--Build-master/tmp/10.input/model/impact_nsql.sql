
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '92' as "order",
         'nSQL' as "name",
         'Potential Impact on nSQL Queries during migration' as "description",
         'Analyze each nSQL Query and see if there is an impact during migration' as "action",
         'Code' as "th1",
         'Name' as "th2",
         'Description' as "th3",
         'Updated By' as "th4",
         'Updated' as "th5",
         'Script' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "description", "last_user", "last_updated_date", "script"))))
       .getclobval()
from (

select q.query_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = q.id
           and n.table_name = 'CMN_GG_NSQL_QUERIES'
           and n.language_code = 'en') as "name",
       nvl((select n.description
          from cmn_captions_nls n
         where n.pk_id = q.id
           and n.table_name = 'CMN_GG_NSQL_QUERIES'
           and n.language_code = 'en'), ' ') as "description",
       (select r.full_name from srm_resources r where r.user_id = q.last_updated_by) as "last_user",
       q.last_updated_date as "last_updated_date",
       'select nsql_text from cmn_nsql_queries where id = ' || t.id || ';'  as "script"
  from cmn_gg_nsql_queries q
 inner join cmn_nsql_queries t on t.id = q.cmn_nsql_queries_id
 where q.last_updated_date >
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and (
       lower(t.nsql_text) like '%odf_aud_value_fct%' or lower(t.nsql_text) like '%cal_events_get_nhresource_availability%' or
       lower(t.nsql_text) like '%pma_calc_present_value%' or lower(t.nsql_text) like '%pma_calc_pv_cost_for_inv%' or
       lower(t.nsql_text) like '%pma_trunc_month_fct%' or lower(t.nsql_text) like '%cmn_sql_trace%' or
       lower(t.nsql_text) like '%cal_event_nhresources%' or lower(t.nsql_text) like '%cal_nhresource_types%' or
       lower(t.nsql_text) like '%cal_nhresources%' or lower(t.nsql_text) like '%cmn_seq_pma_aggr_keys%' or
       lower(t.nsql_text) like '%cmn_seq_pma_aggr_values%' or
       lower(t.nsql_text) like '%cmn_seq_pma_aggr_values_validity%' or
       lower(t.nsql_text) like '%cmn_seq_pma_financial_values%' or
       lower(t.nsql_text) like '%cmn_seq_pma_pinned_investments%' or
       lower(t.nsql_text) like '%cmn_seq_pma_portfolio_contents%' or
       lower(t.nsql_text) like '%cmn_seq_pma_portfolio_roles%' or lower(t.nsql_text) like '%cmn_seq_pma_portfolios%' or
       lower(t.nsql_text) like '%cmn_seq_pma_priority_chart_conf%' or
       lower(t.nsql_text) like '%cmn_seq_pma_prtflio_incl_ctnt_types%' or lower(t.nsql_text) like '%odf_ca_contract%' or
       lower(t.nsql_text) like '%odf_ca_portfolio%' or lower(t.nsql_text) like '%pma_aggr_keys%' or
       lower(t.nsql_text) like '%pma_aggr_values%' or lower(t.nsql_text) like '%pma_aggr_values_validity%' or
       lower(t.nsql_text) like '%pma_ef_candidates%' or lower(t.nsql_text) like '%pma_ef_investments%' or
       lower(t.nsql_text) like '%pma_financial_values%' or lower(t.nsql_text) like '%pma_pinned_investments%' or
       lower(t.nsql_text) like '%pma_portfolio_contents%' or lower(t.nsql_text) like '%pma_portfolio_roles%' or
       lower(t.nsql_text) like '%pma_portfolios%' or lower(t.nsql_text) like '%pma_priority_chart_conf%' or
       lower(t.nsql_text) like '%pma_prtflio_incl_ctnt_types%' or lower(t.nsql_text) like '%odf_contract_v%' or
       lower(t.nsql_text) like '%odf_contract_v2%' or lower(t.nsql_text) like '%odf_portfolio_v%' or
       lower(t.nsql_text) like '%odf_portfolio_v2%' or lower(t.nsql_text) like '%odfsec_contract_v%' or
       lower(t.nsql_text) like '%odfsec_contract_v2%' or lower(t.nsql_text) like '%odfsec_portfolio_v%' or
       lower(t.nsql_text) like '%odfsec_portfolio_v2%' or
       (lower(t.nsql_text) like '%cap_scenarios%' and lower(t.nsql_text) like '%portfolio_id%') or
       (lower(t.nsql_text) like '%cmn_sec_right_v%' and
       (lower(t.nsql_text) like '%aop_id%' or lower(t.nsql_text) like '%id%')) or
       (lower(t.nsql_text) like '%cmn_sec_users%' and lower(t.nsql_text) like '%sqltrace_active%') or
       (lower(t.nsql_text) like '%cmn_ui_themes%' and lower(t.nsql_text) like '%folder%') or
       (lower(t.nsql_text) like '%cmn_user_session_v%' and lower(t.nsql_text) like '%sqltrace_active%') or
       (lower(t.nsql_text) like '%fin_cost_plan_details%' and
       (lower(t.nsql_text) like '%plan_detail_1_key%' or lower(t.nsql_text) like '%plan_detail_2_key%' or
       lower(t.nsql_text) like '%prchargecode_id%' or lower(t.nsql_text) like '%prrole_id%' or
       lower(t.nsql_text) like '%transclass_id%')) or
       (lower(t.nsql_text) like '%inv_projects%' and
       (lower(t.nsql_text) like '%prbasefinish%' or lower(t.nsql_text) like '%prbasestart%' or
       lower(t.nsql_text) like '%prbasetime%')) or
       (lower(t.nsql_text) like '%odf_application_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_application_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_asset_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_asset_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_assignment_v%' and
       (lower(t.nsql_text) like '%prbasefinish%' or lower(t.nsql_text) like '%prbasemax%' or
       lower(t.nsql_text) like '%prbasepattern%' or lower(t.nsql_text) like '%prbasepattern_caption%' or
       lower(t.nsql_text) like '%prbasestart%' or lower(t.nsql_text) like '%prbasesum%')) or
       (lower(t.nsql_text) like '%odf_assignment_v2%' and
       (lower(t.nsql_text) like '%prbasefinish%' or lower(t.nsql_text) like '%prbasemax%' or
       lower(t.nsql_text) like '%prbasepattern%' or lower(t.nsql_text) like '%prbasestart%' or
       lower(t.nsql_text) like '%prbasesum%')) or
       (lower(t.nsql_text) like '%odf_costplan_v%' and
       (lower(t.nsql_text) like '%plan_by_1_code_caption%' or lower(t.nsql_text) like '%plan_by_2_code_caption%')) or
       (lower(t.nsql_text) like '%odf_costplandetail_v%' and
       (lower(t.nsql_text) like '%cost_pctplan%' or lower(t.nsql_text) like '%object_id%' or
       lower(t.nsql_text) like '%plan_by_1_code%' or lower(t.nsql_text) like '%plan_by_1_code_caption%' or
       lower(t.nsql_text) like '%plan_by_2_code%' or lower(t.nsql_text) like '%plan_by_2_code_caption%' or
       lower(t.nsql_text) like '%plan_code%' or lower(t.nsql_text) like '%plan_detail_1%' or
       lower(t.nsql_text) like '%plan_detail_2%' or lower(t.nsql_text) like '%plan_name%' or
       lower(t.nsql_text) like '%prchargecode_id%' or lower(t.nsql_text) like '%prrole_id%' or
       lower(t.nsql_text) like '%transclass_id%')) or
       (lower(t.nsql_text) like '%odf_costplandetail_v2%' and
       (lower(t.nsql_text) like '%cost_pctplan%' or lower(t.nsql_text) like '%object_id%' or
       lower(t.nsql_text) like '%plan_by_1_code%' or lower(t.nsql_text) like '%plan_by_2_code%' or
       lower(t.nsql_text) like '%plan_code%' or lower(t.nsql_text) like '%plan_detail_1%' or
       lower(t.nsql_text) like '%plan_detail_2%' or lower(t.nsql_text) like '%plan_name%' or
       lower(t.nsql_text) like '%prchargecode_id%' or lower(t.nsql_text) like '%prrole_id%' or
       lower(t.nsql_text) like '%transclass_id%')) or
       (lower(t.nsql_text) like '%odf_department_v%' and lower(t.nsql_text) like '%last_updated_by%') or
       (lower(t.nsql_text) like '%odf_department_v2%' and lower(t.nsql_text) like '%last_updated_by%') or
       (lower(t.nsql_text) like '%odf_idea_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_idea_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_inv_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_inv_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_investmenthierarchy_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_investmenthierarchy_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_other_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_other_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_product_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_product_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_project_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%' or lower(t.nsql_text) like '%prbasefinish%' or
       lower(t.nsql_text) like '%prbasestart%' or lower(t.nsql_text) like '%prbasetime%' or
       lower(t.nsql_text) like '%schedule_variance%' or lower(t.nsql_text) like '%schedule_variance_color%' or
       lower(t.nsql_text) like '%schedule_variance_color_nls%' or lower(t.nsql_text) like '%schedule_variance_map%' or
       lower(t.nsql_text) like '%schedule_variance_map_nls%')) or
       (lower(t.nsql_text) like '%odf_project_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%' or lower(t.nsql_text) like '%prbasefinish%' or
       lower(t.nsql_text) like '%prbasestart%' or lower(t.nsql_text) like '%prbasetime%' or
       lower(t.nsql_text) like '%schedule_variance%')) or
       (lower(t.nsql_text) like '%odf_service_v%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_service_v2%' and
       (lower(t.nsql_text) like '%inv_planned_npv%' or lower(t.nsql_text) like '%inv_planned_roi%' or
       lower(t.nsql_text) like '%planned_pv_cost%')) or
       (lower(t.nsql_text) like '%odf_task_v%' and
       (lower(t.nsql_text) like '%prbaseduration%' or lower(t.nsql_text) like '%prbasefinish%' or
       lower(t.nsql_text) like '%prbaseisfixed%' or lower(t.nsql_text) like '%prbaseisfixed_image%' or
       lower(t.nsql_text) like '%prbaseisfixed_image_nls%' or lower(t.nsql_text) like '%prbaseisfixed_map%' or
       lower(t.nsql_text) like '%prbaseisfixed_map_nls%' or lower(t.nsql_text) like '%prbasestart%' or
       lower(t.nsql_text) like '%prbasetime%')) or
       (lower(t.nsql_text) like '%odf_task_v2%' and
       (lower(t.nsql_text) like '%prbaseduration%' or lower(t.nsql_text) like '%prbasefinish%' or
       lower(t.nsql_text) like '%prbaseisfixed%' or lower(t.nsql_text) like '%prbasestart%' or
       lower(t.nsql_text) like '%prbasetime%')) or
       (lower(t.nsql_text) like '%prassignment%' and
       (lower(t.nsql_text) like '%prbasemax%' or lower(t.nsql_text) like '%prbasepattern%' or
       lower(t.nsql_text) like '%prbasesum%')) or
       (lower(t.nsql_text) like '%prj_blb_slices%' and
       (lower(t.nsql_text) like '%created_by%' or lower(t.nsql_text) like '%id%' or
       lower(t.nsql_text) like '%last_updated_by%' or lower(t.nsql_text) like '%last_updated_date%' or
       lower(t.nsql_text) like '%unit%')) or
       (lower(t.nsql_text) like '%prnote%' and
       (lower(t.nsql_text) like '%prcreatedby%' or lower(t.nsql_text) like '%prmodby%')) or
       (lower(t.nsql_text) like '%prtask%' and
       (lower(t.nsql_text) like '%prbaseduration%' or lower(t.nsql_text) like '%prbasefinish%' or
       lower(t.nsql_text) like '%prbaseisfixed%' or lower(t.nsql_text) like '%prbasestart%' or
       lower(t.nsql_text) like '%prbasetime%')))

)


              