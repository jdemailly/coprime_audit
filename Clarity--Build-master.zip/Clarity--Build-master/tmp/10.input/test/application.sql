
                

with version as
 (select to_number(substr(replace(version, '.', ''), 1, 3)) as version
    from (select h.installed_version as version
            from cmn_install_history h
           where h.install_id in ('contentPack::clarityContent', 'database')
           order by h.installed_date desc)
   where rownum = 1)

select xmlelement(name "QueryResult",
      xmlattributes(
      '101' as "order",
      'Test' as "name",
      'Application Objects by navigation' as "description",
      'URI' as "th1",
      'Object' as "th2",
      'Vector' as "th3",
      'Count' as "th4",
      'Script' as "th5"),
      xmlagg(xmlelement(name "Record", xmlforest("uri", "object", "sort", "count", "script"))))
       .getclobval()
from (



--Personal > Organizer [Action Item]
select 'Personal > Organizer' as "uri",
       'Action' as "object",
       'All' as "sort",
       count(*) as "count",
       'select count(*) from cal_action_items' as "script"
  from cal_action_items
union all
select 'Personal > Organizer',
       'Action',
       'User xtd_deploy',
       count(*),
       'select count(*)\n
  from cal_action_items\n
 where owner_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(''xtd_deploy''))'      
  from cal_action_items
 where owner_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper('xtd_deploy'))
union all
select 'Personal > Organizer',
       'Action',
       'Type ' || (select name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'CAL_OBJECT_TYPE'
           and l.lookup_code = a.object_type),
       count(*),
       'select (select name\n
          from cmn_lookups      l,\n
               cmn_captions_nls n\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''CAL_OBJECT_TYPE''\n
           and l.lookup_code = a.object_type) as type,\n
       count(*) as count\n
  from cal_action_items a\n
 group by a.object_type'
  from cal_action_items a
 group by a.object_type

--Personal > Organizer [Task]
union all
select 'Personal > Organizer',
       'Task',
       'All',
       count(*),
       'select count(*) from prtask;\n
select t.prid,\n
       t.prname,\n
       t.prexternalid,\n
       t.created_date\n
  from prtask t\n
 where t.prprojectid is null'
  from prtask
union all
select 'Personal > Organizer',
       'Task',
       'User xtd_deploy',
       count(*),
       'select count(*)\n
  from prtask        t,\n
       prassignment  a,\n
       srm_resources r,\n
       cmn_sec_users u\n
 where a.prtaskid = t.prid\n
   and a.prresourceid = r.id\n
   and r.user_id = u.id\n
   and nls_upper(u.user_name) = nls_upper(''xtd_deploy'')'
  from prtask        t,
       prassignment  a,
       srm_resources r,
       cmn_sec_users u
 where a.prtaskid = t.prid
   and a.prresourceid = r.id
   and r.user_id = u.id
   and nls_upper(u.user_name) = nls_upper('xtd_deploy')
union all
select 'Personal > Organizer',
       'Task',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'INVESTMENT_OBJ_TYPE'
           and l.lookup_code = p.investment_code),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''INVESTMENT_OBJ_TYPE''\n
           and l.lookup_code = p.investment_code) as type,\n
       count(*) as count\n
  from srm_projects p,\n
       prtask       t\n
 where p.id = t.prprojectid\n
 group by p.investment_code'
  from srm_projects p,
       prtask       t
 where p.id = t.prprojectid
 group by p.investment_code

--Personal > Organizer [Process]
union all
select 'Personal > Organizer',
       'Process',
       'All',
       count(*),
       'select count(*) from bpm_run_processes'
  from bpm_run_processes
union all
select 'Personal > Organizer',
       'Process',
       'Status ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'BPM_PROCESS_INSTANCE_STATES'
           and l.lookup_code = p.status_code),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''BPM_PROCESS_INSTANCE_STATES''\n
           and l.lookup_code = p.status_code) as status,\n
       count(*) as count\n
  from bpm_run_processes p\n
 group by p.status_code'
  from bpm_run_processes p
 group by p.status_code

--Personal > Organizer [Notification]
union all
select 'Personal > Organizer',
       'Notification',
       'All',
       count(*),
       'select count(*) from clb_notifications'
  from clb_notifications
union all
select 'Personal > Organizer',
       'Notification',
       'User xtd_deploy',
       count(*),
       'select count(*)\n
  from clb_notifications\n
 where receiver_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(''xtd_deploy''))'
  from clb_notifications
 where receiver_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper('xtd_deploy'))
union all
select 'Personal > Organizer',
       'Notification',
       'Type ' || (select c.name
          from cmn_captions_nls c,
               cmn_lookups      l
         where c.pk_id = l.id
           and c.table_name = 'CMN_LOOKUPS'
           and c.language_code = 'en'
           and l.lookup_type = 'NOTIFICATION_TYPE'
           and l.lookup_code = n.event_type),
       count(*),
       'select (select c.name\n
          from cmn_captions_nls c,\n
               cmn_lookups      l\n
         where c.pk_id = l.id\n
           and c.table_name = ''CMN_LOOKUPS''\n
           and c.language_code = ''en''\n
           and l.lookup_type = ''NOTIFICATION_TYPE''
           and l.lookup_code = n.event_type) as type,\n
       count(*) as count\n
  from clb_notifications n\n
 group by n.event_type'
  from clb_notifications n
 group by n.event_type

--Personal > Dashboards
union all
select 'Personal > Dashboards',
       'Dashboard',
       'All',
       count(*),
       'select count(*)\n
  from cmn_pages\n
 where principal_type = ''USER''\n
   and source = ''customer''\n
   and page_type_code = ''page'''
  from cmn_pages
 where principal_type = 'USER'
   and source = 'customer'
   and page_type_code = 'page'
union all
select 'Personal > Dashboards',
       'Dashboard',
       'User xtd_deploy',
       count(*),
       'select count(*)\n
  from cmn_pages\n
 where principal_type = ''USER''\n
   and source = ''customer''\n
   and page_type_code = ''page''\n
   and principal_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(''xtd_deploy''))'
  from cmn_pages
 where principal_type = 'USER'
   and source = 'customer'
   and page_type_code = 'page'
   and principal_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper('xtd_deploy'))

--Personal > Portlets
union all
select 'Personal > Portlets',
       'Portlet',
       'All',
       count(*),
       'select count(*)\n
  from cmn_portlets\n
 where principal_type = ''USER''\n
   and source = ''customer'''
  from cmn_portlets
 where principal_type = 'USER'
   and source = 'customer'
union all
select 'Personal > Portlets',
       'Portlet',
       'User xtd_deploy',
       count(*),
       'select count(*)\n
  from cmn_portlets\n
 where principal_type = ''USER''\n
   and source = ''customer''\n
   and principal_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(''xtd_deploy''))'
  from cmn_portlets
 where principal_type = 'USER'
   and source = 'customer'
   and principal_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper('xtd_deploy'))

--Personal > Timesheets
union all
select 'Personal > Timesheets',
       'Timesheet',
       'All',
       count(*),
       'select count(*) from prtimesheet'
  from prtimesheet
union all
select 'Personal > Timesheets',
       'Timeentry',
       'All',
       count(*),
       'select count(*) from prtimeentry'
  from prtimeentry
union all
select 'Personal > Timesheets',
       'Timesheet',
       case
         when p.prisopen = 1 then
          'Open'
         else
          'Closed'
       end,
       count(*),
       'select p.prisopen,\n
       count(*)\n
  from prtimesheet  t,\n
       prtimeperiod p\n
 where t.prtimeperiodid = p.prid\n
 group by p.prisopen'
  from prtimesheet  t,
       prtimeperiod p
 where t.prtimeperiodid = p.prid
 group by p.prisopen
union all
select 'Personal > Timesheets',
       'Timesheet',
       'Status ' || (select n.name
                        from cmn_captions_nls n,
                             cmn_lookups      l
                       where n.pk_id = l.id
                         and n.table_name = 'CMN_LOOKUPS'
                         and n.language_code = 'en'
                         and l.lookup_type = 'prTimeSheetStatus'
                         and l.lookup_enum = t.prstatus),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''prTimeSheetStatus''\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus'
  from prtimesheet t
 group by t.prstatus

--Personal > Reports and Jobs
union all
select 'Personal > Reports and Jobs',
       'Job',
       'All',
       count(*),
       'select count(*) from cmn_sch_jobs'
  from cmn_sch_jobs
union all
select 'Personal > Reports and Jobs',
       'Job',
       'Status ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'SCH_JOB_STATUS'
           and l.lookup_code = j.status_code),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''SCH_JOB_STATUS''\n
           and l.lookup_code = j.status_code) as status,\n
       count(*) as count\n
  from cmn_sch_jobs j\n
 group by j.status_code'
  from cmn_sch_jobs j
 group by j.status_code

--Organization > Departments
union all
select 'Organization > Departments',
       'Department',
       'All',
       count(*),
       'select count(*) from departments'      
  from departments

--Organization > Knowledge Store
union all
select 'Organization > Knowledge Store',
       'Knowledge Store',
       'All',
       count(*),
       'select count(*)\n
  from clb_dms_folders f\n
 where f.folder_type = ''StandardFolder''\n
   and f.assoc_obj_type = ''NAME''\n
   and f.path_name = ''/Root/DMS/KS'''
  from clb_dms_folders f
 where f.folder_type = 'StandardFolder'
   and f.assoc_obj_type = 'NAME'
   and f.path_name = '/Root/DMS/KS'
union all
select 'Organization > Knowledge Store',
       'Folder',
       'All',
       count(*),
       'select count(*) from clb_dms_folders'
  from clb_dms_folders
union all
select 'Organization > Knowledge Store',
       'File',
       'All',
       count(*),
       'select count(*) from clb_dms_files'
  from clb_dms_files
union all
select 'Organization > Knowledge Store',
       'File Store',
       'All',
       count(*),
       'select count(*) from clb_dms_file_store'
  from clb_dms_file_store 

--IT Service Management > Services
union all
select 'IT Service Management > Services',
       'Service',
       'All',
       count(*),
       'select count(*)\n
  from srm_projects p\n
 where p.investment_code = ''SERVICE'''
  from inv_services
 
--Portfolio Management > Portfolios
union all
select 'Portfolio Management > Portfolios',
       'Portfolio',
       'All',
      
       (select num_rows
          from user_tables
         where table_name = (case
                 when version < 132 then
                  'PMA_PORTFOLIOS'
                 else
                  'PFM_PORTFOLIOS'
               end)),


       case
         when version < 132 then 'select * from pma_portfolios p'
         else 'select * from pfm_portfolios p'
       end
  from version

--Portfolio Management > Programs
union all
select 'Portfolio Management > Programs',
       'Program',
       'All',
       count(*),
'select *\n
  from srm_projects p\n
 where p.is_program = 1'
  from srm_projects p
 where p.is_program = 1

--Portfolio Management > Projects
union all
select 'Portfolio Management > Projects',
       'Project',
       'Default',
       count(*),
       'select *\n
  from srm_projects p\n
 where p.investment_code = ''PROJECT''\n
   and p.is_active = 1'
  from srm_projects p
 where p.investment_code = 'PROJECT'
   and p.is_active = 1
union all
select 'Portfolio Management > Projects',
       'Project',
       'All',
       count(*),
       'select *\n
  from srm_projects p\n
 where p.investment_code = ''PROJECT'''
  from srm_projects p
 where p.investment_code = 'PROJECT'
union all
select 'Portfolio Management > Projects',
       'Project',
       case
        when p.is_template = 0 then 'Project Not Template'
        else 'Project Template'
       end,
       count(*),
       'select p.is_template,\n
       count(*)\n
  from srm_projects p\n
 where p.investment_code = ''PROJECT''\n
 group by p.is_template'
  from srm_projects p
 where p.investment_code = 'PROJECT'
 group by p.is_template
union all
select 'Portfolio Management > Projects',
       'Project',
       case
        when p.is_active = 0 then 'Project Not Active'
        else 'Project Active'
       end,
       count(*),
       'select p.is_active,\n
       count(*)\n
  from srm_projects p\n
 where p.investment_code = ''PROJECT''\n
 group by p.is_active'
  from srm_projects p
 where p.investment_code = 'PROJECT'
 group by p.is_active
union all
select 'Portfolio Management > Projects',
       'Task',
       'All',
       count(*),
       'select count(*)\n
  from prtask       t,\n
       srm_projects p\n
 where t.prprojectid = p.id\n
   and p.investment_code = ''PROJECT'''
  from prtask       t,
       srm_projects p
 where t.prprojectid = p.id
   and p.investment_code = 'PROJECT'
union all
select 'Portfolio Management > Projects',
       'Assignment',
       'All',
       count(*),
       'select count(*)\n
  from prassignment a,\n
       prtask       t,\n
       srm_projects p\n
 where a.prtaskid = t.prid\n
   and t.prprojectid = p.id\n
   and p.investment_code = ''PROJECT'''
  from prassignment a,
       prtask       t,
       srm_projects p
 where a.prtaskid = t.prid
   and t.prprojectid = p.id
   and p.investment_code = 'PROJECT'
union all
select 'Portfolio Management > Projects',
       'Risk',
       'All',
       count(*),
       'select count(*)\n
  from rim_risks_and_issues r\n
 where r.table_name = ''SRM_PROJECTS''\n
   and r.type_code = ''RISK'''
  from rim_risks_and_issues r
 where r.table_name = 'SRM_PROJECTS'
   and r.type_code = 'RISK'
union all
select 'Portfolio Management > Projects',
       'Issue',
       'All',
       count(*),
       'select count(*)\n
  from rim_risks_and_issues r\n
 where r.table_name = ''SRM_PROJECTS''\n
   and r.type_code = ''ISSUE'''
  from rim_risks_and_issues r
 where r.table_name = 'SRM_PROJECTS'
   and r.type_code = 'ISSUE'
union all
select 'Portfolio Management > Projects',
       'Change Request',
       'All',
       count(*),
       'select count(*)\n
  from rim_risks_and_issues r\n
 where r.table_name = ''SRM_PROJECTS''\n
   and r.type_code = ''CHANGE'''
  from rim_risks_and_issues r
 where r.table_name = 'SRM_PROJECTS'
   and r.type_code = 'CHANGE'

--Portfolio Management > Applications
union all
select 'Portfolio Management > Applications',
       'Application',
       'All',
       count(*),
       'select *\n
  from srm_projects p\n
 where p.investment_code = ''APPLICATION'''
  from inv_applications

--Portfolio Management > Assets
union all
select 'Portfolio Management > Assets',
       'Asset',
       'All',
       count(*),
       'select *\n
  from srm_projects p\n
 where p.investment_code = ''ASSET'''
  from inv_assets

--Portfolio Management > Products
union all
select 'Portfolio Management > Products',
       'Product',
       'All',
       count(*),
       'select *\n
  from srm_projects p\n
 where p.investment_code = ''PRODUCT'''
  from inv_products 

--Portfolio Management > Other Work
union all
select 'Portfolio Management > Other Work',
       'Other Work',
       'All',
       count(*),
       'select *\n
  from srm_projects p\n
 where p.investment_code = ''OTHER'''
  from inv_others

--Portfolio Management [Cost Plan]
union all
select 'Portfolio Management',
       'Cost Plan',
       'All',
       count(*),
       'select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = ''FORECAST'''
  from fin_plans
 where plan_type_code = 'FORECAST'
union all
select 'Portfolio Management',
       'Cost Plan',
       'Details',
       count(*),
       'select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = ''FORECAST'''
  from fin_plans             f,
       fin_cost_plan_details d
 where d.plan_id = f.id
   and f.plan_type_code = 'FORECAST'

--Portfolio Management [Benefit Plan]
union all
select 'Portfolio Management',
       'Benefit Plan',
       'All',
       count(*),
       'select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code is null'
  from fin_plans
 where plan_type_code is null
union all
select 'Portfolio Management',
       'Benefit Plan',
       'Details',
       count(*),
       'select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and p.plan_type_code is null'
  from fin_plans             f,
       fin_cost_plan_details d
 where d.plan_id = f.id
   and f.plan_type_code is null

--Portfolio Management [Budget Plan]
union all
select 'Portfolio Management',
       'Budget Plan',
       'All',
       count(*),
       'select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = ''BUDGET'''
  from fin_plans
 where plan_type_code = 'BUDGET'
union all
select 'Portfolio Management',
       'Budget Plan',
       'Details',
       count(*),
       'select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = ''BUDGET'''
  from fin_plans             f,
       fin_cost_plan_details d
 where d.plan_id = f.id
   and f.plan_type_code = 'BUDGET'

--Portfolio Management [Scenario]
union all
select 'Portfolio Management',
       'Scenario',
       'All',
       count(*),
       'select count(*)\n
  from cap_scenarios s,\n
       cmn_sec_users u\n
 where s.user_id = u.id'
  from cap_scenarios

--Requirements Planning > Release Planning
union all
select 'Requirements Planning > Release Planning',
       'Release Planning',
       'All',
       count(*),
       'select count(*) from rqp_release_plans'
  from rqp_release_plans

--Requirements Planning > Releases
union all
select 'Requirements Planning > Releases',
       'Release',
       'All',
       count(*),
       'select count(*) from rqp_releases'
  from rqp_releases

--Requirements Planning > Requirements
union all
select 'Requirements Planning > Requirements',
       'Requirement',
       'All',
       count(*),
       'select count(*) from rqp_requirements'      
  from rqp_requirements

--Demand Management > Ideas
union all
select 'Demand Management > Ideas',
       'Idea',
       'All',
       count(*),
       'select count(*)\n
  from srm_projects p\n
 where p.investment_code = ''IDEA'''
  from inv_ideas

--Demand Management > Incidents
union all
select 'Demand Management > Incidents',
       'Incident',
       'All',
       count(*),
       'select count(*) from imm_incidents'
  from imm_incidents

--Resource Management > Resources
union all
select 'Resource Management > Resources',
       'Resource',
       'All',
       count(*),
       'select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 0
union all
select 'Resource Management > Resources',
       'Resource',
       'Active',
       count(*),
       'select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
   and r.is_active = 1'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 0
   and r.is_active = 1
union all
select 'Resource Management > Resources',
       'Resource',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'RESOURCE_TYPE'
           and l.lookup_enum = r.resource_type),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''RESOURCE_TYPE''\n
           and l.lookup_enum = r.resource_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.resource_type'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 0
 group by r.resource_type
union all
select 'Resource Management > Resources',
       'Resource',
       'Person Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'SRM_RESOURCE_TYPE'
           and l.id = r.person_type),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''SRM_RESOURCE_TYPE''\n
           and l.id = r.person_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.person_type'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 0
 group by r.person_type
union all
select 'Resource Management > Resources',
       'Role',
       'All',
       count(*),
       'select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 1
union all
select 'Resource Management > Resources',
       'Role',
       'Active',
       count(*),
       'select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1\n
   and r.is_active = 1'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 1
   and r.is_active = 1
union all
select 'Resource Management > Resources',
       'Role',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'RESOURCE_TYPE'
           and l.lookup_enum = r.resource_type),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''RESOURCE_TYPE''\n
           and l.lookup_enum = r.resource_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1\n
 group by r.resource_type'
  from srm_resources r,
       prj_resources rp
 where r.id = rp.prid
   and rp.prisrole = 1
 group by r.resource_type

--Resource Management > Resource Requisitions
union all
select 'Resource Management > Resource Requisitions',
       'Requisition',
       'All',
       count(*),
       'select count(*) from rsm_req_requisitions'
  from rsm_req_requisitions

--Financial Management > Transactions
union all
select 'Financial Management > Transactions',
       'Transaction',
       'All',
       count(*),
       'select count(*) from ppa_wip'
  from ppa_wip

--Financial Management > Invoices
union all
select 'Financial Management > Invoices',
       'Invoice',
       'All',
       count(*),
       'select count(*) from cbk_invoice'
  from cbk_invoice
 
--Financial Management > Companies
union all
select 'Financial Management > Companies',
       'Company',
       'All',
       count(*),
       'select count(*) from srm_companies'
  from srm_companies

 ) t
         


              