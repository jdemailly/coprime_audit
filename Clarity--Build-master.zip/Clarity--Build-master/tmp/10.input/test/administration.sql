
                

select xmlelement(name "QueryResult",
     xmlattributes(
     '102' as "order",
     'Test' as "name",
     'Administration Objects by navigation' as "description",
     'URI' as "th1",
     'Object' as "th2",
     'Vector' as "th3",
     'Count' as "th4",
     'Script' as "th5"),
     xmlagg(xmlelement(name "Record", xmlforest("uri", "object", "sort", "count", "script"))))
       .getclobval()
from (



--Organization and Access > Resources
select 'Organization and Access > Resources' as "uri",
       'User' as "object",
       'Default' as "sort",
       count(*) as "count",
'select count(*)\n
  from cmn_sec_users\n
 where user_status_id = 200' as "script"
  from cmn_sec_users
 where user_status_id = 200
union all
select 'Organization and Access > Resources',
       'User',
       'Show All',
       count(*),
'select count(*) from cmn_sec_users'
  from cmn_sec_users
union all
select 'Organization and Access > Resources',
       'User',
       'Lang ' || (select n.name
          from cmn_captions_nls n,
               cmn_languages    l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LANGUAGES'
           and n.language_code = 'en'
           and l.id = u.language_id),
       count(*),      
'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_languages    l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LANGUAGES''\n
           and n.language_code = ''en''\n
           and l.id = u.language_id) as lang,\n
       count(*) as count\n
  from cmn_sec_users u\n
 group by u.language_id'
  from cmn_sec_users u
 group by u.language_id

--Organization and Access > Groups
union all
select 'Organization and Access > Groups',
       'Group',
       'Default',
       count(*),
'select count(*)\n
  from cmn_sec_groups g\n
 where g.group_role_type = ''GROUP''\n
   and group_type_id is not null\n
   and is_active = 1\n
 order by g.created_date desc'
  from cmn_sec_groups
 where group_role_type = 'GROUP'
   and group_type_id is not null
   and is_active = 1
union all
select 'Organization and Access > Groups',
       'Group',
       'Show All',
       count(*),
'select count(*)\n
  from cmn_sec_groups g\n
 where g.group_role_type = ''GROUP''\n
   and group_type_id is not null\n
 order by g.created_date desc'
  from cmn_sec_groups
 where group_role_type = 'GROUP'
   and group_type_id is not null
union all
select 'Organization and Access > Groups',
       'Group',
       'Resources in ' || (select name
          from cmn_captions_nls
         where pk_id = g.id
           and table_name = 'CMN_SEC_GROUPS'
           and language_code = 'en'),
       count(*),
'select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = ''CMN_SEC_GROUPS''\n
           and language_code = ''en'') as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = ''GROUP''\n
   and g.group_type_id is not null\n
 group by g.id'
  from cmn_sec_groups      g,
       cmn_sec_user_groups u
 where g.id = u.group_id
   and g.group_role_type = 'GROUP'
   and g.group_type_id is not null
 group by g.id

--Organization and Access > OBS
union all
select 'Organization and Access > OBS',
       'OBS',
       'Default',
       count(*),
       'select count(*) from prj_obs_types'
  from prj_obs_types
union all
select 'Organization and Access > OBS',
       'OBS',
       'OBS ' || (select t.name from prj_obs_types t where t.id = u.type_id),
       count(*),
       'select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id'
  from prj_obs_units u
 group by u.type_id 

--Studio > Partition Models
union all
select 'Studio > Partition Models',
       'Partition',
       'All',
       count(*),
       'select count(*) from cmn_partition_models'
  from cmn_partition_models

--Studio > Objects
union all
select 'Studio > Objects',
       'Object',
       'Default',
       count(*),
       'select count(*)\n
  from odf_objects o\n
 where o.is_customizable = 1'
  from odf_objects o
 where o.is_customizable = 1
union all
select 'Studio > Objects',
       'Object',
       'All',
       count(*),
       'select count(*) from odf_objects'
  from odf_objects
union all
select 'Studio > Objects',
       'Object',
       'Custom',
       count(*),
       'select count(*)\n
  from odf_objects\n
 where is_custom = 1'
  from odf_objects
 where is_custom = 1

--Studio > Queries
union all
select 'Studio > Queries',
       'Query',
       'All',
       count(*),
       'select count(*) from cmn_gg_nsql_queries'
  from cmn_gg_nsql_queries
union all
select 'Studio > Queries',
       'Query',
       'Source ' || source,
       count(*),
       'select source,\n
       count(*)\n
  from cmn_gg_nsql_queries\n
 group by source'
  from cmn_gg_nsql_queries
 group by source

--Studio > Portlets
union all
select 'Studio > Portlets',
       'Portlets',
       'All',
       count(*),
       'select count(*)\n
  from cmn_portlets p\n
 where p.principal_type <> ''USER'''
  from cmn_portlets p
 where not p.principal_type = 'USER'
union all
select 'Studio > Portlets',
       'Portlets',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'PORTLET_TYPE'
           and l.lookup_code = p.portlet_type_code),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''PORTLET_TYPE''\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       count(*) as count\n
  from cmn_portlets p\n
 where p.principal_type <> ''USER''\n
   and p.portlet_type_code <> ''FAVORITE''\n
 group by p.portlet_type_code'
  from cmn_portlets p
 where p.principal_type <> 'USER'
   and p.portlet_type_code <> 'FAVORITE'
 group by p.portlet_type_code

--Studio > Portlet Pages
union all
select 'Studio > Portlet Pages',
       'Portlet Page',
       'Default',
       count(*),
       'select count(*)\n
  from cmn_pages p\n
 where p.principal_type <> ''USER''\n
   and p.page_type_code not in (''subtab'', ''tab'')\n
   and p.principal_type = ''SYSTEM''\n
   and p.page_type_code <> ''template'''
  from cmn_pages p
 where p.principal_type <> 'USER'
   and p.page_type_code not in ('subtab', 'tab')
   and p.principal_type = 'SYSTEM'
   and p.page_type_code <> 'template'
union all
select 'Studio > Portlet Pages',
       'Portlet Page',
       'All',
       count(*),
       'select count(*)\n
  from cmn_pages p\n
 where p.principal_type <> ''USER'''
  from cmn_pages p
 where p.principal_type <> 'USER'
union all
select 'Studio > Portlet Pages',
       'Portlet Page',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'PAGE_TYPE_CODE'
           and l.lookup_code = p.page_type_code),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''PAGE_TYPE_CODE''\n
           and l.lookup_code = p.page_type_code) as type,\n
       count(*) as count\n
  from cmn_pages p\n
 where p.principal_type <> ''USER''\n
   and p.page_type_code <> ''subtab''\n
 group by p.page_type_code'
  from cmn_pages p
 where p.principal_type <> 'USER'
   and p.page_type_code <> 'subtab'
 group by p.page_type_code

--Studio > UI Themes
union all
select 'Studio > UI Themes',
       'UI Theme',
       'All',
       count(*),
       'select count(*) from cmn_ui_themes'
  from cmn_ui_themes

--Studio > Views
union all
select 'Studio > Views',
       'View',
       'All',
       count(*),
       'select count(*) from odf_views'
  from odf_views
union all
select 'Studio > Views',
       'View',
       'Type ' || view_type,
       count(*),
       'select view_type,\n
       count(*)\n
  from odf_views\n
 group by view_type'
  from odf_views
 group by view_type



 
--Data Administration > Datamart Settings
union all
select 'Data Administration > Datamart Settings',
       'Datamart Setting',
       'All',
      (select count(*) from (
      select 1 as tmp
        from cmn_options       op,
             cmn_option_values ov
       where ov.option_id = op.id
         and op.option_code in
             ('NBI_CURRENCY_CODE', 'NBI_ENTITY_CODE', 'NBI_EXTRACT_PM_PTFS', 'NBI_EXTRACT_FM_PTFS', 'NBI_EXTRACT_RTFS')
         and not ((op.option_code = 'NBI_CURRENCY_CODE' and ov.value is null) or
              (op.option_code = 'NBI_ENTITY_CODE' and ov.value is null) or
              (op.option_code = 'NBI_EXTRACT_PM_PTFS' and ov.value = 1) or
              (op.option_code = 'NBI_EXTRACT_FM_PTFS' and ov.value = 1) or
              (op.option_code = 'NBI_EXTRACT_RTFS' and ov.value = 1))
      union all
      select 1
        from nbi_cfg_obs_assignments c
       where c.object_type = 'PROJECT'
         and not (c.obs_type_id is null)
      union all
      select 1
        from nbi_cfg_obs_assignments c
       where c.object_type = 'RESOURCE'
         and not (c.obs_type_id is null)
      ) t),
      'select case op.option_code\n
         when ''NBI_CURRENCY_CODE'' then\n
          ''Datamart Currency''\n
         when ''NBI_ENTITY_CODE'' then\n
          ''Datamart Entity''\n
         when ''NBI_EXTRACT_PM_PTFS'' then\n
          ''Extract project management time facts and summary''\n
         when ''NBI_EXTRACT_FM_PTFS'' then\n
          ''Extract financial management time facts and summary''\n
         when ''NBI_EXTRACT_RTFS'' then\n
          ''Extract resource time facts and summary''\n
       end as "name",\n
       ov.value as "value"\n
  from cmn_options       op,\n
       cmn_option_values ov\n
 where ov.option_id = op.id\n
   and op.option_code in\n
       (''NBI_CURRENCY_CODE'', ''NBI_ENTITY_CODE'', ''NBI_EXTRACT_PM_PTFS'', ''NBI_EXTRACT_FM_PTFS'', ''NBI_EXTRACT_RTFS'')\n
   and not ((op.option_code = ''NBI_CURRENCY_CODE'' and ov.value is null) or\n
        (op.option_code = ''NBI_ENTITY_CODE'' and ov.value is null) or\n
        (op.option_code = ''NBI_EXTRACT_PM_PTFS'' and ov.value = 1) or\n
        (op.option_code = ''NBI_EXTRACT_FM_PTFS'' and ov.value = 1) or\n
        (op.option_code = ''NBI_EXTRACT_RTFS'' and ov.value = 1))\n
union all\n
select ''Project Organizational Breakdown Structure Mapping'' as "name",\n
       (select ''OBS : '' || t.unique_name || '' - Default OBS Unit : '' || u.unique_name\n
          from prj_obs_types t,\n
               prj_obs_units u\n
         where u.type_id = t.id\n
           and t.id = c.obs_type_id\n
           and u.id = c.obs_unit_default)\n
  from nbi_cfg_obs_assignments c\n
 where c.object_type = ''PROJECT''\n
   and not (c.obs_type_id is null)\n
union all\n
select ''Resource Organizational Breakdown Structure Mapping'' as "name",\n
       (select ''OBS : '' || t.unique_name + '' - Default OBS Unit : '' || u.unique_name\n
          from prj_obs_types t,\n
               prj_obs_units u\n
         where u.type_id = t.id\n
           and t.id = c.obs_type_id\n
           and u.id = c.obs_unit_default)\n
  from nbi_cfg_obs_assignments c\n
 where c.object_type = ''RESOURCE''\n
   and not (c.obs_type_id is null)\n
 order by "name"'
from dual

--Data Administration > Datamart Stoplights
union all
select 'Data Administration > Datamart Stoplights',
       'Datamart Stoplight',
       'All',
       count(*),
       'select count(*)\n
  from nbi_cfg_stoplight_queries\n
 where redsql is not null'
  from nbi_cfg_stoplight_queries s
 where s.redsql is not null

--Data Administration > Time Slices
union all
select 'Data Administration > Time Slices',
       'Time Slice',
       'All',
       count(*),
       'select count(*)\n
  from prj_blb_slicerequests\n
 where is_visible = 1\n
   and is_template = 0\n
   and is_synchronous = 0'
  from prj_blb_slicerequests
 where is_visible = 1
   and is_template = 0
   and is_synchronous = 0

--Data Administration > Lookups
union all
select 'Data Administration > Lookups',
       'Lookup',
       'Default',
       count(*),
       'select count(*)\n
  from cmn_lookup_types   l,\n
       cmn_list_of_values v\n
 where l.lookup_type = v.lookup_type_code\n
   and l.is_admin_visible = 1\n
   and nvl(v.parent_id, 0) = 0\n
   and l.lookup_type not like ''ODF.NSQL.%''\n
   and l.lookup_type not like ''ODF.OBJECT.%''\n
   and l.lookup_type <> ''REQUIREMENT_PRIORITY'''
  from cmn_lookup_types   l,
       cmn_list_of_values v
 where l.lookup_type = v.lookup_type_code
   and l.is_admin_visible = 1
   and nvl(v.parent_id, 0) = 0
   and l.lookup_type not like 'ODF.NSQL.%'
   and l.lookup_type not like 'ODF.OBJECT.%'
   and l.lookup_type <> 'REQUIREMENT_PRIORITY'
union all
select 'Data Administration > Lookups',
       'Lookup',
       'All',
       count(*),
       'select count(*) from cmn_lookup_types'
  from cmn_lookup_types
union all
select 'Data Administration > Lookups',
       'Lookup',
       'Type ' || (select n1.name
          from cmn_captions_nls n1,
               cmn_lookups      l1
         where n1.pk_id = l1.id
           and n1.language_code = 'en'
           and n1.table_name = 'CMN_LOOKUPS'
           and l1.lookup_type = 'CMN_LOOKUPS_SOURCE'
           and l1.lookup_code = v.lookup_source_code),
       count(*),
       'select count(*)\n
  from cmn_lookup_types   l,\n
       cmn_list_of_values v\n
 where l.lookup_type = v.lookup_type_code\n
 group by v.lookup_source_code'
  from cmn_lookup_types   l,
       cmn_list_of_values v
 where l.lookup_type = v.lookup_type_code
 group by v.lookup_source_code

--Data Administration > Incidents
union all
select 'Data Administration > Incidents',
       'Incident Category',
       'All',
       count(*),
       'select count(*) from imm_categories'
  from imm_categories

--Data Administration > Reports and Jobs
union all
select 'Data Administration > Reports and Jobs',
       'Job',
       'All',
       count(*),
       'select count(*) from cmn_sch_job_definitions'
  from cmn_sch_job_definitions
union all
select 'Data Administration > Reports and Jobs',
       'Job',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'SCH_JOB_TYPE'
           and l.id = j.job_type),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''SCH_JOB_TYPE''\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type'
  from cmn_sch_job_definitions j
 group by j.job_type

--Data Administration > Skills Hierarchy
union all
select 'Data Administration > Skills Hierarchy',
       'Skill',
       'All',
       count(*),
       'select count(*) from rsm_skills'
  from rsm_skills

--Data Administration > Processes
union all
select 'Data Administration > Processes',
       'Process',
       'All',
       count(*),
       'select count(*) from bpm_def_processes'
  from bpm_def_processes p
union all
select 'Data Administration > Processes',
       'Process',
       'Status ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'BPM_PROCESS_USER_STATUS'
           and l.lookup_code = v.user_status_code),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = ''en''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_type = ''BPM_PROCESS_USER_STATUS''\n
           and l.lookup_code = v.user_status_code) as status,\n
       count(*) as count\n
  from bpm_def_process_versions v\n
 group by v.user_status_code'
  from bpm_def_process_versions v
 group by v.user_status_code

--Data Administration > Audit Trail
union all
select 'Data Administration > Audit Trail',
       'Audit Trail',
       'All',
       count(*),
       'select count(*) from cmn_audits'
  from cmn_audits

--Data Administration > Process Engines
union all
select 'Data Administration > Process Engines',
       'Process Engine',
       'All',
       count(*),
       'select count(*) from bpm_run_process_engines'
  from bpm_run_process_engines

--Data Administration > Notifications

  
--Finance > Processing
union all
select 'Finance > Processing',
       'Processing',
       'All',
       (select count(*) from (
        select 1 as tmp
          from cmn_options       op,
               cmn_option_values ov
         where ov.option_id = op.id
           and op.option_code = 'CMN_RETAIN_CURRENCY_PRECISION'
           and not ov.value = '1'
        union all
        select 1
          from cmn_options       op,
               cmn_option_values ov
         where ov.option_id = op.id
           and op.option_code = 'CMN_IS_MULTI_CURRENCY_SYSTEM'
           and not ov.value = '0'
        union all
        select 1
          from nameoptions o
         where not o.allownonchargeableoverride = 1
        union all
        select 1
          from nameoptions o
         where not o.filter_financial_obs = 0
        union all
        select 1
          from nameoptions o
         where not o.entity_security = 0) t),
'select (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''en''\n
           and n.table_name = ''CMN_OPTIONS''\n
           and n.pk_id = op.id) as "name",\n
       to_char(ov.value) as "value"\n
  from cmn_options       op,\n
       cmn_option_values ov\n
 where ov.option_id = op.id\n
   and op.option_code = ''CMN_RETAIN_CURRENCY_PRECISION''\n
   and not ov.value = ''1''\n
union all\n
select ''Use Multi-Currency'' as "name",\n
       to_char(ov.value) as "value"\n
  from cmn_options       op,\n
       cmn_option_values ov\n
 where ov.option_id = op.id\n
   and op.option_code = ''CMN_IS_MULTI_CURRENCY_SYSTEM''\n
   and not ov.value = ''0''\n
union all\n
select ''Allow Chargeable Override'' as "name",\n
       ''<uncheck>'' as "value"\n
  from nameoptions o\n
 where not o.allownonchargeableoverride = 1\n
union all\n
select ''Hide Financial OBS'' as "name",\n
       to_char(o.filter_financial_obs) as "value"\n
  from nameoptions o\n
 where not o.filter_financial_obs = 0\n
union all\n
select ''Entity-based Security'' as "name",\n
       case o.entity_security\n
         when 0 then\n
          ''None''\n
         when 1 then\n
          ''Strict''\n
         when 2 then\n
          ''Parent''\n
       end as "value"\n
  from nameoptions o\n
 where not o.entity_security = 0\n
 order by "name"'
from dual

--Finance > WIP Settings TODO
--Finance > Setup [Defaults] TODO

--Finance > Setup [Entities]
union all
select 'Finance > Setup',
       'Entity',
       'All',
       count(*),
       'select * from entity'
  from entity
union all
select 'Finance > Setup',
       'Fiscal Time Period',
       'All',
       count(*),
'select count(*) from biz_com_periods'
  from biz_com_periods
union all
select 'Finance > Setup',
       'Fiscal Time Period',
       'Entity ' || e.entity,
       count(*),
'select e.entity,\n
       count(*)\n
  from biz_com_periods p,\n
       entity          e\n
 where p.entity_id = e.id\n
 group by e.entity'
  from biz_com_periods p,
       entity          e
 where p.entity_id = e.id
 group by e.entity
union all
select 'Finance > Setup',
       'Fiscal Time Period',
       'Status ' || case
         when is_active = 1 then
          'Active'
         else
          'Inactive'
       end,
       count(*),
       'select case\n
         when is_active = 1 then\n
          ''Active''\n
         else\n
          ''Inactive''\n
       end,\n
       count(*)\n
  from biz_com_periods\n
 group by is_active'
  from biz_com_periods
 group by is_active

--Finance > Setup [Locations]
union all
select 'Finance > Setup',
       'Location',
       'All',
       count(*),
       'select count(*) from locations'
  from locations
union all
select 'Finance > Setup',
       'Location',
       'Entity ' || (select e.shortdesc from entity e where id = l.entity_id),
       count(*),
       'select (select e.shortdesc from entity e where id = l.entity_id),\n
       count(*)\n
  from locations l\n
 group by l.entity_id'
  from locations l
 group by l.entity_id

--Finance > Setup [Vendors]
union all
select 'Finance > Setup',
       'Vendor',
       'All',
       count(*),
       'select count(*) from apmaster'
  from apmaster

--Finance > Setup [Currency]
union all
select 'Finance > Setup',
       'Currency',
       'All',
       count(*),
       'select count(*) from cmn_currencies'
  from cmn_currencies
union all
select 'Finance > Setup',
       'Currency',
       'Status ' || case
         when is_active = 1 then
          'Active'
         else
          'Inactive'
       end,
       count(*),
       'select case\n
         when is_active = 1 then\n
          ''Active''\n
         else\n
          ''Inactive''\n
       end,\n
       count(*)\n
  from cmn_currencies\n
 group by is_active'
  from cmn_currencies
 group by is_active

--Finance > Setup [Foreign Exchange Rates]
union all
select 'Finance > Setup',
       'Foreign Exchange Rate',
       'All',
       count(*),
       'select count(*) from cmn_exchange_rates'
  from cmn_exchange_rates

--Finance > Setup [Resource Classes]
union all
select 'Finance > Setup',
       'Resource Class',
       'All',
       count(*),
       'select count(*) from pac_fos_resource_class'
  from pac_fos_resource_class
union all
select 'Finance > Setup',
       'Resource Class',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'RPT_TRANSACTION_TYPE'
           and l.lookup_code = c.resource_type),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''RPT_TRANSACTION_TYPE''\n
           and l.lookup_code = c.resource_type) as type,\n
       count(*) as count\n
  from pac_fos_resource_class c\n
 group by c.resource_type'
  from pac_fos_resource_class c
 group by c.resource_type

--Finance > Setup [Company Classes]
union all
select 'Finance > Setup',
       'Company Class',
       'All',
       count(*),
       'select count(*) from clntclass'
  from clntclass

--Finance > Setup [Work in Process Classes]
union all
select 'Finance > Setup',
       'WIP Class',
       'All',
       count(*),
       'select count(*) from wipclass'
  from wipclass

--Finance > Setup [Investment Classes]
union all
select 'Finance > Setup',
       'Investment Class',
       'All',
       count(*),
       'select count(*) from projclass'      
  from projclass

--Finance > Setup [Transaction Classes]
union all
select 'Finance > Setup',
       'Transaction Class',
       'All',
       count(*),
       'select count(*) from transclass'
  from transclass
union all
select 'Finance > Setup',
       'Transaction Class',
       'Type ' || (select n.name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'PAC_TRANSACTION_TYPE'
           and l.lookup_code = c.transtype),
       count(*),
       'select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and n.language_code = ''en''\n
           and l.lookup_type = ''PAC_TRANSACTION_TYPE''\n
           and l.lookup_code = c.transtype) as type,\n
       count(*) as count\n
  from transclass c\n
 group by c.transtype'
  from transclass c
 group by c.transtype

--Finance > Cost Plus Codes
union all
select 'Finance > Cost Plus Codes',
       'Cost Plus Code',
       'All',
       count(*),
       'select count(*) from costplus'
  from costplus

--Finance > Manage Matrix
union all
select 'Finance > Manage Matrix',
       'Matrix',
       'Default',
       count(*),
       'select count(*)\n
  from ppa_matrix\n
 where not matrixkey = 1'
  from ppa_matrix
 where not matrixkey = 1
union all
select 'Finance > Manage Matrix',
       'Matrix',
       'All',
       count(*),
       'select count(*) from ppa_matrix'
  from ppa_matrix

--Finance > GL Accounts
union all
select 'Finance > GL Accounts',
       'GL Account',
       'All',
       count(*),
       'select count(*) from cbk_gl_account'
  from cbk_gl_account

--Chargebacks > Standard Rules
union all
select 'Chargebacks > Standard Rules',
       'Standard Rule',
       'All',
       count(*),
       'select count(*)\n
  from cbk_gl_allocation r\n
 where r.chargeback_type = ''DEBIT''\n
   and r.chargeback_subtype = ''STANDARD'''
  from cbk_gl_allocation r
 where r.chargeback_type = 'DEBIT'
   and r.chargeback_subtype = 'STANDARD'

--Chargebacks > Overhead Rules
union all
select 'Chargebacks > Overhead Rules',
       'Overhead Rule',
       'All',
       count(*),
       'select count(*)\n
  from cbk_gl_allocation r\n
 where r.chargeback_type = ''DEBIT''\n
   and r.chargeback_subtype = ''OVERHEAD'''
  from cbk_gl_allocation r
 where r.chargeback_type = 'DEBIT'
   and r.chargeback_subtype = 'OVERHEAD'

--Chargebacks > Credit Rules
union all
select 'Chargebacks > Credit Rules',
       'Credit Rule',
       'All',
       count(*),
       'select count(*)\n
  from cbk_gl_allocation r\n
 where r.chargeback_type = ''DEBIT'''
  from cbk_gl_allocation r
 where r.chargeback_type = 'CREDIT'

--Chargebacks > Messages
union all
select 'Chargebacks > Messages',
       'Message',
       'All',
       count(*),
       'select count(*) from cbk_errors'
  from cbk_errors

--Project Management > Timesheet Options TODO

--Project Management > Time Reporting Periods
union all
select 'Project Management > Time Reporting Periods',
       'Time Reporting Period',
       'All',
       count(*),
       'select count(*) from prtimeperiod'
  from prtimeperiod
union all
select 'Project Management > Time Reporting Periods',
       'Time Reporting Period',
       case
         when prisopen = 1 then
          'Open'
         else
          'Closed'
       end,
       count(*),
       'select count(*)\n
  from prtimeperiod\n
 group by prisopen'
  from prtimeperiod
 group by prisopen

--Project Management > Charge Codes
union all
select 'Project Management > Charge Codes',
       'Charge Code',
       'All',
       count(*),
       'select count(*) from prchargecode'
  from prchargecode

--Project Management > Input Type Codes
union all
select 'Project Management > Input Type Codes',
       'Input Type Code',
       'All',      
       count(*),
       'select count(*) from prtypecode'
  from prtypecode

--Project Management > Invalid Transactions
union all
select 'Project Management > Invalid Transactions',
       'Invalid Transaction',
       'All',
       count(*),
       'select count(*)\n
  from imp_transactionimport\n
 where importstatus = ''E'''
  from imp_transactionimport
 where importstatus = 'E'

--Project Management > Settings TODO

--Project Management > Base Calendars
union all
select 'Project Management > Base Calendars',
       'Base Calendar',
       'Default',
       count(*),
       'select count(*)\n
  from prcalendar\n
 where prresourceid is null'
  from prcalendar
 where prresourceid is null
union all
select 'Project Management > Base Calendars',
       'Base Calendar',
       'All',
       count(*),
       'select count(*) from prcalendar'
  from prcalendar
 
--Project Management > Migrate Methods TODO
--Project Management > Risk Settings TODO
--Project Management > MSP Field Mappings TODO

--General Settings > System Options


--General Settings > Site Links
union all
select 'General Settings > Site Links',
       'Site Link',
       'All',
       count(*),
       'select * from prlink l where l.prtablename = ''PRSite'''
  from prlink
 where prtablename = 'PRSite'

--Earned Value Management > Period Definitions
union all
select 'Earned Value Management > Period Definitions',
       'EV Period',
       'All',
       count(*),
       'select * from evm_period_defs'
  from evm_period_defs

 ) t
         


              