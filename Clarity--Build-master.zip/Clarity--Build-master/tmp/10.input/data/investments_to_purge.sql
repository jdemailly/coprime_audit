
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Investments' as "name",
         'Shows investments with the mark for deletion flag' as "description",
         'Run Job Delete Investments or deactivate the purge flag' as "action",
         'begin\n
\tupdate inv_investments i set i.purge_flag = 0 where i.purge_flag = 1;\n
\tcommit;\n
end;' as "script",
         'Code' as "th1",
         'Type' as "th2",
         'Name' as "th3",
         'Active' as "th4",
         'Progress' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "type", "name", "is_active", "progress"))))
       .getclobval()
from (


         
select i.code as "code",
       i.odf_object_code as "type",
       i.name as "name",
       i.is_active as "is_active",
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'INVESTMENT_OBJ_PROGRESS'
           and l.lookup_enum = i.progress) as "progress"
  from inv_investments i
 where i.purge_flag = 1


order by i.code)


              