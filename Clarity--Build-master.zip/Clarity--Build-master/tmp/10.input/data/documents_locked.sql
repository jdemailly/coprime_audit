
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Documents' as "name",
         'Shows locked documents' as "description",
         'begin\n
  dbms_output.put_line(''Updating clb_dms_files table...'');\n
  update clb_dms_files f set f.lock_owner_id = null, f.lock_time_stamp = null where f.lock_owner_id <> 0;\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;' as "script",
         'Run custom script to remove locks' as "action",
         'Name' as "th1",
         'Mime Type' as "th2",
         'Since' as "th3",
         'By' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest(name, mime_type, lock_time_stamp, lock_by))))
       .getclobval()
from (



select f.name                  as name,
       nvl(f.mime_type, ' ') as mime_type,
       f.lock_time_stamp       as lock_time_stamp,
       r.full_name             as lock_by
  from clb_dms_files f
 inner join srm_resources r on r.user_id = f.lock_owner_id
 where f.lock_owner_id <> 0


order by f.name)


              