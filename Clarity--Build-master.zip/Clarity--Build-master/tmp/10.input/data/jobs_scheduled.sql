
                

select xmlelement(name "QueryResult",
       xmlattributes(
       '46' as "order",
       'Jobs' as "name",
		   'Scheduled Jobs' as "description",
		   'Name' as "th1",
	     'Start Date' as "th2",
       'Visible' as "th3",
	     'Job Code' as "th4",
	     'Job Name' as "th5",
	     'Crontab' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "start_date", "is_visible", "job_code", "job_name", "crontab"))))
       .getclobval()
from (



--Main
select j.name as "name",
       j.start_date as "start_date",
       d.job_code as "job_code",
       n.name as "job_name",
       j.is_visible as "is_visible",
       nvl(j.minutes, '*') || ' ' || nvl(j.hours, '*') || ' ' || nvl(j.days_of_month, '*') || ' ' || nvl(j.months, '*') || ' ' || nvl(j.days_of_week, '*') as "crontab"
  from cmn_sch_jobs j
 inner join cmn_sch_job_definitions d on d.id = j.job_definition_id
 inner join cmn_captions_nls n on n.pk_id = d.id
                              and n.table_name = 'CMN_SCH_JOB_DEFINITIONS'
                              and n.language_code = 'en'
 where j.status_code = 'SCHEDULED'

)


              