
                

select xmlelement(name "QueryResult",
       xmlattributes(
       '45' as "order",
       'Jobs' as "name",
		   'Scheduled Jobs with quotes in their name' as "description",
		   'Rename Job Name to remove quote' as "action",
	     'Name' as "th1",
	     'Code' as "th2",
	     'Type Code' as "th3",
	     'Type Name' as "th4",
	     'Flag' as "th5",
	     'Script' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "code", "type_code", "type_name", "flag", "script"))))
       .getclobval()
from (



--Main
select j.name as "name",
       d.job_code as "code",
       d.job_type as "type_code",
       (select l.lookup_code
          from cmn_lookups l
         where l.lookup_type = 'SCH_JOB_TYPE'
           and l.id = d.job_type) as "type_name",
       'NOK' as "flag",
       'begin\n\tupdate cmn_sch_jobs set name = replace(name, '''''', '' '') where j.id = ' || j.id || ';\nend;' as "script"
       
  from cmn_sch_jobs j
 inner join cmn_sch_job_definitions d on d.id = j.job_definition_id
 where j.status_code = 'SCHEDULED'
   and j.name like '%''%'

)


              