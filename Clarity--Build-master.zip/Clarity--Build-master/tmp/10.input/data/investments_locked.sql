
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '42' as "order",
         'Investments' as "name",
         'Shows locked investments' as "description",
         'begin\n
  dbms_output.put_line(''Deleting from prlock table...'');\n
  delete from prlock where prtablename = ''SRM_PROJECTS'';\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;' as "script",
         'Run custom script to remove locks' as "action",
         'Code' as "th1",
         'Name' as "th2",
         'Type' as "th3",
         'Since' as "th4",
         'Progress' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "type", "since", "progress"))))
       .getclobval()
from (


         
select i.code as "code",
       i.name as "name",
       i.odf_object_code as "type",
       l.prlockedsince as "since",
       (select name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = 'en'
           and l.lookup_type = 'INVESTMENT_OBJ_PROGRESS'
           and l.lookup_enum = i.progress) as "progress"
  from prlock          l,
       inv_investments i
 where l.prrecordid = i.id
   and l.prtablename = 'SRM_PROJECTS'


order by i.code)


              