
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '41' as "order",
         'Resources' as "name",
         'Detect Resources financially active and with no Transaction Class or Resource Class' as "description",
         'For each resource, change their financial properties and add Resource Class / Transaction Class' as "action",
         'ID' as "th1",
         'Code' as "th2",
         'Name' as "th3"),
       xmlagg(xmlelement(name "Record", xmlforest("id", "code", "name"))))
       .getclobval()
from (


   
--Select
select r.id          as "id",
       r.unique_name as "code",
       r.full_name   as "name"
  from srm_resources r
 inner join pac_mnt_resources f on f.id = r.id
 where f.active = 1
   and (f.resource_class is null or f.transclass is null)

)

              