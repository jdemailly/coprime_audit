
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '29' as "order",
         'Oracle' as "name",
         'Count Oracle Objects by Type' as "description",
         'Type' as "th1",
         'Count' as "th2"),
       xmlagg(xmlelement(name "Record", xmlforest("type", "count"))))
       .getclobval()
from (

select o.object_type as "type",
       count(*) as "count"
  from user_objects o
 group by o.object_type
 order by o.object_type

)



              