
                


select xmlelement(name "QueryResult",
  xmlattributes(
    '23' as "order",
    'Oracle' as "name",
    'User Tablespaces' as "description",
    'Check that Tablespaces are autoextensible' as "action",
    '--Auto Extend On\n
select ''alter database datafile '''''' || file_name || '''''' autoextend on maxsize unlimited;'' as script from dba_data_files;\n
select ''alter database tempfile '''''' || file_name || '''''' autoextend on maxsize unlimited;'' as script from dba_temp_files;' as "script",
    'Name' as "th1",
    'Max Extents (MO)' as "th2",
    'Big File' as "th3",
    'Segment Space Management' as "th4",
    'Default Tab Compression' as "th5"),
    xmlagg(xmlelement(name "Record", xmlforest(name, max_extents_mo, bigfile, segment_space_management, def_tab_compression))))
       .getclobval()
from (

--Select
select t.tablespace_name as name,
       round(t.max_extents / (1024 * 1024), 2) as max_extents_mo,
       t.bigfile as bigfile,
       t.segment_space_management,
       t.def_tab_compression
  from user_tablespaces t

)

              