
                

select xmlelement(name "QueryResult",
       xmlattributes(
       '25' as "order",
       'Oracle' as "name",
       'Table records with primary or foreign key null' as "description",
       'Delete row' as "action",
       'Table' as "th1",
       'Columns' as "th2",
       'Count' as "th3",
       'Flag' as "th4",
       'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "column", "count", "flag", "script"))))
       .getclobval()
from (

select t.*
  from (select 'PRTIMEENTRY' as "name",
               'PRID' as "column",
               count(*) as "count",
               'NOK' as "flag",
               'begin\n\tdbms_output.put_line(''Deleting records with no primary key in prtimeentry.'');\n\tdelete from prtimeentry where prid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;' as "script"
          from prtimeentry e
         where e.prid is null
        union all
        select 'PRTIMESHEET',
               'PRRESOURCEID',
               count(*),
               'NOK',
               'begin\n\tdbms_output.put_line(''Deleting records with no foreign key prresourceid in prtimesheet.'');\n\tdelete from prtimesheet where prresourceid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;'
          from prtimesheet t
         where t.prresourceid is null
        union all
        select 'PRTIMESHEET',
               'PRTIMEPERIODID',
               count(*),
               'NOK',
               'begin\n\tdbms_output.put_line(''Deleting records with no foreign key prtimeperiodid in prtimesheet.'');\n\tdelete from prtimesheet where prtimeperiodid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;' as "script"
          from prtimesheet t
         where t.prtimeperiodid is null
        union all
        select 'PRCALENDAR',
               'PRID',
               count(*),
               'NOK',
               'begin\n\tdbms_output.put_line(''Deleting records with no primary key in prcalendar.'');\n\tdelete from prcalendar where prid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;'
          from prcalendar c
         where c.prid is null
        union all
        select 'PRTASK',
               'PRPROJECTID',
               count(*),
               'WARN',
               'begin\n\tdbms_output.put_line(''Deleting records with foreign key prprojectid null in prtask.'');\n\tdelete from prtask where prprojectid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;'
          from prtask t
         where t.prprojectid is null
         ) t
 where t."count" > 0

)



              