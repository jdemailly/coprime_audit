
                


select xmlelement(name "QueryResult",
      xmlattributes(
        '21' as "order",
        'Oracle' as "name",
        'Oracle Prerequisites for Clarity' as "description",
        'Check each NOK prerequisite and apply given SQL script' as "action",
        'Rule' as "th1",
        'Flag' as "th2",
        'Script' as "th3"),
      xmlagg(xmlelement(name "Record", xmlforest("rule", "flag", "script"))))
       .getclobval()
from (

with

--Clarity Version on 3 Digits
version as
 (select to_number(substr(replace(installed_version, '.', ''), 1, 3)) as version
    from (select installed_version
            from cmn_install_history
           where install_id in ('database', 'release_version')
           order by installed_date desc)
   where rownum = 1)
  
--Database Character Set must be UTF8 12.1-
select 'Database Character Set must be UTF8 until 12.1' || decode(p.value, 'UTF8', '', ' (Actual = ' || p.value || ')') as "rule",
       decode(p.value, 'UTF8', 'OK', 'WARN') as "flag",
       'Reinstall Oracle Instance' as "script"
  from version v,
       nls_database_parameters p
 where p.parameter = 'NLS_CHARACTERSET'
   and v.version < 130

--Database Character Set must be AL32UTF8 13.0+
union all
select 'Database Character Set must be AL32UTF8 since 13.0' || decode(p.value, 'AL32UTF8', '', ' (Actual = ' || p.value || ')') as "rule",
       decode(p.value, 'AL32UTF8', 'OK', 'WARN') as "flag",
       'Reinstall Oracle Instance' as "script"
  from version v,
       nls_database_parameters p
 where p.parameter = 'NLS_CHARACTERSET'
   and v.version >= 130
  
--Database National Character Set must be UTF8/AL16UTF16
union all
select 'Database National Character Set must be UTF8/AL16UTF16' || decode(p.value, 'UTF8', '', 'AL16UTF16', '', ' (Actual = ' || p.value || ')'),
       decode(p.value, 'UTF8', 'OK', 'AL16UTF16', 'OK', 'WARN'),
       'Reinstall Oracle Instance'
  from nls_database_parameters p
 where p.parameter = 'NLS_NCHAR_CHARACTERSET'

--Instance Database Parameter NLS_SORT must be BINARY
union all
select 'Instance Database Parameter NLS_SORT must be BINARY' || decode(upper(p.value), 'BINARY', '', ' (Actual = ' || p.value || ')'),
       decode(upper(p.value), 'BINARY', 'OK', 'NOK'),
       'alter system set nls_sort = binary scope = spfile;'
  from nls_instance_parameters p
 where p.parameter = 'NLS_SORT'

--Instance Database Parameter NLS_COMP must be BINARY
union all
select 'Instance Database Parameter NLS_COMP must be BINARY' || decode(upper(p.value), 'BINARY', '', ' (Actual = ' || p.value || ')'),
       decode(upper(p.value), 'BINARY', 'OK', 'NOK'),
       'alter system set nls_comp = binary scope = spfile;'
  from nls_instance_parameters p
 where p.parameter = 'NLS_COMP'

--Instance Database Parameter NLS_DATE_FORMAT must be YYYY-MM-DD HH24:MI:SS
union all
select 'Instance Database Parameter NLS_DATE_FORMAT must be ''YYYY-MM-DD HH24:MI:SS''' || decode(p.value, 'YYYY-MM-DD HH24:MI:SS', '', ' (Actual = ' || p.value || ')'),
       decode(p.value, 'YYYY-MM-DD HH24:MI:SS', 'OK', 'NOK'),
       'alter system set nls_date_format = ''YYYY-MM-DD HH24:MI:SS'' scope = spfile;'
  from nls_instance_parameters p
 where p.parameter = 'NLS_DATE_FORMAT'

--User must have privilege ALTER SESSION since 13.0
union all
select 'User ' || user || ' must have privilege ALTER SESSION since 13.0',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'ALTER SESSION') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'ALTER SESSION') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 130 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant alter session to ' || user || ';'
  from version v
 
--User must have privilege CREATE SESSION
union all
select 'User ' || user || ' must have privilege CREATE SESSION',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE SESSION') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE SESSION') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 130 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant create session to ' || user || ';'
  from version v
 
--User must have privilege CREATE TABLE
union all
select 'User ' || user || ' must have privilege CREATE TABLE',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE TABLE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE TABLE') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant create table to ' || user || ';'
  from dual
 
--User must have privilege CREATE PROCEDURE since 13.2
union all
select 'User ' || user || ' must have privilege CREATE PROCEDURE since 13.2',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE PROCEDURE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE PROCEDURE') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 132 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant create procedure to ' || user || ';'
  from version v
 
--User must have privilege CREATE JOB since 14.2
union all
select 'User ' || user || ' must have privilege CREATE JOB since 14.2',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE JOB') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE JOB') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 142 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant create job to ' || user || ';'
  from version v
 
--User must have privilege CREATE TRIGGER
union all
select 'User ' || user || ' must have privilege CREATE TRIGGER',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE TRIGGER') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE TRIGGER') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant create trigger to ' || user || ';'
  from dual

--User must have privilege CREATE VIEW
union all
select 'User ' || user || ' must have privilege CREATE VIEW',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE VIEW') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE VIEW') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant create view to ' || user || ';'
  from dual

--User must have privilege QUERY REWRITE
union all
select 'User ' || user || ' must have privilege QUERY REWRITE',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'QUERY REWRITE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'QUERY REWRITE') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant query rewrite to ' || user || ';'
  from dual

--User must have privilege UNLIMITED TABLESPACE
union all
select 'User ' || user || ' must have privilege UNLIMITED TABLESPACE',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'UNLIMITED TABLESPACE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'UNLIMITED TABLESPACE') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant unlimited tablespace to ' || user || ';'
  from dual

--User must have role CONNECT
union all
select 'User ' || user || ' must have role CONNECT',
       decode(count(*), 1, 'OK', 'NOK'),
       'grant connect to ' || user || ';'
  from user_role_privs r
 where r.granted_role = 'CONNECT'

--User must have role RESOURCE
union all
select 'User ' || user || ' must have role RESOURCE',
       decode(count(*), 1, 'OK', 'NOK'),
       'grant resource to ' || user || ';'
  from user_role_privs r
 where r.granted_role = 'RESOURCE'

--Statistics must be Gathered if older than 15 days
union all
select 'Statistics must be Gathered if older than 15 days',
       case
         when trunc(sysdate) - 15 > trunc(min(last_analyzed)) then
          'NOK'
         else
          'OK'
       end,
       'begin\n\tcmn_job_analyze_sp(p_job_run_id => 1, p_job_user_id => 1, p_db_schema => user);\nend;'
  from (select min(t.last_analyzed) as last_analyzed
          from user_tables t
        union all
        select min(last_analyzed)
          from user_tab_partitions
        union all
        select min(last_analyzed)
          from user_tab_subpartitions
        union all
        select min(last_analyzed)
          from user_indexes
        union all
        select min(last_analyzed)
          from user_ind_partitions
        union all
        select min(last_analyzed)
          from user_ind_subpartitions)

--Parameter QUERY_REWRITE_ENABLED must be Set to True
union all
select 'Parameter QUERY_REWRITE_ENABLED must be Set to True',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''QUERY_REWRITE_ENABLED'', i, s);\n
  dbms_output.put_line(''QUERY_REWRITE_ENABLED : '' || s);\n
end;\n
\n
alter system set query_rewrite_enabled = true scope = spfile;'
  from dual

--Parameter CURSOR_SHARING must be Set to FORCE
union all
select 'Parameter CURSOR_SHARING must be Set to FORCE',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''CURSOR_SHARING'', i, s);\n
  dbms_output.put_line(''CURSOR_SHARING : '' || s);\n
end;\n
\n
alter system set cursor_sharing = FORCE scope = spfile;'
  from dual

--Parameter _B_TREE_BITMAP_PLANS must be Set to False
union all
select 'Parameter _B_TREE_BITMAP_PLANS must be Set to False',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''_B_TREE_BITMAP_PLANS'', i, s);\n
  dbms_output.put_line(''_B_TREE_BITMAP_PLANS : '' || i);\n
end;\n
\n
alter system set "_b_tree_bitmap_plans" = false scope = spfile;'
  from dual

--Parameter OPTIMIZER_MODE must be Set to ALL_ROWS
union all
select 'Parameter OPTIMIZER_MODE must be Set to ALL_ROWS',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''OPTIMIZER_MODE'', i, s);\n
  dbms_output.put_line(''OPTIMIZER_MODE : '' || s);\n
end;\n
\n
alter system set optimizer_mode = ALL_ROWS scope = spfile;'
  from dual
         
)



              