
                


select xmlelement(name "QueryResult",
  xmlattributes(
    '24' as "order",
    'Oracle' as "name",
    'NLS Parameters (Database, Instance, Session)' as "description",
    'Name' as "th1",
    'Database' as "th2",
    'Instance' as "th3",
    'Session' as "th4",
    'Script' as "th5"),
    xmlagg(xmlelement(name "Record", xmlforest("param", "database", "instance", "session", "script"))))
       .getclobval()
from (

with

--NLS Parameters
params as
 (select parameter as parameter
    from nls_database_parameters
  union
  select parameter
    from nls_instance_parameters
  union
  select parameter
    from nls_session_parameters)

--Select
select p.parameter as "param",
       nvl(d.value, ' ') as "database",
       nvl(i.value, ' ') as "instance",
       nvl(s.value, ' ') as "session",
       'alter system set ' || p.parameter || ' = ''' || nvl(i.value, d.value) || ''' scope = spfile;' as "script"
  from params p
  left join nls_database_parameters d on d.parameter = p.parameter
  left join nls_instance_parameters i on i.parameter = p.parameter
  left join nls_session_parameters s on s.parameter = p.parameter

)

              