
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Time Slice' as "name",
         'Detects duplicates in time slices' as "description",
         'Remove Duplicates in Queries and SQL Objects' as "action",
         'Slice' as "th01",
         'Field' as "th02",
         'Period' as "th03",
         'Rollover' as "th04",
         'From' as "th05",
         'To' as "th06",
         'Number' as "th07",
         'Count' as "th08",
         'Percent' as "th09",
         'Flag' as "th10"),
       xmlagg(xmlelement(name "Record", xmlforest("request_name", "field", "period", "frequency", "from_date", "to_date", "num_periods", "count", "percent", "flag"))))
       .getclobval()
from (
      
with

--Time Slices Duplicates
prj_blb_slicerequests_dup as
 (select r.field,
         r.period,
         r.table_name
    from prj_blb_slicerequests r
   group by field,
            period,
            table_name
  having count(*) > 1),

--Slice Field
blb_slice_item as
 (select l.lookup_enum as code,
         n.name        as name
    from cmn_captions_nls n
   inner join cmn_lookups l on l.id = n.pk_id
                           and n.language_code = 'en'
                           and n.table_name = 'CMN_LOOKUPS'
   where l.lookup_type = 'BLB_SLICE_ITEM'),

--Slice Period
blb_slice_period as
 (select l.lookup_enum as code,
         n.name        as name
    from cmn_captions_nls n
   inner join cmn_lookups l on l.id = n.pk_id
                           and n.language_code = 'en'
                           and n.table_name = 'CMN_LOOKUPS'
   where l.lookup_type = 'BLB_SLICE_PERIOD')

--Select
select request_name as "request_name",
       f.name as "field",
       p.name as "period",
       fr.name as "frequency",
       sr.from_date as "from_date",
       sr.to_date as "to_date",
       sr.num_periods as "num_periods",
       (select count(*) from prj_blb_slices s where s.slice_request_id = sr.id) as "count",
       round((select count(*) from prj_blb_slices s where s.slice_request_id = sr.id) * 100 /
             (select count(*) from prj_blb_slices),
             2) as "percent",
       'WARN' as "flag"
  from prj_blb_slicerequests sr
 inner join prj_blb_slicerequests_dup d on d.field = sr.field
                                       and d.period = sr.period
                                       and d.table_name = sr.table_name
 inner join blb_slice_item f on f.code = sr.field
 inner join blb_slice_period p on p.code = sr.period
 inner join blb_slice_period fr on fr.code = sr.frequency
 order by sr.field,
          sr.period

)


              