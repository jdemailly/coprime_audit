
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '42' as "order",
         'Time Slice' as "name",
         'Detect Objects that are being sliced' as "description",
         'Wait for Time Slicing Job to end or apply given script to reset slices' as "action",
         'Object' as "th1",
         'Count' as "th2",
         'Flag' as "th3",
         'Script' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest("object", "count", "flag", "script"))))
       .getclobval()
from (


         
select "object",
       "count",
       'WARN' as "flag",
       "script"
  from (
 
      --Project
      select 'INV_INVESTMENTS' as "object",
               count(*) as "count",
               'begin\n\tupdate inv_investments set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;' as "script"
          from inv_investments
         where nvl(slice_status, 0) > 0
        union all
        select 'PRTEAM',
               count(*),
               'begin\n\tupdate prteam set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'            
          from prteam
         where nvl(slice_status, 0) > 0
        union all
        select 'PRASSIGNMENT',
               count(*),
               'begin\n\tupdate prassignment set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'  
          from prassignment
         where nvl(slice_status, 0) > 0
        union all
        select 'CAP_SCENARIO_ASSIGNMENTS',
               count(*),
               'begin\n\tupdate cap_scenario_assignments set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from cap_scenario_assignments
         where nvl(slice_status, 0) > 0
        union all
        select 'CAP_SCENARIO_TASKS',
               count(*),
               'begin\n\tupdate cap_scenario_tasks set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from cap_scenario_tasks
         where nvl(slice_status, 0) > 0
        union all
        select 'CAP_SCENARIO_TEAM',
               count(*),
               'begin\n\tupdate cap_scenario_team set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from cap_scenario_team
         where nvl(slice_status, 0) > 0
        union all
        select 'PRJ_BASELINES',
               count(*),
               'begin\n\tupdate prj_baselines set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from prj_baselines
         where nvl(slice_status, 0) > 0
        union all
        select 'PRJ_BASELINE_DETAILS',
               count(*),
               'begin\n\tupdate prj_baseline_details set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from prj_baseline_details d,
               prj_baselines        b
         where d.baseline_id = b.id
           and nvl(d.slice_status, 0) > 0
           and nvl(b.slice_status, 0) > 0
        union all
        select 'PRJ_TENTATIVE_ASSIGNMENTS',
               count(*),
               'begin\n\tupdate prj_tentative_assignments set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from prj_tentative_assignments
         where nvl(slice_status, 0) > 0
        --Resources
        union all
        select 'PRTIMEENTRY',
               count(*),
               'begin\n\tupdate prtimeentry set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from prtimeentry
         where nvl(slice_status, 0) > 0
        union all
        select 'RSM_REQ_REQUISITIONS',
               count(*),
               'begin\n\tupdate rsm_req_requisitions set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from rsm_req_requisitions
         where nvl(slice_status, 0) > 0
        union all
        select 'SRM_RESOURCES',
               count(*),
               'begin\n\tupdate srm_resources set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from srm_resources
         where nvl(slice_status, 0) > 0
        union all
        select 'PRJ_RESOURCES',
               count(*),
               'begin\n\tupdate prj_resources set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from prj_resources
         where nvl(slice_status, 0) > 0
        union all
        select 'PRCALENDAR',
               count(*),
               'begin\n\tupdate prcalendar set slice_status = null where nvl(slice_status, 0) > 0;\n\tcommit;\nend;'
          from prcalendar
         where nvl(slice_status, 0) > 0) t
 where "count" > 0

order by "count" desc)

              