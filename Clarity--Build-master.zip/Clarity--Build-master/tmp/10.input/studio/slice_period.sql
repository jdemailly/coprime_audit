
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '44' as "order",
         'Time Slice' as "name",
         'Detects Time Slices with 0 Period' as "description",
         'Set at Least 1 Period' as "action",
         'Slice' as "th01",
         'Field' as "th02",
         'Period' as "th03",
         'Rollover' as "th04",
         'From' as "th05",
         'To' as "th06",
         'Flag' as "th07"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "field", "period", "frequency", "from_date", "to_date", "flag"))))
       .getclobval()
from (


         
select r.request_name as "name",
       nf.name        as "field",
       np.name        as "period",
       nr.name        as "frequency",
       r.from_date    as "from_date",
       r.to_date      as "to_date",
       'NOK'          as "flag"
  from prj_blb_slicerequests r
--Field : Lookup BLB_SLICE_ITEM
 inner join cmn_lookups lf on lf.lookup_enum = r.field
                          and lf.lookup_type = 'BLB_SLICE_ITEM'
 inner join cmn_captions_nls nf on nf.pk_id = lf.id
                               and nf.language_code = 'en'
                               and nf.table_name = 'CMN_LOOKUPS'
--Period : Lookup BLB_SLICE_PERIOD
 inner join cmn_lookups lp on lp.lookup_enum = r.period
                          and lp.lookup_type = 'BLB_SLICE_PERIOD'
 inner join cmn_captions_nls np on np.pk_id = lp.id
                               and np.language_code = 'en'
                               and np.table_name = 'CMN_LOOKUPS'
--Frequency : Lookup BLB_SLICE_PERIOD
 inner join cmn_lookups lr on lr.lookup_enum = r.frequency
                          and lr.lookup_type = 'BLB_SLICE_PERIOD'
 inner join cmn_captions_nls nr on nr.pk_id = lr.id
                               and nr.language_code = 'en'
                               and nr.table_name = 'CMN_LOOKUPS'
 where r.num_periods = 0

  order by r.request_name)



              