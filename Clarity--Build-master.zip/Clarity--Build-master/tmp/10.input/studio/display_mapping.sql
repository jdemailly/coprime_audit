
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '51' as "order",
         'Studio' as "name",
         'Detect Display Mapping with no Mappings' as "description",
         'Run Script' as "action",
         'begin\n
  delete from odf_display_mappings d\n
   where not exists (select 1 from odf_mappings m where m.display_mappings_id = d.id);\n
  commit;\n
end;' as "script",
         'Type' as "th1",
         'Object Code' as "th2",
         'Object Name' as "th3",
         'Attribute Code' as "th4",
         'Attribute Name' as "th5",
         'Logo' as "th6",
         'Flag' as "th7"),
       	xmlagg(xmlelement(name "Record", xmlforest("type", "object_code", "object_name", "attribute_code", "attribute_name", "logo", "flag"))))
       .getclobval()
from (



--Main
select d.target_type as "type",
       d.object as "object_code",
       nvl((select n.name
          from cmn_captions_nls n,
               odf_objects      o
         where n.pk_id = o.id
           and n.table_name = 'ODF_OBJECTS'
           and n.language_code = 'en'
           and o.code = d.object), ' ') as "object_name",
       d.attribute as "attribute_code",
       nvl((select n.name
          from cmn_captions_nls      n,
               odf_custom_attributes a
         where n.pk_id = a.id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = 'en'
           and a.object_name = d.object
           and a.internal_name = d.attribute), ' ') as "attribute_name",
       d.type as "logo",
       'WARN' as "flag"
  from odf_display_mappings d
 where not exists (select 1 from odf_mappings m where m.display_mappings_id = d.id)

)


              