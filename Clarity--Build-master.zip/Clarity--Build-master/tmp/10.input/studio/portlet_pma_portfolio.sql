
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '52' as "order",
         'Studio' as "name",
         'Detect PMA_PORTFOLIO portlets which are Removed in 13.2' as "description",
         'XOG Out Portlets in Previous Environment\nMake Changes for PFM_PORTFOLIO\nXOG In Portlets in New Environment' as "action",
         'Code' as "th1",
         'Name' as "th2",
         'Type' as "th3",
         'Dal Type' as "th4",
         'Query Code' as "th5",
         'Flag' as "th6"),
       	xmlagg(xmlelement(name "Record", xmlforest("code", "name", "type", "dal_type", "query_code", "flag"))))
       .getclobval()
from (



--Select
select p.portlet_code as "code",
       (select name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.language_code = 'en'
           and n.table_name = 'CMN_PORTLETS') as "name",
       p.portlet_type_code as "type",
       nvl(g.dal_type, ' ') as "dal_type",
       nvl(q.query_code, ' ') as "query_code",
       'WARN' as "flag"
  from cmn_portlets p
  left join cmn_grids g on g.portlet_id = p.id
                       and p.portlet_type_code = 'GRID'
                       and g.principal_type = 'SYSTEM'
  left join cmn_nsql_queries d on d.id = g.dal_id
  left join cmn_gg_nsql_queries q on q.cmn_nsql_queries_id = d.id
 where p.instance_type = 'PMA_PORTFOLIO'

 order by p.portlet_code)

              