
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '52' as "order",
         'Studio' as "name",
         'Detect Attributes on objects with missing lookups' as "description",
         'Delete attributes for each object Administration > Studio > Objects or create lookup correctly' as "action",			
         'Object' as "th1",
         'Name' as "th2",
         'Code' as "th3",
         'Name' as "th4",
         'Lookup' as "th5",
         'Flag' as "th6"),
        xmlagg(xmlelement(name "Record", xmlforest("object", "object_name", "code", "name", "lookup", "flag"))))
       .getclobval()
from (



--Main
select a.object_name as "object",
       (select n.name
          from cmn_captions_nls n,
               odf_objects      o
         where n.pk_id = o.id
           and n.table_name = 'ODF_OBJECTS'
           and n.language_code = 'en'
           and o.code = a.object_name) as "object_name",
       a.internal_name as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = a.id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = 'en') as "name",
       a.lookup_type as "lookup",
       'NOK' as "flag"
  from odf_custom_attributes a
 where a.lookup_type not in (select t.lookup_type from cmn_lookup_types t)
   and a.lookup_type not like 'OBS_BROWSE_FLT%'

)


              