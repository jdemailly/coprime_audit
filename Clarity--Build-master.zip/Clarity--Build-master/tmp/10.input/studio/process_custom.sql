
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '69' as "order",
         'Studio' as "name",
         'Custom Processes' as "description",
         'Analyze Each Process if Needed' as "action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Process Custom\n
select p.process_code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''en''\n
           and n.table_name = ''BPM_DEF_PROCESSES''\n
           and n.pk_id = p.id) as "name",\n
       p.last_updated_date as "last_updated_date",\n
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by"\n
  from bpm_def_processes p\n
 where p.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where p.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by p.process_code' as "script",
         'Code' as "th1",
         'Name' as "th2",
         'Updated Date' as "th3",
         'Updated By' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "last_updated_date", "last_updated_by"))))
       .getclobval()
from (
with
--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

--Portlet Custom
select p.process_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = 'en'
           and n.table_name = 'BPM_DEF_PROCESSES'
           and n.pk_id = p.id) as "name",
       p.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by"
  from bpm_def_processes p
 where p.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where p.last_updated_date between date_minus_1h and date_plus_1h)

order by p.process_code)



              