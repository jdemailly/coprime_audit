
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '53' as "order",
         'Studio' as "name",
         'Detect Attributes on queries with missing lookups' as "description",
         'Modify lookup on query attributes for each query Administration > Studio > Queries or create lookup correctly' as "action",
         'Query Code' as "th1",
         'Query Name' as "th2",
         'Code' as "th3",
         'Name' as "th4",
         'Lookup' as "th5",
         'Flag' as "th6"),
        xmlagg(xmlelement(name "Record", xmlforest("query_code", "query_name", "code", "name", "lookup", "flag"))))
       .getclobval()
from (



--Main
select q.query_code as "query_code",
       (select name
          from cmn_captions_nls n
         where n.pk_id = q.id
           and n.table_name = 'CMN_GG_NSQL_QUERIES'
           and n.language_code = 'en') as "query_name",
       c.filter_association as "code",
       (select name
          from cmn_captions_nls n
         where n.pk_id = c.id
           and n.table_name = 'CMN_NSQL_QUERY_FILTERS'
           and n.language_code = 'en') as "name",
       c.filter_association_type as "type",
       c.lov as "lookup",
       'NOK' as "flag"
  from cmn_nsql_query_filters c
 inner join cmn_nsql_queries n on n.id = c.cmn_nsql_queries_id
 inner join cmn_gg_nsql_queries q on q.cmn_nsql_queries_id = n.id
 where c.lov is not null
   and c.lov not in (select lookup_type from cmn_lookup_types)

)


              