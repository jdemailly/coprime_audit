
                


select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Time Slice' as "name",
         'Detects time slices being processed' as "description",
         'Run Time Slicing Job until no more time slice is done' as "action",
         'Name' as "th1",
         'Table' as "th2",
         'Status' as "th3",
         'Completed Date' as "th4",
         'Active' as "th5",
         'System' as "th6",
         'Flag' as "th7",
         'Script' as "th8"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "table", "status", "request_completed_date", "is_active", "is_system", "flag", "script"))))
       .getclobval()
from (



--Select
select r.request_name as "name",
       r.table_name as "table",
       nvl(to_char(r.request_status), ' ') as "status",
       nvl(to_char(r.request_completed_date, 'YYYY-MM-DD'), ' ') as "request_completed_date",
       
       r.is_active as "is_active",
       r.is_system as "is_system",
       'NOK' as "flag",
       'begin\n\tupdate prj_blb_slicerequests set request_status = null, request_completed_date = sysdate where id = ' || to_char(r.id) || ';\n\tcommit;\nend;' as "script"
  from prj_blb_slicerequests r
 where r.is_template = 0
   and r.is_active = 1
   and (nvl(r.request_status, 0) > 0 or r.request_completed_date is null)

 order by r.last_updated_date desc)

              