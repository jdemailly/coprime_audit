
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '61' as "order",
         'Studio' as "name",
         'Detects required attributes on objects' as "description",
         'Deactivate the property "Value Required" of each attribute on each object before upgrading' as "action",
         'Object' as "th1",
         'Attribute' as "th2",
         'Column' as "th3",
         'Type' as "th4",
         'Extended' as "th5",
         'Size' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "column", "type", "extended_type", "size"))))
       .getclobval()
from (



--Main
select a.object_name as "code",
       a.column_name as "column",
       (select name
          from cmn_captions_nls n
         where n.pk_id = a.id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = 'en') as "name",
       a.data_type as "type",
       nvl(a.extended_type, ' ') as "extended_type",
       a.data_size as "size"
  from odf_custom_attributes a
 where a.is_custom = 1
   and a.is_required = 1
   and not (a.object_name = 'cop_prj_statusrpt' and a.column_name = 'cop_project_manager')

)

              