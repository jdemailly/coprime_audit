
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '51' as "order",
         'Studio' as "name",
         'Detect HTML portlets which need an update' as "description",
         'Make following changes in Administration > Studio > Portlets :\n\t- Replace document.write by innerHTML\n\t- Replace app?action by nu#action\n\t- Remove link action:jre.installation' as "action",			
         'Code' as "th1",
         'Name' as "th2",
         'Script' as "th3"),
       	xmlagg(xmlelement(name "Record", xmlforest("code", "name", "script"))))
       .getclobval()
from (



--Main
select p.portlet_code as "code",
       (select name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'CMN_PORTLETS'
           and n.language_code = 'en') as "name",
       'select p.portlet_code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = ''CMN_PORTLETS''\n
           and n.language_code = ''en'') as "name",\n
       h.html_text as "text"\n
  from cmn_html_retrieve_services h,\n
       cmn_portlets               p\n
 where h.portlet_id = p.id\n
   and h.id = ' || to_char(h.id) || ';' as "script"
  from cmn_html_retrieve_services h,
       cmn_portlets               p
 where h.portlet_id = p.id
   and p.portlet_type_code = 'HTML'
   
   and (lower(h.html_text) like '%app?action=%'
   	 or lower(h.html_text) like '%document.write%'
   	 or lower(h.html_text) like '%personal.jreinstallation%'
   	 or lower(h.html_text) like '%xog.client%')
   

)

              