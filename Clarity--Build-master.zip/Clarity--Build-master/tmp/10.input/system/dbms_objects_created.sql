
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '13' as "order",
         'System Info' as "name",
         'Count Oracle Objects by Creation Date' as "description",
         'Date' as "th1",
         'Count' as "th2"),
       xmlagg(xmlelement(name "Record", xmlforest("date", "count"))))
       .getclobval()
from (

select to_char(trunc(o.created), 'YYYY-MM-DD') as "date",
       count(*) as "count"
  from user_objects o
 group by trunc(o.created)
 order by trunc(o.created) desc

)



              