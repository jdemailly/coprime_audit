
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '11' as "order",
         'System Info' as "name",
         'Information on Oracle and Clarity systems' as "description",
         'System' as "th1",
         'Type' as "th2",
         'Value' as "th3"),
       xmlagg(xmlelement(name "Record", xmlforest("label", "type", "value"))))
       .getclobval()
from (

--Clarity : Version
select "label",
       "type",
       "value"
  from (select 'Clarity' as "label",
               h.install_id as "type",
               h.installed_version as "value"
          from cmn_install_history h
         where h.install_id in ('database', 'release_version')
         order by h.installed_date desc)
 where rownum = 1
union all
select "label",
       "type",
       "value"
  from (select 'Clarity' as "label",
               h.install_id as "type",
               h.installed_version as "value"
          from cmn_install_history h
         where h.install_id = 'contentPack::clarityContent'
         order by h.installed_date desc)
 where rownum = 1
union all
select 'Clarity',
       'Store Files in Database',
       case
         when exists (select 1 from clb_dms_file_store) then
          'Yes'
         else
          'No'
       end
  from dual
union all
select 'Clarity',
       'Multi-Currency',
       case
         when exists (select 1 from cmn_exchange_rates) then
          'Yes'
         else
          'No'
       end
  from dual

--Oracle : Version
union all
select 'Oracle' as "label",
       'Version' as "type",
       property_value as "value"
  from database_properties
 where property_name = 'NLS_RDBMS_VERSION'
union all
select 'Oracle' as "label",
       'Server' as "type",
       sys_context('userenv', 'server_host')
  from dual
union all
select 'Oracle' as "label",
       'Database' as "type",
       sys_context('userenv', 'db_name')
  from dual
union all
select 'Oracle' as "label",
       'User' as "type",
       user
  from dual
union all
select 'Oracle' as "label",
       'Schema' as "type",
       sys_context('userenv', 'current_schema')
  from dual
union all
select 'Oracle' as "label",
       'SID (Instance)' as "type",
       sys_context('userenv', 'instance_name')
  from dual
union all
select 'Oracle' as "label",
       'Service Name' as "type",
       sys_context('userenv', 'service_name')
  from dual
 order by "label",
          "type"
)



              