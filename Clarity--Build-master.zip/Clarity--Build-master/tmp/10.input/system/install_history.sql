
                

select xmlelement(name "QueryResult",
       xmlattributes(
         '12' as "order",
         'System Info' as "name",
         'Clarity Installation History (add-on, upgrade, database, etc.)' as "description",
         'Type' as "th1",
         'Value' as "th2",
         'Date' as "th3"),
       xmlagg(xmlelement(name "Record", xmlforest("type", "value", "date"))))
       .getclobval()
from (
select h.install_id        as "type",
       h.installed_version as "value",
       h.installed_date    as "date"
  from cmn_install_history h
 order by h.installed_date desc
)



              