<QueryResult order="41" name="Resources" description="Detect Resources financially active and with no Transaction Class or Resource Class" action="For each resource, change their financial properties and add Resource Class / Transaction Class" th1="ID" th2="Code" th3="Name"></QueryResult>

