<QueryResult order="43" name="Documents" description="Shows locked documents" script="begin\n
  dbms_output.put_line(&apos;Updating clb_dms_files table...&apos;);\n
  update clb_dms_files f set f.lock_owner_id = null, f.lock_time_stamp = null where f.lock_owner_id &lt;&gt; 0;\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  commit;\n
end;" action="Run custom script to remove locks" th1="Name" th2="Mime Type" th3="Since" th4="By"></QueryResult>

