<QueryResult order="42" name="Investments" description="Shows locked investments" script="begin\n
  dbms_output.put_line(&apos;Deleting from prlock table...&apos;);\n
  delete from prlock where prtablename = &apos;SRM_PROJECTS&apos;;\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  commit;\n
end;" action="Run custom script to remove locks" th1="Code" th2="Name" th3="Type" th4="Since" th5="Progress"></QueryResult>

