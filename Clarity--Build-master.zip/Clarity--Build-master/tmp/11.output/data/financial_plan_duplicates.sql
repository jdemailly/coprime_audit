<QueryResult order="44" name="Investments" description="Detect Financial Plan Codes with duplicated codes in investment" action="Run the following script to change financial plans codes" script="begin\n
\tdbms_output.put_line(&apos;Updating financial plan code duplicates...&apos;);\n
\tupdate fin_plans\n
\t   set code = code || &apos;_&apos; || to_char(id)\n
\t where id in (select p1.id\n
\t                from fin_plans p1,\n
\t                     fin_plans p2\n
\t               where p1.id != p2.id\n
\t                 and p1.object_id = p2.object_id\n
\t                 and p1.code = p2.code\n
\t                 and p1.plan_type_code = p2.plan_type_code);\n
\tdbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
\tcommit;\n
end;" th1="ID" th2="Code" th3="Name" th4="Type" th5="Investment ID" th6="Investment Code" th7="Investment Name"></QueryResult>

