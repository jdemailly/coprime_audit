<QueryResult order="13" name="System Info" description="Count Oracle Objects by Creation Date" th1="Date" th2="Count"><Record><date>2023-11-14</date><count>30</count></Record><Record><date>2023-11-13</date><count>607</count></Record><Record><date>2023-11-10</date><count>7273</count></Record></QueryResult>

