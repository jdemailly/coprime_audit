<QueryResult order="40" name="Upgrade" description="Check List before Upgrading" action="See that Every Flag is Set to OK or WARN before Upgrading" th1="Type" th2="Rule" th3="Value" th4="Flag" th5="Script"><Record><type>User</type><rule>Login xtd_deploy must exist with the proper rights, otherwise use another user</rule><value> </value><flag>WARN</flag><script>&lt;NikuDataBus xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot; xsi:noNamespaceSchemaLocation=&quot;../xsd/nikuxog_user.xsd&quot;&gt;\n
  &lt;Header action=&quot;write&quot; externalSource=&quot;NIKU&quot; objectType=&quot;user&quot; version=&quot;12&quot;/&gt;\n
  &lt;Users&gt;\n
    &lt;User externalId=&quot; &quot; isLDAP=&quot;false&quot; uiThemeDefaultPartitionCode=&quot; &quot; userLanguage=&quot;English&quot; userLocale=&quot;en_US&quot; userName=&quot;xtd_deploy&quot; userStatus=&quot;ACTIVE&quot; userTimezone=&quot;Europe/Brussels&quot; userType=&quot;EXTERNAL&quot;&gt;\n
      &lt;PersonalInformation emailAddress=&quot;centreservices@coprime.fr&quot; firstName=&quot;Clarity&quot; lastName=&quot;Deployment&quot;/&gt;\n
      &lt;Resource resourceId=&quot;xtd_deploy&quot;/&gt;\n
    &lt;/User&gt;\n
  &lt;/Users&gt;\n
&lt;/NikuDataBus&gt;</script></Record><Record><type>User</type><rule>Login xtd_deploy Must Have all Global Rights</rule><value>0 missing</value><flag>OK</flag><script>Add Global Rights on User</script></Record><Record><type>User</type><rule>Login admin language must be english</rule><value>en</value><flag>OK</flag><script>&lt;NikuDataBus xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot; xsi:noNamespaceSchemaLocation=&quot;../xsd/nikuxog_user.xsd&quot;&gt;\n
  &lt;Header action=&quot;write&quot; externalSource=&quot;NIKU&quot; objectType=&quot;user&quot; version=&quot;13&quot;/&gt;\n
  &lt;Users&gt;\n
    &lt;User externalId=&quot;&quot; userLanguage=&quot;English&quot; userName=&quot;admin&quot;&gt;\n
      &lt;PersonalInformation emailAddress=&quot;username@mailserver.com&quot; firstName=&quot;Administrateur&quot; lastName=&quot;Clarity&quot;/&gt;\n
    &lt;/User&gt;\n
  &lt;/Users&gt;\n
&lt;/NikuDataBus&gt;</script></Record><Record><type>User</type><rule>Login admin locale must be en_US English (United States)</rule><value>en_US</value><flag>OK</flag><script>&lt;NikuDataBus xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot; xsi:noNamespaceSchemaLocation=&quot;../xsd/nikuxog_user.xsd&quot;&gt;\n
  &lt;Header action=&quot;write&quot; externalSource=&quot;NIKU&quot; objectType=&quot;user&quot; version=&quot;13&quot;/&gt;\n
  &lt;Users&gt;\n
    &lt;User externalId=&quot;&quot; userLocale=&quot;en_US&quot; userName=&quot;admin&quot;&gt;\n
      &lt;PersonalInformation emailAddress=&quot;username@mailserver.com&quot; firstName=&quot;Administrateur&quot; lastName=&quot;Clarity&quot;/&gt;\n
    &lt;/User&gt;\n
  &lt;/Users&gt;\n
&lt;/NikuDataBus&gt;</script></Record><Record><type>User</type><rule>Login admin Must Have all Global Rights</rule><value>152 missing</value><flag>NOK</flag><script>Add Global Rights on User</script></Record><Record><type>User</type><rule>Reset Login admin Password to niku2000</rule><value> </value><flag>WARN</flag><script>--13.2-\n
begin\n
  dbms_output.put_line(&apos;Reset admin password to niku2000.&apos;);\n
  update cmn_sec_users\n
     set pwd = (select pwd from cmn_sec_users where user_name = &apos;xc_admin&apos;),\n
         user_status_id = 200\n
   where user_name = &apos;admin&apos;\n
     and not pwd = (select pwd from cmn_sec_users where user_name = &apos;xc_admin&apos;);\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  commit;\n
end;\n
--13.3+\n
begin\n
  dbms_output.put_line(&apos;Reset admin password to niku2000.&apos;);\n
  update cmn_sec_users u\n
     set u.pwd          = &apos;b42405b42403535333865636532b1cb94e15b207275f64358b0d6d0d414&apos;,\n
         u.salt         = &apos;[B@5538ece2&apos;,\n
         user_status_id = 200\n
   where id = 1\n
     and not (u.pwd = &apos;b42405b42403535333865636532b1cb94e15b207275f64358b0d6d0d414&apos; or u.salt = &apos;[B@5538ece2&apos;);\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>User</type><rule>Clean up Excessive Notifications older than 30 days</rule><value>114795 notification(s)</value><flag>WARN</flag><script>begin\n
  dbms_output.put_line(&apos;Cleaning table clb_notifications, older than 30 days.&apos;);\n
  delete from clb_notifications where created_date &lt; sysdate - 30;\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  dbms_output.put_line(&apos;Cleaning orphaned records in clb_notification_assocs.&apos;);\n
  delete from clb_notification_assocs where instance_id not in (select id from clb_notifications);\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>Document</type><rule>Locked Documents need to be unlocked</rule><value>0 document(s)</value><flag>OK</flag><script>begin\n
  dbms_output.put_line(&apos;Updating clb_dms_files table...&apos;);\n
  update clb_dms_files f set f.lock_owner_id = null, f.lock_time_stamp = null where f.lock_owner_id &lt;&gt; 0;\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>Investment</type><rule>Locked Projects need to be unlocked on page nu#action:security.locks</rule><value>0 project(s)</value><flag>OK</flag><script>begin\n
  dbms_output.put_line(&apos;Deleting from prlock table...&apos;);\n
  delete from prlock where prtablename = &apos;SRM_PROJECTS&apos;;\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>Investment</type><rule>Closed and to-be-deleted Projects are properly closed</rule><value>9 project(s)</value><flag>WARN</flag></Record><Record><type>Investment</type><rule>Fix 13.3, ideas not in pac_mnt_projects or odf_ca_npiofinproperties</rule><value>0 idea(s)</value><flag>OK</flag><script>--Reference support CA : CLRT-72828_POSTUPGRADE_IDEA_PAC_MNT_PROJECTS.xml\n
begin\n
  dbms_output.put_line(&apos;Fix 13.3 - Inserting elements in pac_mnt_projects for ideas financially enable&apos;);\n
  insert into pac_mnt_projects\n
    (id,\n
     status,\n
     approved,\n
     master_project_code,\n
     project_code,\n
     billing_currency_code,\n
     labor_exchange_rate_type,\n
     expense_exchange_rate_type,\n
     materials_exchange_rate_type,\n
     equipment_exchange_rate_type,\n
     odf_object_code,\n
     cost_type)\n
    select i.id,\n
           &apos;H&apos;,\n
           1,\n
           upper(i.code),\n
           upper(i.code),\n
           i.currency_code,\n
           &apos;AVERAGE&apos;,\n
           &apos;AVERAGE&apos;,\n
           &apos;AVERAGE&apos;,\n
           &apos;AVERAGE&apos;,\n
           i.odf_object_code,\n
           &apos;OPERATING&apos;\n
      from inv_investments i\n
     where odf_object_code = &apos;idea&apos;\n
       and not exists (select 1 from pac_mnt_projects where id = i.id);\n
  dbms_output.put_line(sql%rowcount || &apos; insert(s) done&apos;);\n
  commit;\n
  dbms_output.put_line(&apos;Fix 13.3 - Inserting elements in odf_ca_npiofinproperties for ideas financially enable&apos;);\n
  insert into odf_ca_npiofinproperties\n
    (id,\n
     created_date,\n
     created_by,\n
     last_updated_date,\n
     last_updated_by,\n
     odf_object_code)\n
    select i.id,\n
           sysdate,\n
           1,\n
           sysdate,\n
           1,\n
           i.odf_object_code\n
      from inv_investments i\n
     where odf_object_code = &apos;idea&apos;\n
       and not exists (select 1 from odf_ca_npiofinproperties where id = i.id);\n
  dbms_output.put_line(sql%rowcount || &apos; insert(s) done&apos;);\n
  commit;\n
end;</script></Record><Record><type>Finance</type><rule>Financial Processing, check Invalid Transactions</rule><value>0 transaction(s)</value><flag>OK</flag><script>begin\n
  dbms_output.put_line(&apos;Deleting invalid transactions in imp_transactionimport.&apos;);\n
  delete from imp_transactionimport where importstatus = &apos;E&apos;;\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>Finance</type><rule>Financial Processing, check Pending Transactions</rule><value>11431 transaction(s)</value><flag>WARN</flag><script>Run Financial Jobs</script></Record><Record><type>Finance</type><rule>Financial Processing, check Adjusting Transactions</rule><value>0 transaction(s)</value><flag>OK</flag><script>Approve Adjusting Transactions</script></Record><Record><type>Finance</type><rule>Financial Processing, check Post to WIP Transactions</rule><value>0 transaction(s)</value><flag>OK</flag><script>Post to WIP Transactions</script></Record><Record><type>Process</type><rule>Processes Running or Aborting need to be paused</rule><value>73 process(es)</value><flag>WARN</flag></Record><Record><type>Process</type><rule>Processes in Error older than 30 days need to be cancelled</rule><value>17 process(es)</value><flag>WARN</flag><script>begin\n
  dbms_output.put_line(&apos;Update bpm_run_processes.status_code to BPM_PIS_ABORTING.&apos;);\n
  update bpm_run_processes p\n
     set p.user_action = &apos;BPM_PIA_ABORT&apos;, p.status_code = &apos;BPM_PIS_ABORTING&apos;\n
   where p.status_code = &apos;BPM_PIS_ERROR&apos;\n
     and p.user_action is null;\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>Process</type><rule>Clean up Processes completed - Delete Process Instance</rule><value>8 process(es)</value><flag>WARN</flag><script>Run Job &quot;Delete Process Instance&quot;</script></Record><Record><type>Job</type><rule>Scheduled Job &quot;Extraction du magasin de données&quot; should be created by an english user</rule><value>H81827-2053 fr</value><flag>NOK</flag><script>&lt;NikuDataBus xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot; xsi:noNamespaceSchemaLocation=&quot;../xsd/nikuxog_user.xsd&quot;&gt;\n
  &lt;Header action=&quot;write&quot; externalSource=&quot;NIKU&quot; objectType=&quot;user&quot; version=&quot;13&quot;/&gt;\n
  &lt;Users&gt;\n
    &lt;User externalId=&quot;&quot; userLanguage=&quot;English&quot; userName=&quot;H81827-2053&quot;&gt;\n
      &lt;PersonalInformation emailAddress=&quot;@macif.fr&quot; firstName=&quot;Salah-2053&quot; lastName=&quot;BEN AISSOU.ext&quot;/&gt;\n
    &lt;/User&gt;\n
  &lt;/Users&gt;\n
&lt;/NikuDataBus&gt;</script></Record><Record><type>Job</type><rule>Scheduled Job &quot;Cumul du magasin de données - Temps - Faits et récapitulatif&quot; should be created by an english user</rule><value>H81858-2053 fr</value><flag>NOK</flag><script>&lt;NikuDataBus xmlns:xsi=&quot;http://www.w3.org/2001/XMLSchema-instance&quot; xsi:noNamespaceSchemaLocation=&quot;../xsd/nikuxog_user.xsd&quot;&gt;\n
  &lt;Header action=&quot;write&quot; externalSource=&quot;NIKU&quot; objectType=&quot;user&quot; version=&quot;13&quot;/&gt;\n
  &lt;Users&gt;\n
    &lt;User externalId=&quot;&quot; userLanguage=&quot;English&quot; userName=&quot;H81858-2053&quot;&gt;\n
      &lt;PersonalInformation emailAddress=&quot;@macif.com&quot; firstName=&quot;Zobir-2053&quot; lastName=&quot;ZEGHOUD.ext&quot;/&gt;\n
    &lt;/User&gt;\n
  &lt;/Users&gt;\n
&lt;/NikuDataBus&gt;</script></Record><Record><type>Job</type><rule>Jobs Processing or Scheduled need to be paused</rule><value>36 job(s)</value><flag>WARN</flag><script>Application &gt; Reports and Jobs &gt; [Scheduled Jobs] &gt; Action Pause</script></Record><Record><type>Job</type><rule>Clean up Job completed - Remove Job Logs and Report Library entries older than 15 days</rule><value>0 log(s)</value><flag>OK</flag><script>Run Job &quot;Remove Job Logs and Report Library&quot;</script></Record><Record><type>Job</type><rule>Datamart tables need to be cleaned up NBI_CLEAN_DATAMART_SP</rule><value>875 records in nbi_dim_obs</value><flag>WARN</flag><script>begin\n\tdbms_output.put_line(&apos;Cleaning Datamart tables...&apos;);\n\tNBI_CLEAN_DATAMART_SP;\n\tdbms_output.put_line(&apos;Done&apos;);\nend;</script></Record><Record><type>Job</type><rule>Orphaned Documents need to be Purged</rule><value>0 record(s)</value><flag>OK</flag><script>Run Job &quot;Purge Documents&quot;</script></Record><Record><type>Object</type><rule>Clean up Audit Trails - Purge Audit Trail</rule><value>13080 value(s)</value><flag>WARN</flag><script>Run Job &quot;Purge Audit Trail&quot;</script></Record><Record><type>Object</type><rule>Disable Custom Audit Trails</rule><value>149 attribute(s)</value><flag>NOK</flag></Record><Record><type>Object</type><rule>Set all Required Custom Attributes to be Not-Required</rule><value>32 attribute(s)</value><flag>NOK</flag></Record><Record><type>Object</type><rule>Fix 13.2, Delete portfolio Objects</rule><value> </value><flag>OK</flag></Record><Record><type>Calendar</type><rule>Standard Calendar must exist</rule><value> </value><flag>OK</flag><script>Recreate Standard Calendar</script></Record><Record><type>DBMS</type><rule>Table PRJ_BLB_SLICES is copied during upgrade, tablespace USERS_LARGE must have enough space</rule><value> </value><flag>WARN</flag><script>with tbl as\n
 (select t.owner as &quot;owner&quot;,\n
         t.table_name as &quot;table&quot;,\n
         t.tablespace_name as &quot;tablespace&quot;,\n
         nvl(round((t.num_rows * t.avg_row_len) / (1024 * 1024)), 0) as &quot;mb_needed&quot;,\n
         round(sum(f.bytes) / (1024 * 1024)) as &quot;total_space&quot;,\n
         (select round(sum(s.bytes) / (1024 * 1024)) from dba_segments s where s.tablespace_name = t.tablespace_name) as &quot;total_used_space&quot;,\n
         max(f.autoextensible) as &quot;autoextensible&quot;,\n
         count(*) as &quot;count_data_files&quot;,\n
         sum(f.maxbytes) / (1024 * 1024) * count(*) as &quot;mb_max&quot;,\n
         sum(f.user_bytes) / (1024 * 1024) as &quot;mb_used&quot;,\n
         round((sum(f.user_bytes) / (1024 * 1024)) / (sum(f.maxbytes) / (1024 * 1024)) * 100, 2) as &quot;percent_used&quot;\n
    from all_tables     t,\n
         dba_data_files f\n
   where f.tablespace_name = t.tablespace_name\n
     and t.table_name = &apos;PRJ_BLB_SLICES&apos;\n
   group by t.owner,\n
            t.table_name,\n
            t.tablespace_name,\n
            nvl(round((t.num_rows * t.avg_row_len) / (1024 * 1024)), 0))\n
select &apos;Owner&apos; as &quot;property&quot;,\n
       tbl.&quot;owner&quot; as &quot;value&quot;\n
  from tbl\n
union all\n
select &apos;Table&apos;,\n
       tbl.&quot;table&quot;\n
  from tbl\n
union all\n
select &apos;Tablespace&apos;,\n
       tbl.&quot;tablespace&quot;\n
  from tbl\n
union all\n
select &apos;MB Needed&apos;,\n
       to_char((tbl.&quot;mb_needed&quot;))\n
  from tbl\n
union all\n
select &apos;MB Max&apos;,\n
       to_char((tbl.&quot;mb_max&quot;))\n
  from tbl\n
union all\n
select &apos;MB Used&apos;,\n
       to_char((tbl.&quot;mb_used&quot;))\n
  from tbl\n
union all\n
select &apos;Data Files&apos;,\n
       to_char((tbl.&quot;count_data_files&quot;))\n
  from tbl\n
union all\n
select &apos;MB Free&apos;,\n
       to_char((tbl.&quot;total_space&quot; - tbl.&quot;total_used_space&quot;)) as &quot;mb_free&quot;\n
  from tbl\n
union all\n
select &apos;Autoextensible&apos;,\n
       tbl.&quot;autoextensible&quot;\n
  from tbl\n
union all\n
select &apos;Flag&apos;,\n
       case\n
         when tbl.&quot;autoextensible&quot; = &apos;YES&apos; and tbl.&quot;mb_max&quot; &gt; (tbl.&quot;mb_needed&quot; + tbl.&quot;mb_used&quot;) then\n
          &apos;OK&apos;\n
         when tbl.&quot;autoextensible&quot; = &apos;NO&apos; and tbl.&quot;mb_needed&quot; &lt; (tbl.&quot;total_space&quot; - tbl.&quot;total_used_space&quot;) then\n
          &apos;OK&apos;\n
         else\n
          &apos;NOK&apos;\n
       end as &quot;flag&quot;\n
  from tbl</script></Record><Record><type>DBMS</type><rule>Orphaned records in table NMS_MESSAGE_DELIVERY need to be deleted</rule><value>54 record(s)</value><flag>WARN</flag><script>begin\n
  dbms_output.put_line(&apos;Deleting orphaned records in nms_message_delivery.&apos;);\n
  delete from nms_message_delivery where message_id not in (select id from nms_messages);\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>DBMS</type><rule>Orphaned records in table CMN_SESSION_PROPERTIES need to be deleted</rule><value>0 record(s)</value><flag>OK</flag><script>begin\n
  dbms_output.put_line(&apos;Deleting orphaned records in cmn_session_properties.&apos;);\n
  delete from cmn_session_properties\n
   where session_id not in (select id from cmn_sessions)\n
     and session_id not in (select session_id from cmn_session_audits);\n
  dbms_output.put_line(sql%rowcount || &apos; delete(s) done.&apos;);\n
  commit;\n
end;</script></Record><Record><type>DBMS</type><rule>TEC1527468 ORA-01438: on Column PFM_INV_CONTRAINTS.PH_CURVE_SUM</rule><value> </value><flag>OK</flag><script>alter table pfm_inv_constraint_sums modify (ph_curve_sum number(32,6));</script></Record></QueryResult>

