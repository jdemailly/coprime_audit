<QueryResult order="102" name="Test" description="Administration Objects by navigation" th1="URI" th2="Object" th3="Vector" th4="Count" th5="Script"><Record><uri>Organization and Access &gt; Resources</uri><object>User</object><sort>Default</sort><count>2019</count><script>select count(*)\n
  from cmn_sec_users\n
 where user_status_id = 200</script></Record><Record><uri>Organization and Access &gt; Resources</uri><object>User</object><sort>Show All</sort><count>16513</count><script>select count(*) from cmn_sec_users</script></Record><Record><uri>Organization and Access &gt; Resources</uri><object>User</object><sort>Lang English</sort><count>3374</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_languages    l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LANGUAGES&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.id = u.language_id) as lang,\n
       count(*) as count\n
  from cmn_sec_users u\n
 group by u.language_id</script></Record><Record><uri>Organization and Access &gt; Resources</uri><object>User</object><sort>Lang French</sort><count>13132</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_languages    l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LANGUAGES&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.id = u.language_id) as lang,\n
       count(*) as count\n
  from cmn_sec_users u\n
 group by u.language_id</script></Record><Record><uri>Organization and Access &gt; Resources</uri><object>User</object><sort>Lang Italian</sort><count>4</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_languages    l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LANGUAGES&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.id = u.language_id) as lang,\n
       count(*) as count\n
  from cmn_sec_users u\n
 group by u.language_id</script></Record><Record><uri>Organization and Access &gt; Resources</uri><object>User</object><sort>Lang Spanish</sort><count>3</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_languages    l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LANGUAGES&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.id = u.language_id) as lang,\n
       count(*) as count\n
  from cmn_sec_users u\n
 group by u.language_id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Default</sort><count>69</count><script>select count(*)\n
  from cmn_sec_groups g\n
 where g.group_role_type = &apos;GROUP&apos;\n
   and group_type_id is not null\n
   and is_active = 1\n
 order by g.created_date desc</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Show All</sort><count>81</count><script>select count(*)\n
  from cmn_sec_groups g\n
 where g.group_role_type = &apos;GROUP&apos;\n
   and group_type_id is not null\n
 order by g.created_date desc</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Administrateurs techniques</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Utilisateurs Clarity</sort><count>2218</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in CP Transverse</sort><count>54</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Groupes Chefs de projet</sort><count>31</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Resource Planning</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in License Information Access</sort><count>6</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Administrateurs Fonctionnels NEW</sort><count>13</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Chef de projet MOA User</sort><count>32</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Visu projets transverses - Développement</sort><count>1</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Admin BDP</sort><count>11</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Coordonnateur MOA User</sort><count>37</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Application Administrator</sort><count>9</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Administration - XOG</sort><count>9</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Job Monitors</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Job Users</sort><count>1</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Custom Object Administrators</sort><count>4</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Process Administrator</sort><count>8</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Project Manager</sort><count>11</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Report and Job Administrator</sort><count>9</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Access to CA PPM Studio</sort><count>6</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in System Administrator</sort><count>3</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Basic group for user access</sort><count>5536</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Manageur DIT</sort><count>60</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Gestionnaire adhérences projet</sort><count>9</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Log Analysis Access</sort><count>6</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in PMO Financial Administrator</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in PMO Resource Administrator</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in PMO System Administrator</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in PMO Timesheet Administrator</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in DDSIG - Approbation Feuilles de Temps</sort><count>18</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Chef de projet Planning unique</sort><count>434</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Utilisateurs Clarity Hors Approbation FDT</sort><count>952</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Analyser Feuille de temps</sort><count>30</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Admin Deployment</sort><count>3</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in DSIM - Vérification Feuilles de temps</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Feuille de temps - Saisie et approbation</sort><count>2</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; Groups</uri><object>Group</object><sort>Resources in Interface - Resource Leave File</sort><count>6</count><script>select (select name\n
          from cmn_captions_nls\n
         where pk_id = g.id\n
           and table_name = &apos;CMN_SEC_GROUPS&apos;\n
           and language_code = &apos;en&apos;) as name,\n
       count(*) as count\n
  from cmn_sec_groups      g,\n
       cmn_sec_user_groups u\n
 where g.id = u.group_id\n
   and g.group_role_type = &apos;GROUP&apos;\n
   and g.group_type_id is not null\n
 group by g.id</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>Default</sort><count>6</count><script>select count(*) from prj_obs_types</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>OBS 2 Groupe Macif</sort><count>677</count><script>select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>OBS OBS Ressources</sort><count>1</count><script>select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>OBS 3 OBS Départements</sort><count>1</count><script>select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>OBS Plan 2010 - Déclinaison Stratégie</sort><count>139</count><script>select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>OBS Plan 2011 - Déclinaison Stratégie</sort><count>32</count><script>select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id</script></Record><Record><uri>Organization and Access &gt; OBS</uri><object>OBS</object><sort>OBS OBS Projets</sort><count>24</count><script>select (select t.name from prj_obs_types t where t.id = u.type_id),\n
       count(*)\n
  from prj_obs_units u\n
 group by u.type_id</script></Record><Record><uri>Studio &gt; Partition Models</uri><object>Partition</object><sort>All</sort><count>0</count><script>select count(*) from cmn_partition_models</script></Record><Record><uri>Studio &gt; Objects</uri><object>Object</object><sort>Default</sort><count>99</count><script>select count(*)\n
  from odf_objects o\n
 where o.is_customizable = 1</script></Record><Record><uri>Studio &gt; Objects</uri><object>Object</object><sort>All</sort><count>258</count><script>select count(*) from odf_objects</script></Record><Record><uri>Studio &gt; Objects</uri><object>Object</object><sort>Custom</sort><count>33</count><script>select count(*)\n
  from odf_objects\n
 where is_custom = 1</script></Record><Record><uri>Studio &gt; Queries</uri><object>Query</object><sort>All</sort><count>234</count><script>select count(*) from cmn_gg_nsql_queries</script></Record><Record><uri>Studio &gt; Queries</uri><object>Query</object><sort>Source customer</sort><count>161</count><script>select source,\n
       count(*)\n
  from cmn_gg_nsql_queries\n
 group by source</script></Record><Record><uri>Studio &gt; Queries</uri><object>Query</object><sort>Source niku.com</sort><count>16</count><script>select source,\n
       count(*)\n
  from cmn_gg_nsql_queries\n
 group by source</script></Record><Record><uri>Studio &gt; Queries</uri><object>Query</object><sort>Source csk.niku.com</sort><count>57</count><script>select source,\n
       count(*)\n
  from cmn_gg_nsql_queries\n
 group by source</script></Record><Record><uri>Studio &gt; Portlets</uri><object>Portlets</object><sort>All</sort><count>455</count><script>select count(*)\n
  from cmn_portlets p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;</script></Record><Record><uri>Studio &gt; Portlets</uri><object>Portlets</object><sort>Type Restricted</sort><count>171</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PORTLET_TYPE&apos;\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       count(*) as count\n
  from cmn_portlets p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.portlet_type_code &lt;&gt; &apos;FAVORITE&apos;\n
 group by p.portlet_type_code</script></Record><Record><uri>Studio &gt; Portlets</uri><object>Portlets</object><sort>Type Graph</sort><count>64</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PORTLET_TYPE&apos;\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       count(*) as count\n
  from cmn_portlets p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.portlet_type_code &lt;&gt; &apos;FAVORITE&apos;\n
 group by p.portlet_type_code</script></Record><Record><uri>Studio &gt; Portlets</uri><object>Portlets</object><sort>Type Grid</sort><count>203</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PORTLET_TYPE&apos;\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       count(*) as count\n
  from cmn_portlets p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.portlet_type_code &lt;&gt; &apos;FAVORITE&apos;\n
 group by p.portlet_type_code</script></Record><Record><uri>Studio &gt; Portlets</uri><object>Portlets</object><sort>Type Filter</sort><count>10</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PORTLET_TYPE&apos;\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       count(*) as count\n
  from cmn_portlets p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.portlet_type_code &lt;&gt; &apos;FAVORITE&apos;\n
 group by p.portlet_type_code</script></Record><Record><uri>Studio &gt; Portlets</uri><object>Portlets</object><sort>Type Html</sort><count>6</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PORTLET_TYPE&apos;\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       count(*) as count\n
  from cmn_portlets p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.portlet_type_code &lt;&gt; &apos;FAVORITE&apos;\n
 group by p.portlet_type_code</script></Record><Record><uri>Studio &gt; Portlet Pages</uri><object>Portlet Page</object><sort>Default</sort><count>116</count><script>select count(*)\n
  from cmn_pages p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.page_type_code not in (&apos;subtab&apos;, &apos;tab&apos;)\n
   and p.principal_type = &apos;SYSTEM&apos;\n
   and p.page_type_code &lt;&gt; &apos;template&apos;</script></Record><Record><uri>Studio &gt; Portlet Pages</uri><object>Portlet Page</object><sort>All</sort><count>849</count><script>select count(*)\n
  from cmn_pages p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;</script></Record><Record><uri>Studio &gt; Portlet Pages</uri><object>Portlet Page</object><sort>Type Tab</sort><count>612</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PAGE_TYPE_CODE&apos;\n
           and l.lookup_code = p.page_type_code) as type,\n
       count(*) as count\n
  from cmn_pages p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.page_type_code &lt;&gt; &apos;subtab&apos;\n
 group by p.page_type_code</script></Record><Record><uri>Studio &gt; Portlet Pages</uri><object>Portlet Page</object><sort>Type Template</sort><count>3</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PAGE_TYPE_CODE&apos;\n
           and l.lookup_code = p.page_type_code) as type,\n
       count(*) as count\n
  from cmn_pages p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.page_type_code &lt;&gt; &apos;subtab&apos;\n
 group by p.page_type_code</script></Record><Record><uri>Studio &gt; Portlet Pages</uri><object>Portlet Page</object><sort>Type Page</sort><count>89</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PAGE_TYPE_CODE&apos;\n
           and l.lookup_code = p.page_type_code) as type,\n
       count(*) as count\n
  from cmn_pages p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.page_type_code &lt;&gt; &apos;subtab&apos;\n
 group by p.page_type_code</script></Record><Record><uri>Studio &gt; Portlet Pages</uri><object>Portlet Page</object><sort>Type Page Frame</sort><count>139</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;PAGE_TYPE_CODE&apos;\n
           and l.lookup_code = p.page_type_code) as type,\n
       count(*) as count\n
  from cmn_pages p\n
 where p.principal_type &lt;&gt; &apos;USER&apos;\n
   and p.page_type_code &lt;&gt; &apos;subtab&apos;\n
 group by p.page_type_code</script></Record><Record><uri>Studio &gt; UI Themes</uri><object>UI Theme</object><sort>All</sort><count>11</count><script>select count(*) from cmn_ui_themes</script></Record><Record><uri>Studio &gt; Views</uri><object>View</object><sort>All</sort><count>2060</count><script>select count(*) from odf_views</script></Record><Record><uri>Studio &gt; Views</uri><object>View</object><sort>Type property</sort><count>526</count><script>select view_type,\n
       count(*)\n
  from odf_views\n
 group by view_type</script></Record><Record><uri>Studio &gt; Views</uri><object>View</object><sort>Type subObjectList</sort><count>28</count><script>select view_type,\n
       count(*)\n
  from odf_views\n
 group by view_type</script></Record><Record><uri>Studio &gt; Views</uri><object>View</object><sort>Type filter</sort><count>1506</count><script>select view_type,\n
       count(*)\n
  from odf_views\n
 group by view_type</script></Record><Record><uri>Data Administration &gt; Datamart Settings</uri><object>Datamart Setting</object><sort>All</sort><count>6</count><script>select case op.option_code\n
         when &apos;NBI_CURRENCY_CODE&apos; then\n
          &apos;Datamart Currency&apos;\n
         when &apos;NBI_ENTITY_CODE&apos; then\n
          &apos;Datamart Entity&apos;\n
         when &apos;NBI_EXTRACT_PM_PTFS&apos; then\n
          &apos;Extract project management time facts and summary&apos;\n
         when &apos;NBI_EXTRACT_FM_PTFS&apos; then\n
          &apos;Extract financial management time facts and summary&apos;\n
         when &apos;NBI_EXTRACT_RTFS&apos; then\n
          &apos;Extract resource time facts and summary&apos;\n
       end as &quot;name&quot;,\n
       ov.value as &quot;value&quot;\n
  from cmn_options       op,\n
       cmn_option_values ov\n
 where ov.option_id = op.id\n
   and op.option_code in\n
       (&apos;NBI_CURRENCY_CODE&apos;, &apos;NBI_ENTITY_CODE&apos;, &apos;NBI_EXTRACT_PM_PTFS&apos;, &apos;NBI_EXTRACT_FM_PTFS&apos;, &apos;NBI_EXTRACT_RTFS&apos;)\n
   and not ((op.option_code = &apos;NBI_CURRENCY_CODE&apos; and ov.value is null) or\n
        (op.option_code = &apos;NBI_ENTITY_CODE&apos; and ov.value is null) or\n
        (op.option_code = &apos;NBI_EXTRACT_PM_PTFS&apos; and ov.value = 1) or\n
        (op.option_code = &apos;NBI_EXTRACT_FM_PTFS&apos; and ov.value = 1) or\n
        (op.option_code = &apos;NBI_EXTRACT_RTFS&apos; and ov.value = 1))\n
union all\n
select &apos;Project Organizational Breakdown Structure Mapping&apos; as &quot;name&quot;,\n
       (select &apos;OBS : &apos; || t.unique_name || &apos; - Default OBS Unit : &apos; || u.unique_name\n
          from prj_obs_types t,\n
               prj_obs_units u\n
         where u.type_id = t.id\n
           and t.id = c.obs_type_id\n
           and u.id = c.obs_unit_default)\n
  from nbi_cfg_obs_assignments c\n
 where c.object_type = &apos;PROJECT&apos;\n
   and not (c.obs_type_id is null)\n
union all\n
select &apos;Resource Organizational Breakdown Structure Mapping&apos; as &quot;name&quot;,\n
       (select &apos;OBS : &apos; || t.unique_name + &apos; - Default OBS Unit : &apos; || u.unique_name\n
          from prj_obs_types t,\n
               prj_obs_units u\n
         where u.type_id = t.id\n
           and t.id = c.obs_type_id\n
           and u.id = c.obs_unit_default)\n
  from nbi_cfg_obs_assignments c\n
 where c.object_type = &apos;RESOURCE&apos;\n
   and not (c.obs_type_id is null)\n
 order by &quot;name&quot;</script></Record><Record><uri>Data Administration &gt; Datamart Stoplights</uri><object>Datamart Stoplight</object><sort>All</sort><count>0</count><script>select count(*)\n
  from nbi_cfg_stoplight_queries\n
 where redsql is not null</script></Record><Record><uri>Data Administration &gt; Time Slices</uri><object>Time Slice</object><sort>All</sort><count>76</count><script>select count(*)\n
  from prj_blb_slicerequests\n
 where is_visible = 1\n
   and is_template = 0\n
   and is_synchronous = 0</script></Record><Record><uri>Data Administration &gt; Lookups</uri><object>Lookup</object><sort>Default</sort><count>1223</count><script>select count(*)\n
  from cmn_lookup_types   l,\n
       cmn_list_of_values v\n
 where l.lookup_type = v.lookup_type_code\n
   and l.is_admin_visible = 1\n
   and nvl(v.parent_id, 0) = 0\n
   and l.lookup_type not like &apos;ODF.NSQL.%&apos;\n
   and l.lookup_type not like &apos;ODF.OBJECT.%&apos;\n
   and l.lookup_type &lt;&gt; &apos;REQUIREMENT_PRIORITY&apos;</script></Record><Record><uri>Data Administration &gt; Lookups</uri><object>Lookup</object><sort>All</sort><count>2727</count><script>select count(*) from cmn_lookup_types</script></Record><Record><uri>Data Administration &gt; Lookups</uri><object>Lookup</object><sort>Type Static List</sort><count>2153</count><script>select count(*)\n
  from cmn_lookup_types   l,\n
       cmn_list_of_values v\n
 where l.lookup_type = v.lookup_type_code\n
 group by v.lookup_source_code</script></Record><Record><uri>Data Administration &gt; Lookups</uri><object>Lookup</object><sort>Type Static Dependent List</sort><count>10</count><script>select count(*)\n
  from cmn_lookup_types   l,\n
       cmn_list_of_values v\n
 where l.lookup_type = v.lookup_type_code\n
 group by v.lookup_source_code</script></Record><Record><uri>Data Administration &gt; Lookups</uri><object>Lookup</object><sort>Type Dynamic Niku Query</sort><count>561</count><script>select count(*)\n
  from cmn_lookup_types   l,\n
       cmn_list_of_values v\n
 where l.lookup_type = v.lookup_type_code\n
 group by v.lookup_source_code</script></Record><Record><uri>Data Administration &gt; Incidents</uri><object>Incident Category</object><sort>All</sort><count>0</count><script>select count(*) from imm_categories</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>All</sort><count>173</count><script>select count(*) from cmn_sch_job_definitions</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>Type Java</sort><count>71</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>Type XBL</sort><count>7</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>Type PMD</sort><count>5</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>Type SQL Stored Procedure</sort><count>8</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>Type ETL</sort><count>6</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type</script></Record><Record><uri>Data Administration &gt; Reports and Jobs</uri><object>Job</object><sort>Type Report</sort><count>76</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
           and l.id = j.job_type) as type,\n
       count(*) as count\n
  from cmn_sch_job_definitions j\n
 group by j.job_type</script></Record><Record><uri>Data Administration &gt; Skills Hierarchy</uri><object>Skill</object><sort>All</sort><count>3</count><script>select count(*) from rsm_skills</script></Record><Record><uri>Data Administration &gt; Processes</uri><object>Process</object><sort>All</sort><count>152</count><script>select count(*) from bpm_def_processes</script></Record><Record><uri>Data Administration &gt; Processes</uri><object>Process</object><sort>Status On Hold</sort><count>35</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_USER_STATUS&apos;\n
           and l.lookup_code = v.user_status_code) as status,\n
       count(*) as count\n
  from bpm_def_process_versions v\n
 group by v.user_status_code</script></Record><Record><uri>Data Administration &gt; Processes</uri><object>Process</object><sort>Status Active</sort><count>60</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_USER_STATUS&apos;\n
           and l.lookup_code = v.user_status_code) as status,\n
       count(*) as count\n
  from bpm_def_process_versions v\n
 group by v.user_status_code</script></Record><Record><uri>Data Administration &gt; Processes</uri><object>Process</object><sort>Status Draft</sort><count>57</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_USER_STATUS&apos;\n
           and l.lookup_code = v.user_status_code) as status,\n
       count(*) as count\n
  from bpm_def_process_versions v\n
 group by v.user_status_code</script></Record><Record><uri>Data Administration &gt; Audit Trail</uri><object>Audit Trail</object><sort>All</sort><count>2200819</count><script>select count(*) from cmn_audits</script></Record><Record><uri>Data Administration &gt; Process Engines</uri><object>Process Engine</object><sort>All</sort><count>25</count><script>select count(*) from bpm_run_process_engines</script></Record><Record><uri>Finance &gt; Processing</uri><object>Processing</object><sort>All</sort><count>1</count><script>select (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_OPTIONS&apos;\n
           and n.pk_id = op.id) as &quot;name&quot;,\n
       to_char(ov.value) as &quot;value&quot;\n
  from cmn_options       op,\n
       cmn_option_values ov\n
 where ov.option_id = op.id\n
   and op.option_code = &apos;CMN_RETAIN_CURRENCY_PRECISION&apos;\n
   and not ov.value = &apos;1&apos;\n
union all\n
select &apos;Use Multi-Currency&apos; as &quot;name&quot;,\n
       to_char(ov.value) as &quot;value&quot;\n
  from cmn_options       op,\n
       cmn_option_values ov\n
 where ov.option_id = op.id\n
   and op.option_code = &apos;CMN_IS_MULTI_CURRENCY_SYSTEM&apos;\n
   and not ov.value = &apos;0&apos;\n
union all\n
select &apos;Allow Chargeable Override&apos; as &quot;name&quot;,\n
       &apos;&lt;uncheck&gt;&apos; as &quot;value&quot;\n
  from nameoptions o\n
 where not o.allownonchargeableoverride = 1\n
union all\n
select &apos;Hide Financial OBS&apos; as &quot;name&quot;,\n
       to_char(o.filter_financial_obs) as &quot;value&quot;\n
  from nameoptions o\n
 where not o.filter_financial_obs = 0\n
union all\n
select &apos;Entity-based Security&apos; as &quot;name&quot;,\n
       case o.entity_security\n
         when 0 then\n
          &apos;None&apos;\n
         when 1 then\n
          &apos;Strict&apos;\n
         when 2 then\n
          &apos;Parent&apos;\n
       end as &quot;value&quot;\n
  from nameoptions o\n
 where not o.entity_security = 0\n
 order by &quot;name&quot;</script></Record><Record><uri>Finance &gt; Setup</uri><object>Entity</object><sort>All</sort><count>1</count><script>select * from entity</script></Record><Record><uri>Finance &gt; Setup</uri><object>Fiscal Time Period</object><sort>All</sort><count>807</count><script>select count(*) from biz_com_periods</script></Record><Record><uri>Finance &gt; Setup</uri><object>Fiscal Time Period</object><sort>Entity Migrated Entity</sort><count>759</count><script>select e.entity,\n
       count(*)\n
  from biz_com_periods p,\n
       entity          e\n
 where p.entity_id = e.id\n
 group by e.entity</script></Record><Record><uri>Finance &gt; Setup</uri><object>Fiscal Time Period</object><sort>Status Active</sort><count>581</count><script>select case\n
         when is_active = 1 then\n
          &apos;Active&apos;\n
         else\n
          &apos;Inactive&apos;\n
       end,\n
       count(*)\n
  from biz_com_periods\n
 group by is_active</script></Record><Record><uri>Finance &gt; Setup</uri><object>Fiscal Time Period</object><sort>Status Inactive</sort><count>226</count><script>select case\n
         when is_active = 1 then\n
          &apos;Active&apos;\n
         else\n
          &apos;Inactive&apos;\n
       end,\n
       count(*)\n
  from biz_com_periods\n
 group by is_active</script></Record><Record><uri>Finance &gt; Setup</uri><object>Location</object><sort>All</sort><count>1</count><script>select count(*) from locations</script></Record><Record><uri>Finance &gt; Setup</uri><object>Location</object><sort>Entity Migrated Entity</sort><count>1</count><script>select (select e.shortdesc from entity e where id = l.entity_id),\n
       count(*)\n
  from locations l\n
 group by l.entity_id</script></Record><Record><uri>Finance &gt; Setup</uri><object>Vendor</object><sort>All</sort><count>0</count><script>select count(*) from apmaster</script></Record><Record><uri>Finance &gt; Setup</uri><object>Currency</object><sort>All</sort><count>198</count><script>select count(*) from cmn_currencies</script></Record><Record><uri>Finance &gt; Setup</uri><object>Currency</object><sort>Status Active</sort><count>2</count><script>select case\n
         when is_active = 1 then\n
          &apos;Active&apos;\n
         else\n
          &apos;Inactive&apos;\n
       end,\n
       count(*)\n
  from cmn_currencies\n
 group by is_active</script></Record><Record><uri>Finance &gt; Setup</uri><object>Currency</object><sort>Status Inactive</sort><count>196</count><script>select case\n
         when is_active = 1 then\n
          &apos;Active&apos;\n
         else\n
          &apos;Inactive&apos;\n
       end,\n
       count(*)\n
  from cmn_currencies\n
 group by is_active</script></Record><Record><uri>Finance &gt; Setup</uri><object>Foreign Exchange Rate</object><sort>All</sort><count>1</count><script>select count(*) from cmn_exchange_rates</script></Record><Record><uri>Finance &gt; Setup</uri><object>Resource Class</object><sort>All</sort><count>7</count><script>select count(*) from pac_fos_resource_class</script></Record><Record><uri>Finance &gt; Setup</uri><object>Resource Class</object><sort>Type Labor</sort><count>6</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;RPT_TRANSACTION_TYPE&apos;\n
           and l.lookup_code = c.resource_type) as type,\n
       count(*) as count\n
  from pac_fos_resource_class c\n
 group by c.resource_type</script></Record><Record><uri>Finance &gt; Setup</uri><object>Resource Class</object><sort>Type Expenses</sort><count>1</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;RPT_TRANSACTION_TYPE&apos;\n
           and l.lookup_code = c.resource_type) as type,\n
       count(*) as count\n
  from pac_fos_resource_class c\n
 group by c.resource_type</script></Record><Record><uri>Finance &gt; Setup</uri><object>Company Class</object><sort>All</sort><count>1</count><script>select count(*) from clntclass</script></Record><Record><uri>Finance &gt; Setup</uri><object>WIP Class</object><sort>All</sort><count>1</count><script>select count(*) from wipclass</script></Record><Record><uri>Finance &gt; Setup</uri><object>Investment Class</object><sort>All</sort><count>1</count><script>select count(*) from projclass</script></Record><Record><uri>Finance &gt; Setup</uri><object>Transaction Class</object><sort>All</sort><count>40</count><script>select count(*) from transclass</script></Record><Record><uri>Finance &gt; Setup</uri><object>Transaction Class</object><sort>Type Labor</sort><count>13</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;PAC_TRANSACTION_TYPE&apos;\n
           and l.lookup_code = c.transtype) as type,\n
       count(*) as count\n
  from transclass c\n
 group by c.transtype</script></Record><Record><uri>Finance &gt; Setup</uri><object>Transaction Class</object><sort>Type Equipment</sort><count>1</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;PAC_TRANSACTION_TYPE&apos;\n
           and l.lookup_code = c.transtype) as type,\n
       count(*) as count\n
  from transclass c\n
 group by c.transtype</script></Record><Record><uri>Finance &gt; Setup</uri><object>Transaction Class</object><sort>Type Expense</sort><count>26</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;PAC_TRANSACTION_TYPE&apos;\n
           and l.lookup_code = c.transtype) as type,\n
       count(*) as count\n
  from transclass c\n
 group by c.transtype</script></Record><Record><uri>Finance &gt; Cost Plus Codes</uri><object>Cost Plus Code</object><sort>All</sort><count>0</count><script>select count(*) from costplus</script></Record><Record><uri>Finance &gt; Manage Matrix</uri><object>Matrix</object><sort>Default</sort><count>1</count><script>select count(*)\n
  from ppa_matrix\n
 where not matrixkey = 1</script></Record><Record><uri>Finance &gt; Manage Matrix</uri><object>Matrix</object><sort>All</sort><count>2</count><script>select count(*) from ppa_matrix</script></Record><Record><uri>Finance &gt; GL Accounts</uri><object>GL Account</object><sort>All</sort><count>0</count><script>select count(*) from cbk_gl_account</script></Record><Record><uri>Chargebacks &gt; Standard Rules</uri><object>Standard Rule</object><sort>All</sort><count>0</count><script>select count(*)\n
  from cbk_gl_allocation r\n
 where r.chargeback_type = &apos;DEBIT&apos;\n
   and r.chargeback_subtype = &apos;STANDARD&apos;</script></Record><Record><uri>Chargebacks &gt; Overhead Rules</uri><object>Overhead Rule</object><sort>All</sort><count>0</count><script>select count(*)\n
  from cbk_gl_allocation r\n
 where r.chargeback_type = &apos;DEBIT&apos;\n
   and r.chargeback_subtype = &apos;OVERHEAD&apos;</script></Record><Record><uri>Chargebacks &gt; Credit Rules</uri><object>Credit Rule</object><sort>All</sort><count>0</count><script>select count(*)\n
  from cbk_gl_allocation r\n
 where r.chargeback_type = &apos;DEBIT&apos;</script></Record><Record><uri>Chargebacks &gt; Messages</uri><object>Message</object><sort>All</sort><count>0</count><script>select count(*) from cbk_errors</script></Record><Record><uri>Project Management &gt; Time Reporting Periods</uri><object>Time Reporting Period</object><sort>All</sort><count>883</count><script>select count(*) from prtimeperiod</script></Record><Record><uri>Project Management &gt; Time Reporting Periods</uri><object>Time Reporting Period</object><sort>Closed</sort><count>874</count><script>select count(*)\n
  from prtimeperiod\n
 group by prisopen</script></Record><Record><uri>Project Management &gt; Time Reporting Periods</uri><object>Time Reporting Period</object><sort>Open</sort><count>9</count><script>select count(*)\n
  from prtimeperiod\n
 group by prisopen</script></Record><Record><uri>Project Management &gt; Charge Codes</uri><object>Charge Code</object><sort>All</sort><count>2</count><script>select count(*) from prchargecode</script></Record><Record><uri>Project Management &gt; Input Type Codes</uri><object>Input Type Code</object><sort>All</sort><count>2</count><script>select count(*) from prtypecode</script></Record><Record><uri>Project Management &gt; Invalid Transactions</uri><object>Invalid Transaction</object><sort>All</sort><count>0</count><script>select count(*)\n
  from imp_transactionimport\n
 where importstatus = &apos;E&apos;</script></Record><Record><uri>Project Management &gt; Base Calendars</uri><object>Base Calendar</object><sort>Default</sort><count>8</count><script>select count(*)\n
  from prcalendar\n
 where prresourceid is null</script></Record><Record><uri>Project Management &gt; Base Calendars</uri><object>Base Calendar</object><sort>All</sort><count>3315</count><script>select count(*) from prcalendar</script></Record><Record><uri>General Settings &gt; Site Links</uri><object>Site Link</object><sort>All</sort><count>0</count><script>select * from prlink l where l.prtablename = &apos;PRSite&apos;</script></Record><Record><uri>Earned Value Management &gt; Period Definitions</uri><object>EV Period</object><sort>All</sort><count>2</count><script>select * from evm_period_defs</script></Record></QueryResult>

