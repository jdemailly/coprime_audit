<QueryResult order="101" name="Test" description="Application Objects by navigation" th1="URI" th2="Object" th3="Vector" th4="Count" th5="Script"><Record><uri>Personal &gt; Organizer</uri><object>Action</object><sort>All</sort><count>933</count><script>select count(*) from cal_action_items</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Action</object><sort>User xtd_deploy</sort><count>0</count><script>select count(*)\n
  from cal_action_items\n
 where owner_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(&apos;xtd_deploy&apos;))</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Action</object><sort>Type Project</sort><count>884</count><script>select (select name\n
          from cmn_lookups      l,\n
               cmn_captions_nls n\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;CAL_OBJECT_TYPE&apos;\n
           and l.lookup_code = a.object_type) as type,\n
       count(*) as count\n
  from cal_action_items a\n
 group by a.object_type</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Action</object><sort>Type Personal</sort><count>49</count><script>select (select name\n
          from cmn_lookups      l,\n
               cmn_captions_nls n\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;CAL_OBJECT_TYPE&apos;\n
           and l.lookup_code = a.object_type) as type,\n
       count(*) as count\n
  from cal_action_items a\n
 group by a.object_type</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Task</object><sort>All</sort><count>895538</count><script>select count(*) from prtask;\n
select t.prid,\n
       t.prname,\n
       t.prexternalid,\n
       t.created_date\n
  from prtask t\n
 where t.prprojectid is null</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Task</object><sort>User xtd_deploy</sort><count>0</count><script>select count(*)\n
  from prtask        t,\n
       prassignment  a,\n
       srm_resources r,\n
       cmn_sec_users u\n
 where a.prtaskid = t.prid\n
   and a.prresourceid = r.id\n
   and r.user_id = u.id\n
   and nls_upper(u.user_name) = nls_upper(&apos;xtd_deploy&apos;)</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Task</object><sort>Type Project</sort><count>895538</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;INVESTMENT_OBJ_TYPE&apos;\n
           and l.lookup_code = p.investment_code) as type,\n
       count(*) as count\n
  from srm_projects p,\n
       prtask       t\n
 where p.id = t.prprojectid\n
 group by p.investment_code</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Process</object><sort>All</sort><count>1068</count><script>select count(*) from bpm_run_processes</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Process</object><sort>Status Running</sort><count>73</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_INSTANCE_STATES&apos;\n
           and l.lookup_code = p.status_code) as status,\n
       count(*) as count\n
  from bpm_run_processes p\n
 group by p.status_code</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Process</object><sort>Status Aborted</sort><count>970</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_INSTANCE_STATES&apos;\n
           and l.lookup_code = p.status_code) as status,\n
       count(*) as count\n
  from bpm_run_processes p\n
 group by p.status_code</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Process</object><sort>Status Error</sort><count>17</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_INSTANCE_STATES&apos;\n
           and l.lookup_code = p.status_code) as status,\n
       count(*) as count\n
  from bpm_run_processes p\n
 group by p.status_code</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Process</object><sort>Status Done</sort><count>8</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.lookup_type = &apos;BPM_PROCESS_INSTANCE_STATES&apos;\n
           and l.lookup_code = p.status_code) as status,\n
       count(*) as count\n
  from bpm_run_processes p\n
 group by p.status_code</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>All</sort><count>114795</count><script>select count(*) from clb_notifications</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>User xtd_deploy</sort><count>0</count><script>select count(*)\n
  from clb_notifications\n
 where receiver_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(&apos;xtd_deploy&apos;))</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>Type Risks</sort><count>794</count><script>select (select c.name\n
          from cmn_captions_nls c,\n
               cmn_lookups      l\n
         where c.pk_id = l.id\n
           and c.table_name = &apos;CMN_LOOKUPS&apos;\n
           and c.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;NOTIFICATION_TYPE&apos;
           and l.lookup_code = n.event_type) as type,\n
       count(*) as count\n
  from clb_notifications n\n
 group by n.event_type</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>Type Change Requests</sort><count>2134</count><script>select (select c.name\n
          from cmn_captions_nls c,\n
               cmn_lookups      l\n
         where c.pk_id = l.id\n
           and c.table_name = &apos;CMN_LOOKUPS&apos;\n
           and c.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;NOTIFICATION_TYPE&apos;
           and l.lookup_code = n.event_type) as type,\n
       count(*) as count\n
  from clb_notifications n\n
 group by n.event_type</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>Type Timesheets</sort><count>66581</count><script>select (select c.name\n
          from cmn_captions_nls c,\n
               cmn_lookups      l\n
         where c.pk_id = l.id\n
           and c.table_name = &apos;CMN_LOOKUPS&apos;\n
           and c.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;NOTIFICATION_TYPE&apos;
           and l.lookup_code = n.event_type) as type,\n
       count(*) as count\n
  from clb_notifications n\n
 group by n.event_type</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>Type Conversations</sort><count>1</count><script>select (select c.name\n
          from cmn_captions_nls c,\n
               cmn_lookups      l\n
         where c.pk_id = l.id\n
           and c.table_name = &apos;CMN_LOOKUPS&apos;\n
           and c.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;NOTIFICATION_TYPE&apos;
           and l.lookup_code = n.event_type) as type,\n
       count(*) as count\n
  from clb_notifications n\n
 group by n.event_type</script></Record><Record><uri>Personal &gt; Organizer</uri><object>Notification</object><sort>Type Projects</sort><count>45285</count><script>select (select c.name\n
          from cmn_captions_nls c,\n
               cmn_lookups      l\n
         where c.pk_id = l.id\n
           and c.table_name = &apos;CMN_LOOKUPS&apos;\n
           and c.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;NOTIFICATION_TYPE&apos;
           and l.lookup_code = n.event_type) as type,\n
       count(*) as count\n
  from clb_notifications n\n
 group by n.event_type</script></Record><Record><uri>Personal &gt; Dashboards</uri><object>Dashboard</object><sort>All</sort><count>0</count><script>select count(*)\n
  from cmn_pages\n
 where principal_type = &apos;USER&apos;\n
   and source = &apos;customer&apos;\n
   and page_type_code = &apos;page&apos;</script></Record><Record><uri>Personal &gt; Dashboards</uri><object>Dashboard</object><sort>User xtd_deploy</sort><count>0</count><script>select count(*)\n
  from cmn_pages\n
 where principal_type = &apos;USER&apos;\n
   and source = &apos;customer&apos;\n
   and page_type_code = &apos;page&apos;\n
   and principal_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(&apos;xtd_deploy&apos;))</script></Record><Record><uri>Personal &gt; Portlets</uri><object>Portlet</object><sort>All</sort><count>0</count><script>select count(*)\n
  from cmn_portlets\n
 where principal_type = &apos;USER&apos;\n
   and source = &apos;customer&apos;</script></Record><Record><uri>Personal &gt; Portlets</uri><object>Portlet</object><sort>User xtd_deploy</sort><count>0</count><script>select count(*)\n
  from cmn_portlets\n
 where principal_type = &apos;USER&apos;\n
   and source = &apos;customer&apos;\n
   and principal_id = (select id from cmn_sec_users where nls_upper(user_name) = nls_upper(&apos;xtd_deploy&apos;))</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>All</sort><count>841872</count><script>select count(*) from prtimesheet</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timeentry</object><sort>All</sort><count>2715345</count><script>select count(*) from prtimeentry</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Open</sort><count>1785</count><script>select p.prisopen,\n
       count(*)\n
  from prtimesheet  t,\n
       prtimeperiod p\n
 where t.prtimeperiodid = p.prid\n
 group by p.prisopen</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Closed</sort><count>840087</count><script>select p.prisopen,\n
       count(*)\n
  from prtimesheet  t,\n
       prtimeperiod p\n
 where t.prtimeperiodid = p.prid\n
 group by p.prisopen</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Status Submitted</sort><count>514</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;prTimeSheetStatus&apos;\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Status Rejected</sort><count>614</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;prTimeSheetStatus&apos;\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Status Posted</sort><count>791018</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;prTimeSheetStatus&apos;\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Status Adjusted</sort><count>25679</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;prTimeSheetStatus&apos;\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Status Approved</sort><count>2</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;prTimeSheetStatus&apos;\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus</script></Record><Record><uri>Personal &gt; Timesheets</uri><object>Timesheet</object><sort>Status Unsubmitted</sort><count>24045</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;prTimeSheetStatus&apos;\n
           and l.lookup_enum = t.prstatus),\n
       count(*)\n
  from prtimesheet t\n
 group by t.prstatus</script></Record><Record><uri>Personal &gt; Reports and Jobs</uri><object>Job</object><sort>All</sort><count>48</count><script>select count(*) from cmn_sch_jobs</script></Record><Record><uri>Personal &gt; Reports and Jobs</uri><object>Job</object><sort>Status Pending for Process Engine</sort><count>5</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SCH_JOB_STATUS&apos;\n
           and l.lookup_code = j.status_code) as status,\n
       count(*) as count\n
  from cmn_sch_jobs j\n
 group by j.status_code</script></Record><Record><uri>Personal &gt; Reports and Jobs</uri><object>Job</object><sort>Status Cancelled</sort><count>1</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SCH_JOB_STATUS&apos;\n
           and l.lookup_code = j.status_code) as status,\n
       count(*) as count\n
  from cmn_sch_jobs j\n
 group by j.status_code</script></Record><Record><uri>Personal &gt; Reports and Jobs</uri><object>Job</object><sort>Status Completed</sort><count>2</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SCH_JOB_STATUS&apos;\n
           and l.lookup_code = j.status_code) as status,\n
       count(*) as count\n
  from cmn_sch_jobs j\n
 group by j.status_code</script></Record><Record><uri>Personal &gt; Reports and Jobs</uri><object>Job</object><sort>Status Paused</sort><count>4</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SCH_JOB_STATUS&apos;\n
           and l.lookup_code = j.status_code) as status,\n
       count(*) as count\n
  from cmn_sch_jobs j\n
 group by j.status_code</script></Record><Record><uri>Personal &gt; Reports and Jobs</uri><object>Job</object><sort>Status Scheduled</sort><count>36</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SCH_JOB_STATUS&apos;\n
           and l.lookup_code = j.status_code) as status,\n
       count(*) as count\n
  from cmn_sch_jobs j\n
 group by j.status_code</script></Record><Record><uri>Organization &gt; Departments</uri><object>Department</object><sort>All</sort><count>1</count><script>select count(*) from departments</script></Record><Record><uri>Organization &gt; Knowledge Store</uri><object>Knowledge Store</object><sort>All</sort><count>15</count><script>select count(*)\n
  from clb_dms_folders f\n
 where f.folder_type = &apos;StandardFolder&apos;\n
   and f.assoc_obj_type = &apos;NAME&apos;\n
   and f.path_name = &apos;/Root/DMS/KS&apos;</script></Record><Record><uri>Organization &gt; Knowledge Store</uri><object>Folder</object><sort>All</sort><count>55061</count><script>select count(*) from clb_dms_folders</script></Record><Record><uri>Organization &gt; Knowledge Store</uri><object>File</object><sort>All</sort><count>585</count><script>select count(*) from clb_dms_files</script></Record><Record><uri>Organization &gt; Knowledge Store</uri><object>File Store</object><sort>All</sort><count>581</count><script>select count(*) from clb_dms_file_store</script></Record><Record><uri>IT Service Management &gt; Services</uri><object>Service</object><sort>All</sort><count>0</count><script>select count(*)\n
  from srm_projects p\n
 where p.investment_code = &apos;SERVICE&apos;</script></Record><Record><uri>Portfolio Management &gt; Portfolios</uri><object>Portfolio</object><sort>All</sort><count>159</count><script>select * from pfm_portfolios p</script></Record><Record><uri>Portfolio Management &gt; Programs</uri><object>Program</object><sort>All</sort><count>119</count><script>select *\n
  from srm_projects p\n
 where p.is_program = 1</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Project</object><sort>Default</sort><count>1291</count><script>select *\n
  from srm_projects p\n
 where p.investment_code = &apos;PROJECT&apos;\n
   and p.is_active = 1</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Project</object><sort>All</sort><count>17820</count><script>select *\n
  from srm_projects p\n
 where p.investment_code = &apos;PROJECT&apos;</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Project</object><sort>Project Template</sort><count>54</count><script>select p.is_template,\n
       count(*)\n
  from srm_projects p\n
 where p.investment_code = &apos;PROJECT&apos;\n
 group by p.is_template</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Project</object><sort>Project Not Template</sort><count>17766</count><script>select p.is_template,\n
       count(*)\n
  from srm_projects p\n
 where p.investment_code = &apos;PROJECT&apos;\n
 group by p.is_template</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Project</object><sort>Project Active</sort><count>1291</count><script>select p.is_active,\n
       count(*)\n
  from srm_projects p\n
 where p.investment_code = &apos;PROJECT&apos;\n
 group by p.is_active</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Project</object><sort>Project Not Active</sort><count>16529</count><script>select p.is_active,\n
       count(*)\n
  from srm_projects p\n
 where p.investment_code = &apos;PROJECT&apos;\n
 group by p.is_active</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Task</object><sort>All</sort><count>895538</count><script>select count(*)\n
  from prtask       t,\n
       srm_projects p\n
 where t.prprojectid = p.id\n
   and p.investment_code = &apos;PROJECT&apos;</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Assignment</object><sort>All</sort><count>684131</count><script>select count(*)\n
  from prassignment a,\n
       prtask       t,\n
       srm_projects p\n
 where a.prtaskid = t.prid\n
   and t.prprojectid = p.id\n
   and p.investment_code = &apos;PROJECT&apos;</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Risk</object><sort>All</sort><count>1476</count><script>select count(*)\n
  from rim_risks_and_issues r\n
 where r.table_name = &apos;SRM_PROJECTS&apos;\n
   and r.type_code = &apos;RISK&apos;</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Issue</object><sort>All</sort><count>53</count><script>select count(*)\n
  from rim_risks_and_issues r\n
 where r.table_name = &apos;SRM_PROJECTS&apos;\n
   and r.type_code = &apos;ISSUE&apos;</script></Record><Record><uri>Portfolio Management &gt; Projects</uri><object>Change Request</object><sort>All</sort><count>3140</count><script>select count(*)\n
  from rim_risks_and_issues r\n
 where r.table_name = &apos;SRM_PROJECTS&apos;\n
   and r.type_code = &apos;CHANGE&apos;</script></Record><Record><uri>Portfolio Management &gt; Applications</uri><object>Application</object><sort>All</sort><count>0</count><script>select *\n
  from srm_projects p\n
 where p.investment_code = &apos;APPLICATION&apos;</script></Record><Record><uri>Portfolio Management &gt; Assets</uri><object>Asset</object><sort>All</sort><count>0</count><script>select *\n
  from srm_projects p\n
 where p.investment_code = &apos;ASSET&apos;</script></Record><Record><uri>Portfolio Management &gt; Products</uri><object>Product</object><sort>All</sort><count>0</count><script>select *\n
  from srm_projects p\n
 where p.investment_code = &apos;PRODUCT&apos;</script></Record><Record><uri>Portfolio Management &gt; Other Work</uri><object>Other Work</object><sort>All</sort><count>1</count><script>select *\n
  from srm_projects p\n
 where p.investment_code = &apos;OTHER&apos;</script></Record><Record><uri>Portfolio Management</uri><object>Cost Plan</object><sort>All</sort><count>117617</count><script>select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = &apos;FORECAST&apos;</script></Record><Record><uri>Portfolio Management</uri><object>Cost Plan</object><sort>Details</sort><count>1724968</count><script>select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = &apos;FORECAST&apos;</script></Record><Record><uri>Portfolio Management</uri><object>Benefit Plan</object><sort>All</sort><count>0</count><script>select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code is null</script></Record><Record><uri>Portfolio Management</uri><object>Benefit Plan</object><sort>Details</sort><count>0</count><script>select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and p.plan_type_code is null</script></Record><Record><uri>Portfolio Management</uri><object>Budget Plan</object><sort>All</sort><count>106495</count><script>select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = &apos;BUDGET&apos;</script></Record><Record><uri>Portfolio Management</uri><object>Budget Plan</object><sort>Details</sort><count>1566141</count><script>select count(*)\n
  from srm_projects p,\n
       fin_plans    f\n
 where p.id = f.object_id\n
   and f.plan_type_code = &apos;BUDGET&apos;</script></Record><Record><uri>Portfolio Management</uri><object>Scenario</object><sort>All</sort><count>12</count><script>select count(*)\n
  from cap_scenarios s,\n
       cmn_sec_users u\n
 where s.user_id = u.id</script></Record><Record><uri>Requirements Planning &gt; Release Planning</uri><object>Release Planning</object><sort>All</sort><count>0</count><script>select count(*) from rqp_release_plans</script></Record><Record><uri>Requirements Planning &gt; Releases</uri><object>Release</object><sort>All</sort><count>0</count><script>select count(*) from rqp_releases</script></Record><Record><uri>Requirements Planning &gt; Requirements</uri><object>Requirement</object><sort>All</sort><count>0</count><script>select count(*) from rqp_requirements</script></Record><Record><uri>Demand Management &gt; Ideas</uri><object>Idea</object><sort>All</sort><count>0</count><script>select count(*)\n
  from srm_projects p\n
 where p.investment_code = &apos;IDEA&apos;</script></Record><Record><uri>Demand Management &gt; Incidents</uri><object>Incident</object><sort>All</sort><count>0</count><script>select count(*) from imm_incidents</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>All</sort><count>16520</count><script>select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Active</sort><count>3177</count><script>select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
   and r.is_active = 1</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Type Expense</sort><count>7</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;RESOURCE_TYPE&apos;\n
           and l.lookup_enum = r.resource_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.resource_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Type Labor</sort><count>16513</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;RESOURCE_TYPE&apos;\n
           and l.lookup_enum = r.resource_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.resource_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Person Type Employee</sort><count>8813</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SRM_RESOURCE_TYPE&apos;\n
           and l.id = r.person_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.person_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Person Type Stagiaire</sort><count>13</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SRM_RESOURCE_TYPE&apos;\n
           and l.id = r.person_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.person_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Person Type Contractor</sort><count>7687</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SRM_RESOURCE_TYPE&apos;\n
           and l.id = r.person_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.person_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Resource</object><sort>Person Type </sort><count>7</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;SRM_RESOURCE_TYPE&apos;\n
           and l.id = r.person_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 0\n
 group by r.person_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Role</object><sort>All</sort><count>1511</count><script>select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Role</object><sort>Active</sort><count>305</count><script>select count(*)\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1\n
   and r.is_active = 1</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Role</object><sort>Type Expense</sort><count>3</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;RESOURCE_TYPE&apos;\n
           and l.lookup_enum = r.resource_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1\n
 group by r.resource_type</script></Record><Record><uri>Resource Management &gt; Resources</uri><object>Role</object><sort>Type Labor</sort><count>1508</count><script>select (select n.name\n
          from cmn_captions_nls n,\n
               cmn_lookups      l\n
         where n.pk_id = l.id\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and n.language_code = &apos;en&apos;\n
           and l.lookup_type = &apos;RESOURCE_TYPE&apos;\n
           and l.lookup_enum = r.resource_type) as type,\n
       count(*) as count\n
  from srm_resources r,\n
       prj_resources rp\n
 where r.id = rp.prid\n
   and rp.prisrole = 1\n
 group by r.resource_type</script></Record><Record><uri>Resource Management &gt; Resource Requisitions</uri><object>Requisition</object><sort>All</sort><count>0</count><script>select count(*) from rsm_req_requisitions</script></Record><Record><uri>Financial Management &gt; Transactions</uri><object>Transaction</object><sort>All</sort><count>0</count><script>select count(*) from ppa_wip</script></Record><Record><uri>Financial Management &gt; Invoices</uri><object>Invoice</object><sort>All</sort><count>0</count><script>select count(*) from cbk_invoice</script></Record><Record><uri>Financial Management &gt; Companies</uri><object>Company</object><sort>All</sort><count>1</count><script>select count(*) from srm_companies</script></Record></QueryResult>

