<QueryResult order="43" name="Time Slice" description="Detects duplicates in time slices" action="Remove Duplicates in Queries and SQL Objects" th01="Slice" th02="Field" th03="Period" th04="Rollover" th05="From" th06="To" th07="Number" th08="Count" th09="Percent" th10="Flag"></QueryResult>

