<QueryResult order="51" name="Studio" description="Detect Display Mapping with no Mappings" action="Run Script" script="begin\n
  delete from odf_display_mappings d\n
   where not exists (select 1 from odf_mappings m where m.display_mappings_id = d.id);\n
  commit;\n
end;" th1="Type" th2="Object Code" th3="Object Name" th4="Attribute Code" th5="Attribute Name" th6="Logo" th7="Flag"></QueryResult>

