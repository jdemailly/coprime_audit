<QueryResult order="52" name="Studio" description="Detect PMA_PORTFOLIO portlets which are Removed in 13.2" action="XOG Out Portlets in Previous Environment\nMake Changes for PFM_PORTFOLIO\nXOG In Portlets in New Environment" th1="Code" th2="Name" th3="Type" th4="Dal Type" th5="Query Code" th6="Flag"></QueryResult>

