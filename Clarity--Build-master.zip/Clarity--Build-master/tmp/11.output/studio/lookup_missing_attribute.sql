<QueryResult order="52" name="Studio" description="Detect Attributes on objects with missing lookups" action="Delete attributes for each object Administration &gt; Studio &gt; Objects or create lookup correctly" th1="Object" th2="Name" th3="Code" th4="Name" th5="Lookup" th6="Flag"></QueryResult>

