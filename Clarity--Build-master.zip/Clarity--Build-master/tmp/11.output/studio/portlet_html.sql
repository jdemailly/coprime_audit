<QueryResult order="51" name="Studio" description="Detect HTML portlets which need an update" action="Make following changes in Administration &gt; Studio &gt; Portlets :\n\t- Replace document.write by innerHTML\n\t- Replace app?action by nu#action\n\t- Remove link action:jre.installation" th1="Code" th2="Name" th3="Script"><Record><code>ma_verrous</code><name>Verrous</name><script>select p.portlet_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;CMN_PORTLETS&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       h.html_text as &quot;text&quot;\n
  from cmn_html_retrieve_services h,\n
       cmn_portlets               p\n
 where h.portlet_id = p.id\n
   and h.id = 5000000;</script></Record><Record><code>xtd_xog_client</code><name>Système - Client XOG</name><script>select p.portlet_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;CMN_PORTLETS&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       h.html_text as &quot;text&quot;\n
  from cmn_html_retrieve_services h,\n
       cmn_portlets               p\n
 where h.portlet_id = p.id\n
   and h.id = 5001024;</script></Record></QueryResult>

