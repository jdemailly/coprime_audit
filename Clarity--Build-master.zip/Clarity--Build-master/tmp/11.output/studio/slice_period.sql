<QueryResult order="44" name="Time Slice" description="Detects Time Slices with 0 Period" action="Set at Least 1 Period" th01="Slice" th02="Field" th03="Period" th04="Rollover" th05="From" th06="To" th07="Flag"></QueryResult>

