<QueryResult order="63" name="Studio" description="Detects custom attributes of type attachment" action="See if filestoring system is on server or in database\nIf upgrading on different server, need to copy files and rebuild their index" script="admin search recreate-index-files\nadmin search recreate-index-data" th1="Object" th2="Attribute" th3="Name" th4="Flag" th5="Script"><Record><object>change</object><attribute>ma_document</attribute><name>Document</name><script>select f.name as &quot;name&quot;,\n
       f.mime_type as &quot;type&quot;,\n
       d.path_name as &quot;path&quot;,\n
       substr(v.id, 2, 3) || &apos;/00&apos; || substr(v.id, 1, 1) || &apos;/&apos; || v.id as &quot;folder&quot;\n
  from odf_ca_change        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.ma_document = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id</script></Record><Record><object>actionitem</object><attribute>ma_piece_jointe</attribute><name>Pièce jointe</name><script>select f.name as &quot;name&quot;,\n
       f.mime_type as &quot;type&quot;,\n
       d.path_name as &quot;path&quot;,\n
       substr(v.id, 2, 3) || &apos;/00&apos; || substr(v.id, 1, 1) || &apos;/&apos; || v.id as &quot;folder&quot;\n
  from odf_ca_actionitem        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.ma_piece_jointe = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id</script></Record><Record><object>inv</object><attribute>odf_asr_template</attribute><name>Status Report Template</name><script>select f.name as &quot;name&quot;,\n
       f.mime_type as &quot;type&quot;,\n
       d.path_name as &quot;path&quot;,\n
       substr(v.id, 2, 3) || &apos;/00&apos; || substr(v.id, 1, 1) || &apos;/&apos; || v.id as &quot;folder&quot;\n
  from odf_ca_inv        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.ODF_ASR_TEMPLATE = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id</script></Record><Record><object>inv</object><attribute>odf_asr_reports</attribute><name>Status Reports</name><script>select f.name as &quot;name&quot;,\n
       f.mime_type as &quot;type&quot;,\n
       d.path_name as &quot;path&quot;,\n
       substr(v.id, 2, 3) || &apos;/00&apos; || substr(v.id, 1, 1) || &apos;/&apos; || v.id as &quot;folder&quot;\n
  from odf_ca_inv        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.ODF_ASR_REPORTS = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id</script></Record><Record><object>xtd_res_leave_file</object><attribute>xtd_attachment</attribute><name>Attachment</name><script>select f.name as &quot;name&quot;,\n
       f.mime_type as &quot;type&quot;,\n
       d.path_name as &quot;path&quot;,\n
       substr(v.id, 2, 3) || &apos;/00&apos; || substr(v.id, 1, 1) || &apos;/&apos; || v.id as &quot;folder&quot;\n
  from odf_ca_xtd_res_leave_file        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.xtd_attachment = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id</script></Record><Record><object>cop_prj_statusrpt</object><attribute>cop_pdf_file</attribute><name>Attachment</name><script>select f.name as &quot;name&quot;,\n
       f.mime_type as &quot;type&quot;,\n
       d.path_name as &quot;path&quot;,\n
       substr(v.id, 2, 3) || &apos;/00&apos; || substr(v.id, 1, 1) || &apos;/&apos; || v.id as &quot;folder&quot;\n
  from odf_ca_cop_prj_statusrpt        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.cop_pdf_file = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id</script></Record></QueryResult>

