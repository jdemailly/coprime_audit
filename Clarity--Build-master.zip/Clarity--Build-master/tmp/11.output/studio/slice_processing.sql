<QueryResult order="43" name="Time Slice" description="Detects time slices being processed" action="Run Time Slicing Job until no more time slice is done" th1="Name" th2="Table" th3="Status" th4="Completed Date" th5="Active" th6="System" th7="Flag" th8="Script"></QueryResult>

