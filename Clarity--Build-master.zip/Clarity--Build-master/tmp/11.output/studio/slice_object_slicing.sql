<QueryResult order="42" name="Time Slice" description="Detect Objects that are being sliced" action="Wait for Time Slicing Job to end or apply given script to reset slices" th1="Object" th2="Count" th3="Flag" th4="Script"></QueryResult>

