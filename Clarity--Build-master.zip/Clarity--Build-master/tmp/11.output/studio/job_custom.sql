<QueryResult order="68" name="Studio" description="Custom Jobs" action="Analyze Each Job if Needed" script="with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Job Custom\n
select d.job_code as code,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_SCH_JOB_DEFINITIONS&apos;\n
           and n.pk_id = d.id) as name,\n
       (select n.name\n
          from cmn_captions_nls n\n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = &apos;SCH_JOB_TYPE&apos;\n
         where n.language_code = &apos;en&apos;\n
           and n.table_name = &apos;CMN_LOOKUPS&apos;\n
           and l.id = d.job_type) as type,\n
       d.last_updated_date,\n
       (select full_name from srm_resources where user_id = d.last_updated_by) as last_updated_by\n
  from cmn_sch_job_definitions d\n
 where d.last_updated_date &gt;= (select min(h.installed_date) from cmn_install_history h where h.install_id in (&apos;release_version&apos;, &apos;database&apos;))\n
   and not exists (select 1 from install where d.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by d.job_code" th1="Code" th2="Name" th3="Type" th4="Updated Date" th5="Updated By"><Record><code>CSK_ADM_AnonymizePII</code><name>Anonymize Personally Identifiable Information (PII)</name><type>ETL</type><last_updated_date>2020-11-13</last_updated_date><last_updated_by>BEN AISSOU.ext, Salah-2053</last_updated_by></Record><Record><code>EXECUTE_AGGR_CLEANUP_JOB</code><name>Purge Temporary Aggregated Data</name><type>Java</type><last_updated_date>2006-08-30</last_updated_date><last_updated_by>Clarity, Administrateur</last_updated_by></Record><Record><code>EXECUTE_AGGREGATION_JOB</code><name>Update Aggregated Data</name><type>Java</type><last_updated_date>2006-08-09</last_updated_date><last_updated_by>Clarity, Administrateur</last_updated_by></Record></QueryResult>

