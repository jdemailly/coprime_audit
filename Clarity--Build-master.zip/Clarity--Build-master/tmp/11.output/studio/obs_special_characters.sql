<QueryResult order="53" name="Studio" description="Detect OBS Name with special characters in it /:&quot;&lt;&gt;" action="Change OBS Name for each OBS found" script="begin\n
  dbms_output.put_line(&apos;Replacing quote by nyphen in departments table.&apos;);\n
  update departments\n
     set shortdesc = translate(shortdesc, &apos;/:&quot;&lt;&gt;&apos;, &apos;-&apos;)\n
   where (instr(shortdesc, &apos;/&apos;) &gt; 0 or instr(shortdesc, &apos;:&apos;) &gt; 0 or instr(shortdesc, &apos;&quot;&apos;) &gt; 0 or\n
         instr(shortdesc, &apos;&lt;&apos;) &gt; 0 or instr(shortdesc, &apos;&gt;&apos;) &gt; 0);\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  dbms_output.put_line(&apos;Replacing quote by nyphen in locations table.&apos;);\n
  update locations\n
     set shortdesc = translate(shortdesc, &apos;/:&quot;&lt;&gt;&apos;, &apos;-&apos;)\n
   where (instr(shortdesc, &apos;/&apos;) &gt; 0 or instr(shortdesc, &apos;:&apos;) &gt; 0 or instr(shortdesc, &apos;&quot;&apos;) &gt; 0 or\n
         instr(shortdesc, &apos;&lt;&apos;) &gt; 0 or instr(shortdesc, &apos;&gt;&apos;) &gt; 0);\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  dbms_output.put_line(&apos;Replacing quote by nyphen in prj_obs_units table.&apos;);\n
  update prj_obs_units\n
     set name = translate(name, &apos;/:&quot;&lt;&gt;&apos;, &apos;-&apos;)\n
   where (instr(name, &apos;/&apos;) &gt; 0 or instr(name, &apos;:&apos;) &gt; 0 or instr(name, &apos;&quot;&apos;) &gt; 0 or instr(name, &apos;&lt;&apos;) &gt; 0 or\n
         instr(name, &apos;&gt;&apos;) &gt; 0);\n
  dbms_output.put_line(sql%rowcount || &apos; update(s) done.&apos;);\n
  commit;\n
end;" th1="Type ID" th2="Type Code" th3="Type Name" th4="ID" th5="Code" th6="Name" th7="Path"></QueryResult>

