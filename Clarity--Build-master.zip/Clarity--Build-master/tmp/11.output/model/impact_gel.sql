<QueryResult order="91" name="GEL" description="Detect Potential Impact on Processes" action="Analyze each process and see if there is an impact during migration" th1="Code" th2="Name" th3="Description" th4="Updated By" th5="Updated" th6="Script"><Record><code>ma_ctrl</code><name>Supervision</name><description> </description><last_user>MAIKOOUVA.ext, Jean-Luc</last_user><last_updated_date>2023-05-03</last_updated_date><script>select p.process_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;BPM_DEF_PROCESSES&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       st.step_code as &quot;step&quot;,\n
       a.action_code as &quot;action&quot;,\n
       s.script_text as &quot;script&quot;\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = 5108990;</script></Record><Record><code>ma_ctrl_auto</code><name>Supervision (AUTO)</name><description> </description><last_user>MAIKOOUVA.ext, Jean-Luc</last_user><last_updated_date>2023-04-24</last_updated_date><script>select p.process_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;BPM_DEF_PROCESSES&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       st.step_code as &quot;step&quot;,\n
       a.action_code as &quot;action&quot;,\n
       s.script_text as &quot;script&quot;\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = 5109991;</script></Record><Record><code>ma_ctrl_v2</code><name>Supervision v2</name><description> </description><last_user>NOUHAUD.ext, Daniel</last_user><last_updated_date>2022-09-29</last_updated_date><script>select p.process_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;BPM_DEF_PROCESSES&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       st.step_code as &quot;step&quot;,\n
       a.action_code as &quot;action&quot;,\n
       s.script_text as &quot;script&quot;\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = 5111031;</script></Record><Record><code>ma_ctrl_arch</code><name>Supervision - Archive 20230424</name><description> </description><last_user>MAIKOOUVA.ext, Jean-Luc</last_user><last_updated_date>2023-04-24</last_updated_date><script>select p.process_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;BPM_DEF_PROCESSES&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       st.step_code as &quot;step&quot;,\n
       a.action_code as &quot;action&quot;,\n
       s.script_text as &quot;script&quot;\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = 5120051;</script></Record><Record><code>ma_ctrl_auto_arch</code><name>Supervision (AUTO) - Archive 20230424</name><description> </description><last_user>MAIKOOUVA.ext, Jean-Luc</last_user><last_updated_date>2023-04-24</last_updated_date><script>select p.process_code as &quot;code&quot;,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = &apos;BPM_DEF_PROCESSES&apos;\n
           and n.language_code = &apos;en&apos;) as &quot;name&quot;,\n
       st.step_code as &quot;step&quot;,\n
       a.action_code as &quot;action&quot;,\n
       s.script_text as &quot;script&quot;\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = 5120052;</script></Record></QueryResult>

