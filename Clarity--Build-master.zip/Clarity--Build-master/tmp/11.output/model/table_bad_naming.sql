<QueryResult order="93" name="Oracle Custom Objects" description="Detect Custom Tables with a bad naming (dot)" action="Rename table or drop it" th1="Name" th2="Created" th3="Flag" th4="Script"></QueryResult>

