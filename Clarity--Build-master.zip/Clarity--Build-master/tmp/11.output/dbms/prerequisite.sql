<QueryResult order="21" name="Oracle" description="Oracle Prerequisites for Clarity" action="Check each NOK prerequisite and apply given SQL script" th1="Rule" th2="Flag" th3="Script"><Record><rule>Database Character Set must be AL32UTF8 since 13.0</rule><flag>OK</flag><script>Reinstall Oracle Instance</script></Record><Record><rule>Database National Character Set must be UTF8/AL16UTF16</rule><flag>OK</flag><script>Reinstall Oracle Instance</script></Record><Record><rule>Instance Database Parameter NLS_SORT must be BINARY</rule><flag>OK</flag><script>alter system set nls_sort = binary scope = spfile;</script></Record><Record><rule>Instance Database Parameter NLS_COMP must be BINARY</rule><flag>OK</flag><script>alter system set nls_comp = binary scope = spfile;</script></Record><Record><rule>Instance Database Parameter NLS_DATE_FORMAT must be &apos;YYYY-MM-DD HH24:MI:SS&apos;</rule><flag>OK</flag><script>alter system set nls_date_format = &apos;YYYY-MM-DD HH24:MI:SS&apos; scope = spfile;</script></Record><Record><rule>User NIKUPRD must have privilege ALTER SESSION since 13.0</rule><flag>OK</flag><script>grant alter session to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege CREATE SESSION</rule><flag>OK</flag><script>grant create session to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege CREATE TABLE</rule><flag>OK</flag><script>grant create table to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege CREATE PROCEDURE since 13.2</rule><flag>OK</flag><script>grant create procedure to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege CREATE JOB since 14.2</rule><flag>OK</flag><script>grant create job to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege CREATE TRIGGER</rule><flag>OK</flag><script>grant create trigger to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege CREATE VIEW</rule><flag>OK</flag><script>grant create view to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege QUERY REWRITE</rule><flag>OK</flag><script>grant query rewrite to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have privilege UNLIMITED TABLESPACE</rule><flag>OK</flag><script>grant unlimited tablespace to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have role CONNECT</rule><flag>OK</flag><script>grant connect to NIKUPRD;</script></Record><Record><rule>User NIKUPRD must have role RESOURCE</rule><flag>OK</flag><script>grant resource to NIKUPRD;</script></Record><Record><rule>Statistics must be Gathered if older than 15 days</rule><flag>NOK</flag><script>begin\n\tcmn_job_analyze_sp(p_job_run_id =&gt; 1, p_job_user_id =&gt; 1, p_db_schema =&gt; user);\nend;</script></Record><Record><rule>Parameter QUERY_REWRITE_ENABLED must be Set to True</rule><flag>WARN</flag><script>declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(&apos;QUERY_REWRITE_ENABLED&apos;, i, s);\n
  dbms_output.put_line(&apos;QUERY_REWRITE_ENABLED : &apos; || s);\n
end;\n
\n
alter system set query_rewrite_enabled = true scope = spfile;</script></Record><Record><rule>Parameter CURSOR_SHARING must be Set to FORCE</rule><flag>WARN</flag><script>declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(&apos;CURSOR_SHARING&apos;, i, s);\n
  dbms_output.put_line(&apos;CURSOR_SHARING : &apos; || s);\n
end;\n
\n
alter system set cursor_sharing = FORCE scope = spfile;</script></Record><Record><rule>Parameter _B_TREE_BITMAP_PLANS must be Set to False</rule><flag>WARN</flag><script>declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(&apos;_B_TREE_BITMAP_PLANS&apos;, i, s);\n
  dbms_output.put_line(&apos;_B_TREE_BITMAP_PLANS : &apos; || i);\n
end;\n
\n
alter system set &quot;_b_tree_bitmap_plans&quot; = false scope = spfile;</script></Record><Record><rule>Parameter OPTIMIZER_MODE must be Set to ALL_ROWS</rule><flag>WARN</flag><script>declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(&apos;OPTIMIZER_MODE&apos;, i, s);\n
  dbms_output.put_line(&apos;OPTIMIZER_MODE : &apos; || s);\n
end;\n
\n
alter system set optimizer_mode = ALL_ROWS scope = spfile;</script></Record></QueryResult>

