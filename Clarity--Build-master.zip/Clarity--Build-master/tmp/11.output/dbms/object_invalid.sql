<QueryResult order="24" name="Oracle" description="Detect Oracle Invalid Objects on current schema" action="Run following script to recompile all objects on current schema and analyze each invalid object" script="declare\n
  cursor my_sqls is\n
    select case\n
             when o.object_type in (&apos;PACKAGE&apos;, &apos;PROCEDURE&apos;, &apos;FUNCTION&apos;, &apos;TRIGGER&apos;, &apos;VIEW&apos;, &apos;TYPE&apos;) then\n
              &apos;alter &apos; || lower(o.object_type) || &apos; &apos; || lower(o.object_name) || &apos; compile&apos;\n
             when o.object_type = &apos;PACKAGE BODY&apos; then\n
              &apos;alter package &apos; || lower(o.object_name) || &apos; compile body&apos;\n
           end as script\n
      from user_objects o\n
     where not o.status = &apos;VALID&apos;\n
     order by o.object_name;\n
begin\n
  for my_sql in my_sqls loop\n
    execute immediate my_sql.script;\n
  end loop;\n
end;" th1="Name" th2="Type" th3="Status" th4="Flag" th5="Script"><Record><name>NBI_EXTR_PCF_SP</name><type>PROCEDURE</type><status>INVALID</status><flag>WARN</flag><script>alter procedure nbi_extr_pcf_sp compile</script></Record><Record><name>NBI_PROJECT_CURRENT_FACTS_SP</name><type>PROCEDURE</type><status>INVALID</status><flag>WARN</flag><script>alter procedure nbi_project_current_facts_sp compile</script></Record><Record><name>NBI_EXTRACT_SP</name><type>PROCEDURE</type><status>INVALID</status><flag>WARN</flag><script>alter procedure nbi_extract_sp compile</script></Record></QueryResult>

