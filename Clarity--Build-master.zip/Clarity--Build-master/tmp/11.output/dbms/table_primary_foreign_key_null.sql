<QueryResult order="25" name="Oracle" description="Table records with primary or foreign key null" action="Delete row" th1="Table" th2="Columns" th3="Count" th4="Flag" th5="Script"></QueryResult>

