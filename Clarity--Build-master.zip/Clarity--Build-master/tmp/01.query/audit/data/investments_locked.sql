/*
OBJECTIVE
  - Get Locked Investments
  - Go to the OOTB page nu#action:security.locks or run custom script
HISTORY
  - 2014-04-17 : CoPrime (DMA) - Init
BUSINESS RULES
  - inv_investments.progress               : Lookup INVESTMENT_OBJ_PROGRESS
  - prlock.prtablename = 'SRM_PROJECTS'    : Lock on Investments
  - prlock.prrecordid = inv_investments.id : Link between Investment and Lock
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '42' as "order",
         'Investments' as "name",
         'Shows locked investments' as "description",
         'begin\n
  dbms_output.put_line(''Deleting from prlock table...'');\n
  delete from prlock where prtablename = ''SRM_PROJECTS'';\n
  dbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n
  commit;\n
end;' as "script",
         'Run custom script to remove locks' as "action",
         'Code' as "th1",
         'Name' as "th2",
         'Type' as "th3",
         'Since' as "th4",
         'Progress' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "type", "since", "progress"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '42' as "@order",
       'Investments' as "@name",
       'Shows locked investments' as "@description",
       'begin\n  print ''Deleting from prlock table...'';\n  delete from prlock where prtablename = ''SRM_PROJECTS'';\n  print cast(@@rowcount as varchar) + '' delete(s) done.'';\nend;' as "@script",
       'Run custom script to remove locks' as "@action",
       'Code' as "@th1",
       'Name' as "@th2",
       'Type' as "@th3",
       'Since' as "@th4",
       'Progress' as "@th5",
       (select t.*
          from (:SQLSERVER@
         
select i.code as "code",
       i.name as "name",
       i.odf_object_code as "type",
       l.prlockedsince as "since",
       (select name
          from cmn_captions_nls n,
               cmn_lookups      l
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = '@P_LANGUAGE@'
           and l.lookup_type = 'INVESTMENT_OBJ_PROGRESS'
           and l.lookup_enum = i.progress) as "progress"
  from prlock          l,
       inv_investments i
 where l.prrecordid = i.id
   and l.prtablename = 'SRM_PROJECTS'

@ORACLE:
order by i.code):ORACLE@

@SQLSERVER:) t order by t."code"
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@