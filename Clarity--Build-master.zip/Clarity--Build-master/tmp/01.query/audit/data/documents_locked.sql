/*
OBJECTIVE
  - Document : Locked Documents
HISTORY
  - 2016-06-03 : CoPrime (DMA) - Init
  - 2016-09-15 : CoPrime (DMA) - Add Quota
BUSINESS RULES
  - clb_dms_files.lock_owner_id : Locked by User
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 13.x, 14.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Documents' as "name",
         'Shows locked documents' as "description",
         'begin\n
  dbms_output.put_line(''Updating clb_dms_files table...'');\n
  update clb_dms_files f set f.lock_owner_id = null, f.lock_time_stamp = null where f.lock_owner_id <> 0;\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;' as "script",
         'Run custom script to remove locks' as "action",
         'Name' as "th1",
         'Mime Type' as "th2",
         'Since' as "th3",
         'By' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest(name, mime_type, lock_time_stamp, lock_by))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '43' as "@order",
       'Documents' as "@name",
       'Shows locked documents' as "@description",
       'begin\n
  print ''Updating clb_dms_files table...'';\n
  update clb_dms_files f set f.lock_owner_id = null, f.lock_time_stamp = null where f.lock_owner_id <> 0;\n
  print cast(@@rowcount as varchar) + '' update(s) done.'';\n
end;' as "@script",
       'Run custom script to remove locks' as "@action",
       'Name' as "@th1",
       'Type' as "@th2",
       'Since' as "@th3",
       'By' as "@th4",
       (select t.*
          from (:SQLSERVER@

select f.name                  as name,
       @NVL@(f.mime_type, ' ') as mime_type,
       f.lock_time_stamp       as lock_time_stamp,
       r.full_name             as lock_by
  from clb_dms_files f
 inner join srm_resources r on r.user_id = f.lock_owner_id
 where f.lock_owner_id <> 0

@ORACLE:
order by f.name):ORACLE@

@SQLSERVER:) t order by t.name
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@