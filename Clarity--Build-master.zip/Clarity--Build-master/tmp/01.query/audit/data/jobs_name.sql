/*
OBJECTIVE
  - Bug CLRT-73622 : Get Scheduled Jobs with Quotes in their name
  - Action : Remove quotes in name, problem with 'Allocation Investment' jobs
HISTORY
  - 2014-04-25 : CoPrime (DMA) - Init
  - 2015-06-29 : CoPrime (DMA) - Fix SQL Server Update
  - 2016-08-01 : CoPrime (DMA) - Index CMN_LOOKUPS_U3
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
       '45' as "order",
       'Jobs' as "name",
		   'Scheduled Jobs with quotes in their name' as "description",
		   'Rename Job Name to remove quote' as "action",
	     'Name' as "th1",
	     'Code' as "th2",
	     'Type Code' as "th3",
	     'Type Name' as "th4",
	     'Flag' as "th5",
	     'Script' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "code", "type_code", "type_name", "flag", "script"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '45' as "@order",
       'Jobs' as "@name",
       'Scheduled Jobs with quotes in their name' as "@description",
       'Rename Job Name to remove quote' as "@action",
       'Name' as "@th1",
       'Code' as "@th2",
       'Type Code' as "@th3",
       'Type Name' as "@th4",
       'Flag' as "@th5",
       'Script' as "@th6",
       (select t.*
          from (:SQLSERVER@

--Main
select j.name as "name",
       d.job_code as "code",
       d.job_type as "type_code",
       (select l.lookup_code
          from cmn_lookups l
         where l.lookup_type = 'SCH_JOB_TYPE'
           and l.id = d.job_type) as "type_name",
       'NOK' as "flag",
       @ORACLE:'begin\n\tupdate cmn_sch_jobs set name = replace(name, '''''', '' '') where j.id = ' || j.id || ';\nend;' as "script":ORACLE@
       @SQLSERVER:'update cmn_sch_jobs set name = replace(name, '''''''', '' '') where id = ' + cast(j.id as varchar) + ';' as "script":SQLSERVER@
  from cmn_sch_jobs j
 inner join cmn_sch_job_definitions d on d.id = j.job_definition_id
 where j.status_code = 'SCHEDULED'
   and j.name like '%''%'

@ORACLE:):ORACLE@

@SQLSERVER:) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@