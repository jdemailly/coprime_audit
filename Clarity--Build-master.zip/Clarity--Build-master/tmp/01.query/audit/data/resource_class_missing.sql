/*
OBJECTIVE
  - Detect Resources active financially with no Resource Class or no Transaction Class
  - During an upgrade, these properties are mandatory
HISTORY
  - 2014-03-09 : CoPrime (DMA) - Init
  - 2014-03-21 : CoPrime (DMA) - SQL Server Compatibility
  - 2016-07-06 : CoPrime (DMA) - Is Active
BUSINESS RULES
  - If the Resource Class or Transaction Class fields are null for Resource financials, the upgrade process fails
  - The data must be corrected before you resume the upgrade process
TESTED ON
  - Clarity 12.x, 13.x
  - SQL Server 2008R2, Oracle 11.2.0.2
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '41' as "order",
         'Resources' as "name",
         'Detect Resources financially active and with no Transaction Class or Resource Class' as "description",
         'For each resource, change their financial properties and add Resource Class / Transaction Class' as "action",
         'ID' as "th1",
         'Code' as "th2",
         'Name' as "th3"),
       xmlagg(xmlelement(name "Record", xmlforest("id", "code", "name"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '41' as "@order",
       'Resources' as "@name",
       'Detect Resources financially active and with no Transaction Class or Resource Class' as "@description",
       'For each resource, change their financial properties and add Resource Class / Transaction Class' as "@action",
       'ID' as "@th1",
       'Code' as "@th2",
       'Name' as "@th3",
    (select t.* from (:SQLSERVER@
   
--Select
select r.id          as "id",
       r.unique_name as "code",
       r.full_name   as "name"
  from srm_resources r
 inner join pac_mnt_resources f on f.id = r.id
 where f.active = 1
   and (f.resource_class is null or f.transclass is null)

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@