/*
OBJECTIVE
  - Get Investments with the purged flag
  - Start job Delete Investment if needed
HISTORY
  - 2014-02-14 : CoPrime (DMA) - Init
  - 2015-06-29 : CoPrime (DMA) - Script to Deactivate Flag
BUSINESS RULES
  - inv_investments.purge_flag = 1 : Investments that are going to be purged
  - inv_investments.progress       : Lookup INVESTMENT_OBJ_PROGRESS
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2, 2012
  - Clarity 12.x, 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Investments' as "name",
         'Shows investments with the mark for deletion flag' as "description",
         'Run Job Delete Investments or deactivate the purge flag' as "action",
         'begin\n
\tupdate inv_investments i set i.purge_flag = 0 where i.purge_flag = 1;\n
\tcommit;\n
end;' as "script",
         'Code' as "th1",
         'Type' as "th2",
         'Name' as "th3",
         'Active' as "th4",
         'Progress' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "type", "name", "is_active", "progress"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '43' as "@order",
       'Investments' as "@name",
       'Shows investments with the mark for deletion flag' as "@description",
       'Run Job Delete Investments or deactivate the purge flag' as "@action",
       'update inv_investments set purge_flag = 0 where purge_flag = 1;' as "@script",
       'Code' as "@th1",
       'Type' as "@th2",
       'Name' as "@th3",
       'Active' as "@th4",
       'Progress' as "@th5",
       (select t.*
          from (:SQLSERVER@
         
select i.code as "code",
       i.odf_object_code as "type",
       i.name as "name",
       i.is_active as "is_active",
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUPS'
           and n.language_code = '@P_LANGUAGE@'
           and l.lookup_type = 'INVESTMENT_OBJ_PROGRESS'
           and l.lookup_enum = i.progress) as "progress"
  from inv_investments i
 where i.purge_flag = 1

@ORACLE:
order by i.code):ORACLE@

@SQLSERVER:) t order by t."code"
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@