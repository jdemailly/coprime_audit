/*
OBJECTIVE
  - Job : Scheduled, Prevent Cancelling
HISTORY
  - 2018-07-10 : CoPrime (DMA) - Init
  - 2018-10-08 : CoPrime (DMA) - Init
TESTED ON
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x, 15.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
       '46' as "order",
       'Jobs' as "name",
		   'Scheduled Jobs' as "description",
		   'Name' as "th1",
	     'Start Date' as "th2",
       'Visible' as "th3",
	     'Job Code' as "th4",
	     'Job Name' as "th5",
	     'Crontab' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "start_date", "is_visible", "job_code", "job_name", "crontab"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '46' as "@order",
       'Jobs' as "@name",
       'Scheduled Jobs' as "@description",
       'Name' as "@th1",
       'Start Date' as "@th2",
       'Visible' as "@th3",
       'Job Code' as "@th4",
       'Job Name' as "@th5",
       'Crontab' as "@th6",
       (select t.*
          from (:SQLSERVER@

--Main
select j.name as "name",
       j.start_date as "start_date",
       d.job_code as "job_code",
       n.name as "job_name",
       j.is_visible as "is_visible",
       @NVL@(j.minutes, '*') @+@ ' ' @+@ @NVL@(j.hours, '*') @+@ ' ' @+@ @NVL@(j.days_of_month, '*') @+@ ' ' @+@ @NVL@(j.months, '*') @+@ ' ' @+@ @NVL@(j.days_of_week, '*') as "crontab"
  from cmn_sch_jobs j
 inner join cmn_sch_job_definitions d on d.id = j.job_definition_id
 inner join cmn_captions_nls n on n.pk_id = d.id
                              and n.table_name = 'CMN_SCH_JOB_DEFINITIONS'
                              and n.language_code = 'en'
 where j.status_code = 'SCHEDULED'

@ORACLE:):ORACLE@

@SQLSERVER:) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@