/*
OBJECTIVE
  - Detect Financial Plans with same code within an investment
  - During an upgrade, the duplication of a plan code within a financial plan can cause the upgrade process to fail
HISTORY
  - 2014-03-09 : CoPrime (DMA) - Init
  - 2014-03-21 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - The plan code for each plan type within the investment must be unique (constraint 13.0)
TESTED ON
  - Clarity 12.1
  - SQL Server 2008R2, Oracle 11.2.0.2
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '44' as "order",
         'Investments' as "name",
         'Detect Financial Plan Codes with duplicated codes in investment' as "description",
         'Run the following script to change financial plans codes' as "action",
		 'begin\n
\tdbms_output.put_line(''Updating financial plan code duplicates...'');\n
\tupdate fin_plans\n
\t   set code = code || ''_'' || to_char(id)\n
\t where id in (select p1.id\n
\t                from fin_plans p1,\n
\t                     fin_plans p2\n
\t               where p1.id != p2.id\n
\t                 and p1.object_id = p2.object_id\n
\t                 and p1.code = p2.code\n
\t                 and p1.plan_type_code = p2.plan_type_code);\n
\tdbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
\tcommit;\n
end;' as "script",
         'ID' as "th1",
         'Code' as "th2",
         'Name' as "th3",
         'Type' as "th4",
         'Investment ID' as "th5",
         'Investment Code' as "th6",
         'Investment Name' as "th7"),
	     xmlagg(xmlelement(name "Record", xmlforest("id", "code", "name", "type", "investment_id", "investment_code", "investment_name"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '44' as "@order",
       'Investments' as "@name",
       'Detect Financial Plan Codes with duplicated codes in investment' as "@description",
       'Run the following script to change financial plans codes' as "@action",
		'go\n
print ''Updating financial plan code duplicates...'';\n
update fin_plans
   set code = code + ''_'' + id
 where id in (select p1.id
                from fin_plans p1,
                     fin_plans p2
               where p1.id != p2.id
                 and p1.object_id = p2.object_id
                 and p1.code = p2.code
                 and p1.plan_type_code = p2.plan_type_code);\n
print cast(@@ROWCOUNT as varchar) + '' update(s) done.'';\n
GO' as "@script",
         'ID' as "@th1",
         'Code' as "@th2",
         'Name' as "@th3",
         'Type' as "@th4",
         'Investment ID' as "@th5",
         'Investment Code' as "@th6",
         'Investment Name' as "@th7",
		(select t.* from (:SQLSERVER@

select p1.id             as "id",
       p1.code           as "code",
       p1.name           as "name",
       p1.plan_type_code as "type",
       i.id              as "investment_id",
       i.code            as "investment_code",
       i.name            as "investment_name"
  from fin_plans       p1,
       fin_plans       p2,
       inv_investments i
 where i.id = p1.object_id
   and p1.id != p2.id
   and p1.object_id = p2.object_id
   and p1.code = p2.code
   and p1.plan_type_code = p2.plan_type_code

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@