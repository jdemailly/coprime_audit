/*
OBJECTIVE
  - Object : Get Custom
HISTORY
  - 2016-10-18 : CoPrime (DMA) - Init
  - 2017-06-19 : CoPrime (DMA) - Fix SQL Server
BUSINESS RULES
  - odf_objects.is_custom = 1 : Custom Only
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '65' as "order",
         'Studio' as "name",
         'Custom Objects' as "description",
         'Analyze Each Object if Needed' as "action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Select\n
select o.code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''ODF_OBJECTS''\n
           and n.pk_id = o.id) as "name",\n
       o.last_updated_date as "last_updated_date",\n
       (select full_name from srm_resources where user_id = o.last_updated_by) as "last_updated_by"\n
  from odf_objects o\n
 where o.is_custom = 1\n
   and o.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where o.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by o.code' as "script",
         'Code' as "th1",
         'Name' as "th2",
         'Updated Date' as "th3",
         'Updated By' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "last_updated_date", "last_updated_by"))))
       .getclobval()
from (
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

--Select
select o.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'ODF_OBJECTS'
           and n.pk_id = o.id) as "name",
       o.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = o.last_updated_by) as "last_updated_by"
  from odf_objects o
 where o.is_custom = 1
   and o.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where o.last_updated_date between date_minus_1h and date_plus_1h)
 order by o.code)
:ORACLE@

@SQLSERVER:
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

select '65' as "@order",
       'Studio' as "@name",
       'Custom Objects' as "@description",
       'Analyze Each Object if Needed' as "@action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Select\n
select o.code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''ODF_OBJECTS''\n
           and n.pk_id = o.id) as "name",\n
       o.last_updated_date as "last_updated_date",\n
       (select full_name from srm_resources where user_id = o.last_updated_by) as "last_updated_by"\n
  from odf_objects o\n
 where o.is_custom = 1\n
   and o.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where o.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by o.code' as "@script",
       'Code' as "@th1",
       'Name' as "@th2",
       'Updated Date' as "@th3",
       'Updated By' as "@th4",
       (select t.*
          from (

--Select
select o.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'ODF_OBJECTS'
           and n.pk_id = o.id) as "name",
       o.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = o.last_updated_by) as "last_updated_by"
  from odf_objects o
 where o.is_custom = 1
   and o.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where o.last_updated_date between date_minus_1h and date_plus_1h)

) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@