/*
OBJECTIVE
  - Object : Get Custom Attributes
HISTORY
  - 2016-10-18 : CoPrime (DMA) - Init
  - 2017-06-19 : CoPrime (DMA) - SQL Server
BUSINESS RULES
  - odf_custom_attributes.is_custom = 1 : Custom Only
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '66' as "order",
         'Studio' as "name",
         'Custom Attributes' as "description",
         'Analyze Each Attribute if Needed' as "action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Select\n
select a.object_name as "object_code",\n
       a.internal_name as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''ODF_CUSTOM_ATTRIBUTES''\n
           and n.pk_id = a.id) as "name",\n
       a.last_updated_date as "last_updated_date",\n
       (select full_name from srm_resources where user_id = a.last_updated_by) as "last_updated_by"\n
  from odf_custom_attributes a\n
 where a.is_custom = 1\n
   and a.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where a.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by a.object_name,\n
          a.internal_name' as "script",
         'Object' as "th1",
         'Code' as "th2",
         'Name' as "th3",
         'Updated Date' as "th4",
         'Updated By' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("object_code", "acode", "aname", "last_updated_date", "last_updated_by"))))
       .getclobval()
from (

with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

--Select
select a.object_name as "object_code",
       a.internal_name as "acode",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.pk_id = a.id) as "aname",
       a.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = a.last_updated_by) as "last_updated_by"
  from odf_custom_attributes a
 where a.is_custom = 1
   and a.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where a.last_updated_date between date_minus_1h and date_plus_1h)

order by a.object_name,
         a.internal_name)
:ORACLE@

@SQLSERVER:
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

select '66' as "@order",
       'Studio' as "@name",
       'Custom Objects' as "@description",
       'Analyze Each Attribute if Needed' as "@action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Select\n
select a.object_name as "object_code",\n
       a.internal_name as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''ODF_CUSTOM_ATTRIBUTES''\n
           and n.pk_id = a.id) as "name",\n
       a.last_updated_date as "last_updated_date",\n
       (select full_name from srm_resources where user_id = a.last_updated_by) as "last_updated_by"\n
  from odf_custom_attributes a\n
 where a.is_custom = 1\n
   and a.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where a.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by a.object_name,\n
          a.internal_name' as "@script",
       'Object' as "@th1",
       'Code' as "@th2",
       'Name' as "@th3",
       'Updated Date' as "@th4",
       'Updated By' as "@th5",
       (select t.*
          from (

--Select
select a.object_name as "object_code",
       a.internal_name as "acode",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.pk_id = a.id) as "aname",
       a.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = a.last_updated_by) as "last_updated_by"
  from odf_custom_attributes a
 where a.is_custom = 1
   and a.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where a.last_updated_date between date_minus_1h and date_plus_1h)

) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@