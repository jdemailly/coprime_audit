/*
OBJECTIVE
  - Detect bad Display Mappings (no mappings)
HISTORY
  - 2015-10-19 : CoPrime (DMA) - Init
BUSINESS RULES
  - Prevent XOG error ORA-01400: cannot insert NULL into ("CLARITY"."ODF_MAPPINGS"."MAPPING_CODE")
TESTED ON
  - Oracle 11.2
  - Clarity 13.2
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '51' as "order",
         'Studio' as "name",
         'Detect Display Mapping with no Mappings' as "description",
         'Run Script' as "action",
         'begin\n
  delete from odf_display_mappings d\n
   where not exists (select 1 from odf_mappings m where m.display_mappings_id = d.id);\n
  commit;\n
end;' as "script",
         'Type' as "th1",
         'Object Code' as "th2",
         'Object Name' as "th3",
         'Attribute Code' as "th4",
         'Attribute Name' as "th5",
         'Logo' as "th6",
         'Flag' as "th7"),
       	xmlagg(xmlelement(name "Record", xmlforest("type", "object_code", "object_name", "attribute_code", "attribute_name", "logo", "flag"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '51' as "@order",
       'Studio' as "@name",
       'Detect Display Mapping with no Mappings' as "@description",
       'Run Script' as "@action",
       'begin\n
  delete from odf_display_mappings d\n
   where not exists (select 1 from odf_mappings m where m.display_mappings_id = d.id);\n
end;' as "@script",
       'Type' as "@th1",
       'Object Code' as "@th2",
       'Object Name' as "@th3",
       'Attribute Code' as "@th4",
       'Attribute Name' as "@th5",
       'Logo' as "@th6",
       'Flag' as "@th7",
		(select t.* from (:SQLSERVER@

--Main
select d.target_type as "type",
       d.object as "object_code",
       @NVL@((select n.name
          from cmn_captions_nls n,
               odf_objects      o
         where n.pk_id = o.id
           and n.table_name = 'ODF_OBJECTS'
           and n.language_code = '@P_LANGUAGE@'
           and o.code = d.object), ' ') as "object_name",
       d.attribute as "attribute_code",
       @NVL@((select n.name
          from cmn_captions_nls      n,
               odf_custom_attributes a
         where n.pk_id = a.id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = '@P_LANGUAGE@'
           and a.object_name = d.object
           and a.internal_name = d.attribute), ' ') as "attribute_name",
       d.type as "logo",
       'WARN' as "flag"
  from odf_display_mappings d
 where not exists (select 1 from odf_mappings m where m.display_mappings_id = d.id)

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@
