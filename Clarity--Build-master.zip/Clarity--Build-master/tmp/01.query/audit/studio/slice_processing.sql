/*
OBJECTIVE
  - Detect Processing Slice Requests
HISTORY
  - 2014-03-12 : CoPrime (DMA) - Init
  - 2014-03-24 : CoPrime (DMA) - SQL Server Compatibility
  - 2104-04-01 : CoPrime (DMA) - Conditions template and active
BUSINESS RULES
  - prj_blb_slicerequests.request_status > 0             : Status processing
  - prj_blb_slicerequests.request_completed_date is null : Slice requests probably in error or running
  - prj_blb_slicerequests.is_template = 0                : Ignore template Slice Requests
  - prj_blb_slicerequests.is_template = 1                : Ignore inactive slices requests
TESTED ON
  - Oracle 11.x, SQL Server 2008R2
  - Clarity 12.x, 13.x
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '43' as "order",
         'Time Slice' as "name",
         'Detects time slices being processed' as "description",
         'Run Time Slicing Job until no more time slice is done' as "action",
         'Name' as "th1",
         'Table' as "th2",
         'Status' as "th3",
         'Completed Date' as "th4",
         'Active' as "th5",
         'System' as "th6",
         'Flag' as "th7",
         'Script' as "th8"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "table", "status", "request_completed_date", "is_active", "is_system", "flag", "script"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '43' as "@order",
       'Time Slice' as "@name",
       'Detects time slices being processed' as "@description",
       'Run Time Slicing Job until no more time slice is done' as "@action",
       'Name' as "@th1",
       'Table' as "@th2",
       'Status' as "@th3",
       'Completed Date' as "@th4",
       'Active' as "@th5",
       'System' as "@th6",
       'Flag' as "@th7",
       'Script' as "@th8",
       (select t.*
          from (:SQLSERVER@

--Select
select r.request_name as "name",
       r.table_name as "table",
       @NVL@(@STRING:r.request_status:STRING@, ' ') as "status",
       @ORACLE:nvl(to_char(r.request_completed_date, 'YYYY-MM-DD'), ' ') as "request_completed_date",:ORACLE@
       @SQLSERVER:isnull(convert(varchar(10), r.request_completed_date, 121), ' ') as "request_completed_date",:SQLSERVER@
       r.is_active as "is_active",
       r.is_system as "is_system",
       'NOK' as "flag",
       'begin\n\tupdate prj_blb_slicerequests set request_status = null, request_completed_date = @NOW@ where id = ' @+@ @STRING:r.id:STRING@ @+@ ';\n@ORACLE:\tcommit;\n:ORACLE@end;' as "script"
  from prj_blb_slicerequests r
 where r.is_template = 0
   and r.is_active = 1
   and (@NVL@(r.request_status, 0) > 0 or r.request_completed_date is null)

@ORACLE: order by r.last_updated_date desc):ORACLE@
@SQLSERVER:) t
for xml path('Record'), type) for xml path('QueryResult')
:SQLSERVER@