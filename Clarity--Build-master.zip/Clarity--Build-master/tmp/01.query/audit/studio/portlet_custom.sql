/*
OBJECTIVE
  - Portlet : Get Custom
HISTORY
  - 2016-10-18 : CoPrime (DMA) - Init
  - 2017-06-19 : CoPrime (DMA) - Fix SQL Server
BUSINESS RULES
  - cmn_portlets.principal_type <> 'USER'      : Ignore User Portlet
  - cmn_portlets.portlet_type_code <> 'SYSTEM' : Ignore System
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '67' as "order",
         'Studio' as "name",
         'Custom Portlets' as "description",
         'Analyze Each Portlet if Needed' as "action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Portlet Custom\n
select p.portlet_code as code,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_PORTLETS''\n
           and n.pk_id = p.id) as name,\n
       (select n.name\n
          from cmn_captions_nls n\n
         inner join cmn_lookups l on l.id = n.pk_id\n
                                 and l.lookup_type = ''PORTLET_TYPE''\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       p.last_updated_date,\n
       (select full_name from srm_resources where user_id = p.last_updated_by) as last_updated_by\n
  from cmn_portlets p\n
 where p.principal_type <> ''USER''\n
   and p.portlet_type_code <> ''SYSTEM''\n
   and p.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where p.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by p.portlet_code' as "script",
         'Code' as "th1",
         'Name' as "th2",
         'Type' as "th3",
         'Updated Date' as "th4",
         'Updated By' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "type", "last_updated_date", "last_updated_by"))))
       .getclobval()
from (
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

--Portlet Custom
select p.portlet_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_PORTLETS'
           and n.pk_id = p.id) as "name",
       (select n.name
          from cmn_captions_nls n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = 'PORTLET_TYPE'
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_code = p.portlet_type_code) as "type",
       p.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by"
  from cmn_portlets p
 where p.principal_type <> 'USER'
   and p.portlet_type_code <> 'SYSTEM'
   and p.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where p.last_updated_date between date_minus_1h and date_plus_1h)
 order by p.portlet_code)
:ORACLE@

@SQLSERVER:
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

select '67' as "@order",
       'Studio' as "@name",
       'Custom Portlets' as "@description",
       'Analyze Each Portlet if Needed' as "@action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Portlet Custom\n
select p.portlet_code as code,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_PORTLETS''\n
           and n.pk_id = p.id) as name,\n
       (select n.name\n
          from cmn_captions_nls n\n
         inner join cmn_lookups l on l.id = n.pk_id\n
                                 and l.lookup_type = ''PORTLET_TYPE''\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.lookup_code = p.portlet_type_code) as type,\n
       p.last_updated_date,\n
       (select full_name from srm_resources where user_id = p.last_updated_by) as last_updated_by\n
  from cmn_portlets p\n
 where p.principal_type <> ''USER''\n
   and p.portlet_type_code <> ''SYSTEM''\n
   and p.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where p.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by p.portlet_code' as "@script",
       'Code' as "@th1",
       'Name' as "@th2",
       'Type' as "@th3",
       'Updated Date' as "@th4",
       'Updated By' as "@th5",
       (select t.*
          from (

--Portlet Custom
select p.portlet_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_PORTLETS'
           and n.pk_id = p.id) as "name",
       (select n.name
          from cmn_captions_nls n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = 'PORTLET_TYPE'
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_code = p.portlet_type_code) as "type",
       p.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by"
  from cmn_portlets p
 where p.principal_type <> 'USER'
   and p.portlet_type_code <> 'SYSTEM'
   and p.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where p.last_updated_date between date_minus_1h and date_plus_1h)

) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@