/*
OBJECTIVE
  - Time Slices : Search for Time Slices for 0 Period
HISTORY
  - 2016-11-16 : CoPrime (DMA) - Init
  - 2017-06-16 : CoPrime (DMA) - SQL Server
BUSINESS RULES
  - cmn_lookups.lookup_type = 'BLB_SLICE_ITEM'   : Slice Field
  - cmn_lookups.lookup_type = 'BLB_SLICE_PERIOD' : Slice Period
  - Prevent Time Slicing Error
    ERROR 2016-11-16 08:39:01,070 [Dispatch Time Slicing : bg (tenant=clarity)] niku.blobcrack (clarity:admin:10822045__7A385AF7-08E4-46B1-
    9607-5F68EB37DE43:Time Slicing) Exception during blobcrack process
    java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
TESTED ON
  - Oracle 11.x, SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '44' as "order",
         'Time Slice' as "name",
         'Detects Time Slices with 0 Period' as "description",
         'Set at Least 1 Period' as "action",
         'Slice' as "th01",
         'Field' as "th02",
         'Period' as "th03",
         'Rollover' as "th04",
         'From' as "th05",
         'To' as "th06",
         'Flag' as "th07"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "field", "period", "frequency", "from_date", "to_date", "flag"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '44' as "@order",
       'Time Slice' as "@name",
       'Detects Time Slices with 0 Period' as "@description",
       'Set at Least 1 Period' as "@action",
       'Slice' as "@th01",
       'Field' as "@th02",
       'Period' as "@th03",
       'Rollover' as "@th04",
       'From' as "@th05",
       'To' as "@th06",
       'Flag' as "@th07",    
       (select t.*
          from (
:SQLSERVER@
         
select r.request_name as "name",
       nf.name        as "field",
       np.name        as "period",
       nr.name        as "frequency",
       r.from_date    as "from_date",
       r.to_date      as "to_date",
       'NOK'          as "flag"
  from prj_blb_slicerequests r
--Field : Lookup BLB_SLICE_ITEM
 inner join cmn_lookups lf on lf.lookup_enum = r.field
                          and lf.lookup_type = 'BLB_SLICE_ITEM'
 inner join cmn_captions_nls nf on nf.pk_id = lf.id
                               and nf.language_code = 'en'
                               and nf.table_name = 'CMN_LOOKUPS'
--Period : Lookup BLB_SLICE_PERIOD
 inner join cmn_lookups lp on lp.lookup_enum = r.period
                          and lp.lookup_type = 'BLB_SLICE_PERIOD'
 inner join cmn_captions_nls np on np.pk_id = lp.id
                               and np.language_code = 'en'
                               and np.table_name = 'CMN_LOOKUPS'
--Frequency : Lookup BLB_SLICE_PERIOD
 inner join cmn_lookups lr on lr.lookup_enum = r.frequency
                          and lr.lookup_type = 'BLB_SLICE_PERIOD'
 inner join cmn_captions_nls nr on nr.pk_id = lr.id
                               and nr.language_code = 'en'
                               and nr.table_name = 'CMN_LOOKUPS'
 where r.num_periods = 0

@ORACLE:  order by r.request_name):ORACLE@

@SQLSERVER:
) t order by t.name
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@
