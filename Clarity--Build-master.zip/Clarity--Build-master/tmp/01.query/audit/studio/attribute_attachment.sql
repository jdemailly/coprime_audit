/*
OBJECTIVE
  - Detect Custom attributes with document attachment
HISTORY
  - 2014-03-01 : CoPrime (DMA) - Init
  - 2014-03-24 : CoPrime (DMA) - SQL Server Compatibility
  - 2014-04-24 : CoPrime (DMA) - Script Debug
  - 2016-07-30 : CoPrime (DMA) - Portfolio Object Removed in 13.2
BUSINESS RULES
  - odf_custom_attributes.data_type = 'attachment' : Custom Attribute of type attachment
TESTED ON
  - Oracle 11.x, SQL Server 2008R2
  - Clarity 12.x 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '63' as "order",
         'Studio' as "name",
         'Detects custom attributes of type attachment' as "description",
         'See if filestoring system is on server or in database\nIf upgrading on different server, need to copy files and rebuild their index' as "action",
         'admin search recreate-index-files\nadmin search recreate-index-data' as "script",
         'Object' as "th1",
         'Attribute' as "th2",
         'Name' as "th3",
         'Flag' as "th4",
         'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("object", "attribute", "name", "flag", "script"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '63' as "@order",
       'Studio' as "@name",
       'Detects custom attributes of type attachment' as "@description",
       'See if filestoring system is on server or in database\nIf upgrading on different server, need to copy files and rebuild their index' as "@action",
       'admin search recreate-index-files\nadmin search recreate-index-data' as "@script",
       'Object' as "@th1",
       'Attribute' as "@th2",
       'Name' as "@th3",
       'Flag' as "@th4",
       'Script' as "@th5",
       (select t.*
          from (:SQLSERVER@

--Main         
select a.object_name as "object",
       a.internal_name as "attribute",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = a.id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = '@P_LANGUAGE@') as "name",
       case
         when o.code = 'portfolio' or o.parent_object_code = 'portfolio' then
          'WARN'
         else
          ''
       end as "flag",
      'select f.name as "name",\n
       f.mime_type as "type",\n
       d.path_name as "path",\n
       substr(v.id, 2, 3) || ''/00'' || substr(v.id, 1, 1) || ''/'' || v.id as "folder"\n
  from odf_ca_' @+@ lower(a.object_name) @+@ '        t,\n
       clb_dms_files     f,\n
       clb_dms_versions  v,\n
       clb_dms_histories h,\n
       clb_dms_folders   d\n
 where t.' @+@ a.column_name @+@ ' = f.parent_folder_id\n
   and v.file_id = f.id\n
   and v.is_latest = 1\n
   and h.version_id = v.id\n
   and d.id = f.parent_folder_id' as "script"
  from odf_custom_attributes a
 inner join odf_objects o on o.code = a.object_name
 where a.data_type = 'attachment'

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@