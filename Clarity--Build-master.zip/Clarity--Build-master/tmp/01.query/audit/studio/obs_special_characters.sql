/*
OBJECTIVE
  - Detect OBS Units with special characters
  - During an upgrade, these characters are automatically replaced by '-'
HISTORY
  - 2014-03-09 : CoPrime (DMA) - Init
  - 2014-03-21 : CoPrime (DMA) - SQL Server Compatibility
  - 2015-06-29 : CoPrime (DMA) - OBS Path
  - 2015-07-28 : CoPrime (DMA) - Script Oracle to Update Names
BUSINESS RULES
  - The following special characters are replaced:
    / Slash (/)
    / Colon (:)
    / Double quote (")
    / Less than (<)
    / Greater than (>)
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x 
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '53' as "order",
         'Studio' as "name",
         'Detect OBS Name with special characters in it /:"<>' as "description",
         'Change OBS Name for each OBS found' as "action",
         'begin\n
  dbms_output.put_line(''Replacing quote by nyphen in departments table.'');\n
  update departments\n
     set shortdesc = translate(shortdesc, ''/:"<>'', ''-'')\n
   where (instr(shortdesc, ''/'') > 0 or instr(shortdesc, '':'') > 0 or instr(shortdesc, ''"'') > 0 or\n
         instr(shortdesc, ''<'') > 0 or instr(shortdesc, ''>'') > 0);\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  dbms_output.put_line(''Replacing quote by nyphen in locations table.'');\n
  update locations\n
     set shortdesc = translate(shortdesc, ''/:"<>'', ''-'')\n
   where (instr(shortdesc, ''/'') > 0 or instr(shortdesc, '':'') > 0 or instr(shortdesc, ''"'') > 0 or\n
         instr(shortdesc, ''<'') > 0 or instr(shortdesc, ''>'') > 0);\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  dbms_output.put_line(''Replacing quote by nyphen in prj_obs_units table.'');\n
  update prj_obs_units\n
     set name = translate(name, ''/:"<>'', ''-'')\n
   where (instr(name, ''/'') > 0 or instr(name, '':'') > 0 or instr(name, ''"'') > 0 or instr(name, ''<'') > 0 or\n
         instr(name, ''>'') > 0);\n
  dbms_output.put_line(sql%rowcount || '' update(s) done.'');\n
  commit;\n
end;' as "script",
         'Type ID' as "th1",
         'Type Code' as "th2",
         'Type Name' as "th3",
         'ID' as "th4",
         'Code' as "th5",
         'Name' as "th6",
         'Path' as "th7"),
	     xmlagg(xmlelement(name "Record", xmlforest("type_id", "type_code", "type_name", "id", "code", "name", "script"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '53' as "@order",
       'Studio' as "@name",
       'Detect OBS Name with special characters in it /:"<>' as "@description",
       'Change OBS Name for each OBS found' as "@action",
       'Type ID' as "@th1",
       'Type Code' as "@th2",
       'Type Name' as "@th3",
       'ID' as "@th4",
       'Code' as "@th5",
       'Name' as "@th6",
       'Path' as "@th7",
    (select t.* from (:SQLSERVER@

select t.id          as "type_id",
       t.unique_name as "type_code",
       t.name        as "type_name",
       u.id          as "id",
       u.unique_name as "code",
       u.name        as "name",
       (select @SUBSTR@(path, 4, @LENGTH@(path)) from nbi_dim_obs o where o.obs_unit_id = u.id) as "script"
  from prj_obs_units u,
       prj_obs_types t
 where t.id = u.type_id
   and (@INSTR@(u.name, '/') > 0 or @INSTR@(u.name, ':') > 0 or @INSTR@(u.name, '"') > 0 or
       @INSTR@(u.name, '<') > 0 or @INSTR@(u.name, '>') > 0)

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@
