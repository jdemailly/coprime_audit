/*
OBJECTIVE
  - Object : Get Required Custom Attributes
HISTORY
  - 2014-02-18 : CoPrime (DMA) - Init
  - 2014-04-09 : CoPrime (DMA) - Oracle Compatibility
  - 2015-06-29 : CoPrime (DMA) - Ignore Attribute cop_prj_statusrpt.cop_project_manager
  - 2015-11-07 : CoPrime (DMA) - Review Label to "Value Required"
  - 2016-08-01 : CoPrime (DMA) - Index CMN_CAPTIONS_NLS_N3
  - 2018-10-08 : CoPrime (DMA) - Extended Nvl
BUSINESS RULES
  - odf_custom_attributes.is_custom = 1   : Custom Attributes only
  - odf_custom_attributes.is_required = 1 : Attributes Required only
TESTED ON
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x, 15.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '61' as "order",
         'Studio' as "name",
         'Detects required attributes on objects' as "description",
         'Deactivate the property "Value Required" of each attribute on each object before upgrading' as "action",
         'Object' as "th1",
         'Attribute' as "th2",
         'Column' as "th3",
         'Type' as "th4",
         'Extended' as "th5",
         'Size' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "column", "type", "extended_type", "size"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '61' as "@order",
       'Studio' as "@name",
       'Detects required attributes on objects' as "@description",
       'Deactivate the property "Value Required" of each attribute on each object before upgrading' as "@action",
       'Object' as "@th1",
       'Attribute' as "@th2",
       'Column' as "@th3",
       'Type' as "@th4",
       'Extended' as "@th5",
       'Size' as "@th6",
       (select t.*
          from (:SQLSERVER@

--Main
select a.object_name as "code",
       a.column_name as "column",
       (select name
          from cmn_captions_nls n
         where n.pk_id = a.id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = '@P_LANGUAGE@') as "name",
       a.data_type as "type",
       @NVL@(a.extended_type, ' ') as "extended_type",
       a.data_size as "size"
  from odf_custom_attributes a
 where a.is_custom = 1
   and a.is_required = 1
   and not (a.object_name = 'cop_prj_statusrpt' and a.column_name = 'cop_project_manager')

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@