/*
OBJECTIVE
  - Detect Object which are being sliced
  - Wait for the time slicing to be over before upgrading
HISTORY
  - 2014-03-13 : CoPrime (DMA) - Init
  - 2014-03-20 : CoPrime (DMA) - Script Debug and SQL Server Compatibility
  - 2014-04-24 : CoPrime (DMA) - Join btw baseline_details and baselines
  - 2015-07-01 : CoPrime (DMA) - Warning Message Instead of Error
BUSINESS RULES
  - Attribute slice_status > 0                  : Slice status processing
  - inv_investments.slice_status != 0           : Time Slices Processing or Out-of-date on INV_INVESTMENTS need to be processed
  - prteam.slice_status != 0                    : Time Slices Processing or Out-of-date on PRTEAM need to be processed
  - prassignment.slice_status != 0              : Time Slices Processing or Out-of-date on PRASSIGNMENT need to be processed
  - cap_scenario_assignments.slice_status != 0  : Time Slices Processing or Out-of-date on CAP_SCENARIO_ASSIGNMENTS need to be processed
  - cap_scenario_tasks.slice_status != 0        : Time Slices Processing or Out-of-date on CAP_SCENARIO_TASKS need to be processed
  - cap_scenario_team.slice_status != 0         : Time Slices Processing or Out-of-date on CAP_SCENARIO_TEAM need to be processed
  - prj_baselines.slice_status != 0             : Time Slices Processing or Out-of-date on PRJ_BASELINES need to be processed
  - prj_baseline_details.slice_status != 0      : Time Slices Processing or Out-of-date on PRJ_BASELINE_DETAILS need to be processed (be aware, you can have slice_status > 0 on baseline_detail when slice_status is null on baseline)
  - prj_tentative_assignments.slice_status != 0 : Time Slices Processing or Out-of-date on PRJ_TENTATIVE_ASSIGNMENTS need to be processed
  - prtimeentry.slice_status != 0               : Time Slices Processing or Out-of-date on PRTIMEENTRY need to be processed
  - rsm_req_requisitions.slice_status != 0      : Time Slices Processing or Out-of-date on RSM_REQ_REQUISITIONS need to be processed
  - srm_resources.slice_status != 0             : Time Slices Processing or Out-of-date on SRM_RESOURCES need to be processed
  - prj_resources.slice_status != 0             : Time Slices Processing or Out-of-date on PRJ_RESOURCES need to be processed
  - prcalendar.slice_status != 0                : Time Slices Processing or Out-of-date on PRCALENDAR need to be processed
STAND BY
--Time Slices Processing or Out-of-date on PFM_BASELINE_DETAILS need to be processed
union all
select 'Time Slices Processing or Out-of-date on PFM_BASELINE_DETAILS need to be processed',
       case when count(*) = 0 then 'OK' else 'NOK' end
  from pfm_baseline_details i
 where @NVL@(i.slice_status, 0) != 0
--Time Slices Processing or Out-of-date on PFM_INVESTMENTS need to be processed
union all
select 'Time Slices Processing or Out-of-date on PFM_INVESTMENTS need to be processed',
       case when count(*) = 0 then 'OK' else 'NOK' end
  from pfm_investments i
 where @NVL@(i.slice_status, 0) != 0
--Time Slices Processing or Out-of-date on PFM_INVESTMENTS_PLAN need to be processed
union all
select 'Time Slices Processing or Out-of-date on PFM_INVESTMENTS_PLAN need to be processed',
       case when count(*) = 0 then 'OK' else 'NOK' end
  from pfm_investments_plan i
 where @NVL@(i.slice_status, 0) != 0
TESTED ON
  - Oracle 11.x, SQL Server 2008R2
  - Clarity 12.x 13.x
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '42' as "order",
         'Time Slice' as "name",
         'Detect Objects that are being sliced' as "description",
         'Wait for Time Slicing Job to end or apply given script to reset slices' as "action",
         'Object' as "th1",
         'Count' as "th2",
         'Flag' as "th3",
         'Script' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest("object", "count", "flag", "script"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '42' as "@order",
       'Time Slice' as "@name",
       'Detect Objects that are being sliced' as "@description",
       'Wait for Time Slicing Job to end or apply given script to reset slices' as "@action",
       'Object' as "@th1",
       'Count' as "@th2",
       'Flag' as "@th3",
       'Script' as "@th4",
       (:SQLSERVER@
         
select "object",
       "count",
       'WARN' as "flag",
       "script"
  from (
 
      --Project
      select 'INV_INVESTMENTS' as "object",
               count(*) as "count",
               'begin\n\tupdate inv_investments set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;' as "script"
          from inv_investments
         where @NVL@(slice_status, 0) > 0
        union all
        select 'PRTEAM',
               count(*),
               'begin\n\tupdate prteam set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'            
          from prteam
         where @NVL@(slice_status, 0) > 0
        union all
        select 'PRASSIGNMENT',
               count(*),
               'begin\n\tupdate prassignment set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'  
          from prassignment
         where @NVL@(slice_status, 0) > 0
        union all
        select 'CAP_SCENARIO_ASSIGNMENTS',
               count(*),
               'begin\n\tupdate cap_scenario_assignments set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from cap_scenario_assignments
         where @NVL@(slice_status, 0) > 0
        union all
        select 'CAP_SCENARIO_TASKS',
               count(*),
               'begin\n\tupdate cap_scenario_tasks set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from cap_scenario_tasks
         where @NVL@(slice_status, 0) > 0
        union all
        select 'CAP_SCENARIO_TEAM',
               count(*),
               'begin\n\tupdate cap_scenario_team set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from cap_scenario_team
         where @NVL@(slice_status, 0) > 0
        union all
        select 'PRJ_BASELINES',
               count(*),
               'begin\n\tupdate prj_baselines set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from prj_baselines
         where @NVL@(slice_status, 0) > 0
        union all
        select 'PRJ_BASELINE_DETAILS',
               count(*),
               'begin\n\tupdate prj_baseline_details set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from prj_baseline_details d,
               prj_baselines        b
         where d.baseline_id = b.id
           and @NVL@(d.slice_status, 0) > 0
           and @NVL@(b.slice_status, 0) > 0
        union all
        select 'PRJ_TENTATIVE_ASSIGNMENTS',
               count(*),
               'begin\n\tupdate prj_tentative_assignments set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from prj_tentative_assignments
         where @NVL@(slice_status, 0) > 0
        --Resources
        union all
        select 'PRTIMEENTRY',
               count(*),
               'begin\n\tupdate prtimeentry set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from prtimeentry
         where @NVL@(slice_status, 0) > 0
        union all
        select 'RSM_REQ_REQUISITIONS',
               count(*),
               'begin\n\tupdate rsm_req_requisitions set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from rsm_req_requisitions
         where @NVL@(slice_status, 0) > 0
        union all
        select 'SRM_RESOURCES',
               count(*),
               'begin\n\tupdate srm_resources set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from srm_resources
         where @NVL@(slice_status, 0) > 0
        union all
        select 'PRJ_RESOURCES',
               count(*),
               'begin\n\tupdate prj_resources set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from prj_resources
         where @NVL@(slice_status, 0) > 0
        union all
        select 'PRCALENDAR',
               count(*),
               'begin\n\tupdate prcalendar set slice_status = null where @NVL@(slice_status, 0) > 0;\n@ORACLE:\tcommit;\n:ORACLE@end;'
          from prcalendar
         where @NVL@(slice_status, 0) > 0) t
 where "count" > 0

@ORACLE:order by "count" desc):ORACLE@
@SQLSERVER:for xml path('Record'), type) for xml path('QueryResult'):SQLSERVER@