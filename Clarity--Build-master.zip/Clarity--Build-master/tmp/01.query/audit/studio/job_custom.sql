/*
OBJECTIVE
  - Job : Get Custom
HISTORY
  - 2016-10-18 : CoPrime (DMA) - Init
  - 2017-06-19 : CoPrime (DMA) - Fix SQL Server
BUSINESS RULES
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '68' as "order",
         'Studio' as "name",
         'Custom Jobs' as "description",
         'Analyze Each Job if Needed' as "action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Job Custom\n
select d.job_code as code,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_SCH_JOB_DEFINITIONS''\n
           and n.pk_id = d.id) as name,\n
       (select n.name\n
          from cmn_captions_nls n\n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = ''SCH_JOB_TYPE''\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.id = d.job_type) as type,\n
       d.last_updated_date,\n
       (select full_name from srm_resources where user_id = d.last_updated_by) as last_updated_by\n
  from cmn_sch_job_definitions d\n
 where d.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where d.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by d.job_code' as "script",
         'Code' as "th1",
         'Name' as "th2",
         'Type' as "th3",
         'Updated Date' as "th4",
         'Updated By' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "type", "last_updated_date", "last_updated_by"))))
       .getclobval()
from (
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

--Portlet Custom
select d.job_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_SCH_JOB_DEFINITIONS'
           and n.pk_id = d.id) as "name",
       (select n.name
          from cmn_captions_nls n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = 'SCH_JOB_TYPE'
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.id = d.job_type) as "type",
       d.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = d.last_updated_by) as "last_updated_by"
  from cmn_sch_job_definitions d
 where d.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where d.last_updated_date between date_minus_1h and date_plus_1h)
 order by d.job_code)
:ORACLE@

@SQLSERVER:
with

--Installation Range
install as
 (select (h.installed_date - 1 / 24) as date_minus_1h,
         (h.installed_date + 1 / 24) as date_plus_1h
    from cmn_install_history h)

select '68' as "@order",
       'Studio' as "@name",
       'Custom Jobs' as "@description",
       'Analyze Each Job if Needed' as "@action",
         'with\n
--Installation Range\n
install as\n
 (select (h.installed_date - 1 / 24) as date_minus_1h,\n
         (h.installed_date + 1 / 24) as date_plus_1h\n
    from cmn_install_history h)\n
--Job Custom\n
select d.job_code as code,\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_SCH_JOB_DEFINITIONS''\n
           and n.pk_id = d.id) as name,\n
       (select n.name\n
          from cmn_captions_nls n\n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = ''SCH_JOB_TYPE''\n
         where n.language_code = ''@P_LANGUAGE@''\n
           and n.table_name = ''CMN_LOOKUPS''\n
           and l.id = d.job_type) as type,\n
       d.last_updated_date,\n
       (select full_name from srm_resources where user_id = d.last_updated_by) as last_updated_by\n
  from cmn_sch_job_definitions d\n
 where d.last_updated_date >= (select min(h.installed_date) from cmn_install_history h where h.install_id in (''release_version'', ''database''))\n
   and not exists (select 1 from install where d.last_updated_date between date_minus_1h and date_plus_1h)\n
 order by d.job_code' as "@script",
       'Code' as "@th1",
       'Name' as "@th2",
       'Type' as "@th3",
       'Updated Date' as "@th4",
       'Updated By' as "@th5",
       (select t.*
          from (

--Portlet Custom
select d.job_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_SCH_JOB_DEFINITIONS'
           and n.pk_id = d.id) as "name",
       (select n.name
          from cmn_captions_nls n
         inner join cmn_lookups l on l.id = n.pk_id
                                 and l.lookup_type = 'SCH_JOB_TYPE'
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.id = d.job_type) as "type",
       d.last_updated_date as "last_updated_date",
       (select full_name from srm_resources where user_id = d.last_updated_by) as "last_updated_by"
  from cmn_sch_job_definitions d
 where d.last_updated_date >=
       (select min(h.installed_date) from cmn_install_history h where h.install_id in ('release_version', 'database'))
   and not exists (select 1 from install where d.last_updated_date between date_minus_1h and date_plus_1h)
  
) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@