/*
OBJECTIVE
  - Detect HTML portlets with :
    / app?action= to be replaced by nu#action=
    / document.write to be replaced by property .innerHTML
HISTORY
  - 2014-02-01 : CoPrime (DMA) - Init
  - 2014-03-14 : CoPrime (DMA) - document.write Check
  - 2014-03-21 : CoPrime (DMA) - SQL Server Compatibility
  - 2014-04-18 : CoPrime (DMA) - jre.installation
  - 2014-06-03 : CoPrime (DMA) - xog.client (Removed in 13.3)
BUSINESS RULES
  - cmn_html_retrieve_services.portlet_id = cmn_portlets.id : Link between HTML Code and Portlet
  - cmn_portlets.portlet_type_code = 'HTML'                 : HTML Portlets only
  - SQL Server : Use of function collate sql_latin1_general_cp1_ci_as
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2, 2012
  - Clarity 12, 13
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '51' as "order",
         'Studio' as "name",
         'Detect HTML portlets which need an update' as "description",
         'Make following changes in Administration > Studio > Portlets :\n\t- Replace document.write by innerHTML\n\t- Replace app?action by nu#action\n\t- Remove link action:jre.installation' as "action",			
         'Code' as "th1",
         'Name' as "th2",
         'Script' as "th3"),
       	xmlagg(xmlelement(name "Record", xmlforest("code", "name", "script"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '51' as "@order",
       'Studio' as "@name",
       'Detect HTML portlets which need an update' as "@description",
       'Make following changes in Administration > Studio > Portlets :\n\t- Replace document.write by innerHTML\n\t- Replace app?action by nu#action\n\t- Remove link action:jre.installation' as "@action",			
       'Code' as "@th1",
       'Name' as "@th2",
       'Script' as "@th3",
		(select t.* from (:SQLSERVER@

--Main
select p.portlet_code as "code",
       (select name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'CMN_PORTLETS'
           and n.language_code = '@P_LANGUAGE@') as "name",
       'select p.portlet_code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = ''CMN_PORTLETS''\n
           and n.language_code = ''@P_LANGUAGE@'') as "name",\n
       h.html_text as "text"\n
  from cmn_html_retrieve_services h,\n
       cmn_portlets               p\n
 where h.portlet_id = p.id\n
   and h.id = ' @+@ @STRING:h.id:STRING@ @+@ ';' as "script"
  from cmn_html_retrieve_services h,
       cmn_portlets               p
 where h.portlet_id = p.id
   and p.portlet_type_code = 'HTML'
   @ORACLE:
   and (lower(h.html_text) like '%app?action=%'
   	 or lower(h.html_text) like '%document.write%'
   	 or lower(h.html_text) like '%personal.jreinstallation%'
   	 or lower(h.html_text) like '%xog.client%'):ORACLE@
   @SQLSERVER:
   and (h.html_text like '%app\?action=%' collate sql_latin1_general_cp1_ci_as escape '\'
   	 or h.html_text like '%document.write%' collate sql_latin1_general_cp1_ci_as
   	 or h.html_text like '%personal.jreinstallation%' collate sql_latin1_general_cp1_ci_as
   	 or h.html_text like '%xog.client%' collate sql_latin1_general_cp1_ci_as):SQLSERVER@

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@