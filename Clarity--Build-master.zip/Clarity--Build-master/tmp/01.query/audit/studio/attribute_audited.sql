/*
OBJECTIVE
  - Select Audited Attributes
HISTORY
  - 2014-02-18 : CoPrime (DMA) - Init
  - 2014-04-09 : CoPrime (DMA) - Oracle compatibility
BUSINESS RULES
  - odf_audited_attributes.is_active = 1 : Active only
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 12.x, 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '62' as "order",
         'Studio' as "name",
         'Detects audited attributes on objects' as "description",
         'Deactivate audit trails on each object before upgrading' as "action",
         'Object' as "th1",
         'Code' as "th2",
         'Operation' as "th3",
         'Name' as "th4"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "operation", "value"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '62' as "@order",
       'Studio' as "@name",
       'Detects audited attributes on objects' as "@description",
       'Deactivate audit trails on each object before upgrading' as "@action",
       'Object' as "@th1",
       'Code' as "@th2",
       'Operation' as "@th3",
       'Name' as "@th4",
       (select t.*
          from (:SQLSERVER@
         
select a.object_code as "code",
       a.attribute_code as "name",
       a.operation_code as "operation",
       (select n.name
          from cmn_captions_nls      n,
               odf_custom_attributes ca
         where ca.id = n.pk_id
           and n.table_name = 'ODF_CUSTOM_ATTRIBUTES'
           and n.language_code = '@P_LANGUAGE@'
           and ca.object_name = a.object_code
           and ca.internal_name = a.attribute_code) as "value"
  from odf_audited_attributes a
 where a.is_active = 1

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@