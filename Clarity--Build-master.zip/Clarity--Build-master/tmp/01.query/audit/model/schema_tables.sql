/*
OBJECTIVE
  - Table : All DBMS Tables
HISTORY
  - 2016-06-03 : CoPrime (DMA) - Init
  - 2019-07-05 : CoPrime (DMA) - SQL Server User Table
BUSINESS RULES
  - This result is compared with schema.xml (folder cfg/schema)
  - Oracle user_objects : Objects for current schema
  - SQL Server sys.all_objects : All Objects
  - sys.all_objects.schema_id = schema_id() : Current Schema is given by standard function schema_id()
  - Ignore Oracle Objects (CA compliant) :
    / Tables ODF_CA_%, ODF_SSL_%, ODF_SL_%
TESTED ON
  - Clarity 12.x, 13.x, 14.x
  - Oracle 11.2, 12.1
  - SQL Server 2008R2, 2012 
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
        '92' as "order",
        'Oracle Custom Objects' as "name",
        'Detect Custom Tables on current schema' as "description",
        'Convert each table into an object Clarity' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Created' as "th3",
        'Flag' as "th4"),
         xmlagg(xmlelement("Record", xmlforest("name", "type", "created", "flag")))).getclobval()
from (

--Tables
select o.object_name as "name",
       o.object_type as "type",
       to_char(o.created, 'yyyy-mm-dd') as "created",
       'WARN' as "flag"
  from user_objects o
 where o.object_type = 'TABLE'
   and not (o.object_name like 'ODF_CA_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%')
 order by o.object_name

)
:ORACLE@

@SQLSERVER:
select '92' as "@order",
       'SQL Server Custom Objects' as "@name",
       'Detect Custom Tables on current schema' as "@description",
       'Convert each table into an object Clarity' as "@action",
       'Name' as "@th1",
       'Type' as "@th2",
       'Created' as "@th3",
       'Flag' as "@th4",
    (select t.* from (

--Tables
select o.name as "name",
       'TABLE' as "type",
       convert(varchar(10), o.create_date, 126) as "created",
       'WARN' as "flag"
  from sys.all_objects o
 where o.schema_id = schema_id()
   and o.type_desc in ('INTERNAL_TABLE', 'USER_TABLE')
   and not (o.name like 'ODF_CA_%' or o.name like 'ODF_SSL_%' or o.name like 'ODF_SL_%' or o.name like 'CMN_SEQ_%')

) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@