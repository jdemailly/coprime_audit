/*
OBJECTIVE
  - Detect Process Custom Scripts with potential impact on migration
  - See Data Model Analysis Document
HISTORY
  - 2014-03-11 : CoPrime (DMA) - Init
  - 2014-03-20 : CoPrime (DMA) - Script Debug and SQL Server Compatibility
  - 2015-07-10 : CoPrime (DMA) - odf_aud_value_fct
BUSINESS RULES
  - Analyze GEL content in cmn_custom_scripts.script_text
  - bpm_def_processes              : Process Table
  - cmn_custom_scripts.script_text : GEL Script Body
  - 13.0 Cost Plan Enhancement on XOG, remove XOG content <PlanData> :
    / v12   : <PlanData cost="700.0" end_date="2011-01-31" revenue="750.0" start_date="2011-01-16" units="7.0"/>
    / v13.0 : <Cost><segment finish="2008-01-31T00:00:00" start="2008-01-01T00:00:00" value="100.0"/></Cost>
  - SQL Server collate sql_latin1_general_cp1_ci_as
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 12, 13
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '91' as "order",
         'GEL' as "name",
         'Detect Potential Impact on Processes' as "description",
         'Analyze each process and see if there is an impact during migration' as "action",
         'Code' as "th1",
         'Name' as "th2",
         'Description' as "th3",
		 'Updated By' as "th4",
		 'Updated' as "th5",
		 'Script' as "th6"),
       xmlagg(xmlelement(name "Record", xmlforest("code", "name", "description", "last_user", "last_updated_date", "script"))))
       .getclobval()
from (

select p.process_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'BPM_DEF_PROCESSES'
           and n.language_code = '@P_LANGUAGE@') as "name",
       @NVL@((select n.description
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'BPM_DEF_PROCESSES'
           and n.language_code = '@P_LANGUAGE@'), ' ') as "description",
       (select r.full_name from srm_resources r where r.user_id = s.last_updated_by) as "last_user",
       s.last_updated_date as "last_updated_date",
       'select p.process_code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = ''BPM_DEF_PROCESSES''\n
           and n.language_code = ''@P_LANGUAGE@'') as "name",\n
       st.step_code as "step",\n
       a.action_code as "action",\n
       s.script_text as "script"\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = ' || s.id || ';' as "script"
  from bpm_def_processes        p,
       bpm_def_process_versions v,
       bpm_def_stages           stage,
       bpm_def_steps            step,
       bpm_def_step_actions     pa,
       cmn_custom_scripts       s
 where stage.process_version_id = v.id
   and step.stage_id = stage.id
   and pa.step_id = step.id
   and s.id = pa.script_id
   and v.process_id = p.id
   and (lower(s.script_text) like '%odf_aud_value_fct%' or
       lower(s.script_text) like '%<plandata%' or lower(s.script_text) like '%cal_events_get_nhresource_availability%' or
       lower(s.script_text) like '%pma_calc_present_value%' or lower(s.script_text) like '%pma_calc_pv_cost_for_inv%' or
       lower(s.script_text) like '%pma_trunc_month_fct%' or lower(s.script_text) like '%cmn_sql_trace%' or
       lower(s.script_text) like '%cal_event_nhresources%' or lower(s.script_text) like '%cal_nhresource_types%' or
       lower(s.script_text) like '%cal_nhresources%' or lower(s.script_text) like '%cmn_seq_pma_aggr_keys%' or
       lower(s.script_text) like '%cmn_seq_pma_aggr_values%' or
       lower(s.script_text) like '%cmn_seq_pma_aggr_values_validity%' or
       lower(s.script_text) like '%cmn_seq_pma_financial_values%' or
       lower(s.script_text) like '%cmn_seq_pma_pinned_investments%' or
       lower(s.script_text) like '%cmn_seq_pma_portfolio_contents%' or
       lower(s.script_text) like '%cmn_seq_pma_portfolio_roles%' or
       lower(s.script_text) like '%cmn_seq_pma_portfolios%' or
       lower(s.script_text) like '%cmn_seq_pma_priority_chart_conf%' or
       lower(s.script_text) like '%cmn_seq_pma_prtflio_incl_ctnt_types%' or
       lower(s.script_text) like '%odf_ca_contract%' or lower(s.script_text) like '%odf_ca_portfolio%' or
       lower(s.script_text) like '%pma_aggr_keys%' or lower(s.script_text) like '%pma_aggr_values%' or
       lower(s.script_text) like '%pma_aggr_values_validity%' or lower(s.script_text) like '%pma_ef_candidates%' or
       lower(s.script_text) like '%pma_ef_investments%' or lower(s.script_text) like '%pma_financial_values%' or
       lower(s.script_text) like '%pma_pinned_investments%' or lower(s.script_text) like '%pma_portfolio_contents%' or
       lower(s.script_text) like '%pma_portfolio_roles%' or lower(s.script_text) like '%pma_portfolios%' or
       lower(s.script_text) like '%pma_priority_chart_conf%' or
       lower(s.script_text) like '%pma_prtflio_incl_ctnt_types%' or lower(s.script_text) like '%odf_contract_v%' or
       lower(s.script_text) like '%odf_contract_v2%' or lower(s.script_text) like '%odf_portfolio_v%' or
       lower(s.script_text) like '%odf_portfolio_v2%' or lower(s.script_text) like '%odfsec_contract_v%' or
       lower(s.script_text) like '%odfsec_contract_v2%' or lower(s.script_text) like '%odfsec_portfolio_v%' or
       lower(s.script_text) like '%odfsec_portfolio_v2%' or
       (lower(s.script_text) like '%cap_scenarios%' and lower(s.script_text) like '%portfolio_id%') or
       (lower(s.script_text) like '%cmn_sec_right_v%' and
       (lower(s.script_text) like '%aop_id%' or lower(s.script_text) like '%id%')) or
       (lower(s.script_text) like '%cmn_sec_users%' and lower(s.script_text) like '%sqltrace_active%') or
       (lower(s.script_text) like '%cmn_ui_themes%' and lower(s.script_text) like '%folder%') or
       (lower(s.script_text) like '%cmn_user_session_v%' and lower(s.script_text) like '%sqltrace_active%') or
       (lower(s.script_text) like '%fin_cost_plan_details%' and
       (lower(s.script_text) like '%plan_detail_1_key%' or lower(s.script_text) like '%plan_detail_2_key%' or
       lower(s.script_text) like '%prchargecode_id%' or lower(s.script_text) like '%prrole_id%' or
       lower(s.script_text) like '%transclass_id%')) or
       (lower(s.script_text) like '%inv_projects%' and
       (lower(s.script_text) like '%prbasefinish%' or lower(s.script_text) like '%prbasestart%' or
       lower(s.script_text) like '%prbasetime%')) or
       (lower(s.script_text) like '%odf_application_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_application_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_asset_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_asset_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_assignment_v%' and
       (lower(s.script_text) like '%prbasefinish%' or lower(s.script_text) like '%prbasemax%' or
       lower(s.script_text) like '%prbasepattern%' or lower(s.script_text) like '%prbasepattern_caption%' or
       lower(s.script_text) like '%prbasestart%' or lower(s.script_text) like '%prbasesum%')) or
       (lower(s.script_text) like '%odf_assignment_v2%' and
       (lower(s.script_text) like '%prbasefinish%' or lower(s.script_text) like '%prbasemax%' or
       lower(s.script_text) like '%prbasepattern%' or lower(s.script_text) like '%prbasestart%' or
       lower(s.script_text) like '%prbasesum%')) or
       (lower(s.script_text) like '%odf_costplan_v%' and
       (lower(s.script_text) like '%plan_by_1_code_caption%' or lower(s.script_text) like '%plan_by_2_code_caption%')) or
       (lower(s.script_text) like '%odf_costplandetail_v%' and
       (lower(s.script_text) like '%cost_pctplan%' or lower(s.script_text) like '%object_id%' or
       lower(s.script_text) like '%plan_by_1_code%' or lower(s.script_text) like '%plan_by_1_code_caption%' or
       lower(s.script_text) like '%plan_by_2_code%' or lower(s.script_text) like '%plan_by_2_code_caption%' or
       lower(s.script_text) like '%plan_code%' or lower(s.script_text) like '%plan_detail_1%' or
       lower(s.script_text) like '%plan_detail_2%' or lower(s.script_text) like '%plan_name%' or
       lower(s.script_text) like '%prchargecode_id%' or lower(s.script_text) like '%prrole_id%' or
       lower(s.script_text) like '%transclass_id%')) or
       (lower(s.script_text) like '%odf_costplandetail_v2%' and
       (lower(s.script_text) like '%cost_pctplan%' or lower(s.script_text) like '%object_id%' or
       lower(s.script_text) like '%plan_by_1_code%' or lower(s.script_text) like '%plan_by_2_code%' or
       lower(s.script_text) like '%plan_code%' or lower(s.script_text) like '%plan_detail_1%' or
       lower(s.script_text) like '%plan_detail_2%' or lower(s.script_text) like '%plan_name%' or
       lower(s.script_text) like '%prchargecode_id%' or lower(s.script_text) like '%prrole_id%' or
       lower(s.script_text) like '%transclass_id%')) or
       (lower(s.script_text) like '%odf_department_v%' and lower(s.script_text) like '%last_updated_by%') or
       (lower(s.script_text) like '%odf_department_v2%' and lower(s.script_text) like '%last_updated_by%') or
       (lower(s.script_text) like '%odf_idea_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_idea_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_inv_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_inv_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_investmenthierarchy_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_investmenthierarchy_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_other_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_other_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_product_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_product_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_project_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%' or lower(s.script_text) like '%prbasefinish%' or
       lower(s.script_text) like '%prbasestart%' or lower(s.script_text) like '%prbasetime%' or
       lower(s.script_text) like '%schedule_variance%' or lower(s.script_text) like '%schedule_variance_color%' or
       lower(s.script_text) like '%schedule_variance_color_nls%' or
       lower(s.script_text) like '%schedule_variance_map%' or
       lower(s.script_text) like '%schedule_variance_map_nls%')) or
       (lower(s.script_text) like '%odf_project_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%' or lower(s.script_text) like '%prbasefinish%' or
       lower(s.script_text) like '%prbasestart%' or lower(s.script_text) like '%prbasetime%' or
       lower(s.script_text) like '%schedule_variance%')) or
       (lower(s.script_text) like '%odf_service_v%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_service_v2%' and
       (lower(s.script_text) like '%inv_planned_npv%' or lower(s.script_text) like '%inv_planned_roi%' or
       lower(s.script_text) like '%planned_pv_cost%')) or
       (lower(s.script_text) like '%odf_task_v%' and
       (lower(s.script_text) like '%prbaseduration%' or lower(s.script_text) like '%prbasefinish%' or
       lower(s.script_text) like '%prbaseisfixed%' or lower(s.script_text) like '%prbaseisfixed_image%' or
       lower(s.script_text) like '%prbaseisfixed_image_nls%' or lower(s.script_text) like '%prbaseisfixed_map%' or
       lower(s.script_text) like '%prbaseisfixed_map_nls%' or lower(s.script_text) like '%prbasestart%' or
       lower(s.script_text) like '%prbasetime%')) or
       (lower(s.script_text) like '%odf_task_v2%' and
       (lower(s.script_text) like '%prbaseduration%' or lower(s.script_text) like '%prbasefinish%' or
       lower(s.script_text) like '%prbaseisfixed%' or lower(s.script_text) like '%prbasestart%' or
       lower(s.script_text) like '%prbasetime%')) or
       (lower(s.script_text) like '%prassignment%' and
       (lower(s.script_text) like '%prbasemax%' or lower(s.script_text) like '%prbasepattern%' or
       lower(s.script_text) like '%prbasesum%')) or
       (lower(s.script_text) like '%prj_blb_slices%' and
       (lower(s.script_text) like '%created_by%' or lower(s.script_text) like '%id%' or
       lower(s.script_text) like '%last_updated_by%' or lower(s.script_text) like '%last_updated_date%' or
       lower(s.script_text) like '%unit%')) or
       (lower(s.script_text) like '%prnote%' and
       (lower(s.script_text) like '%prcreatedby%' or lower(s.script_text) like '%prmodby%')) or
       (lower(s.script_text) like '%prtask%' and
       (lower(s.script_text) like '%prbaseduration%' or lower(s.script_text) like '%prbasefinish%' or
       lower(s.script_text) like '%prbaseisfixed%' or lower(s.script_text) like '%prbasestart%' or
       lower(s.script_text) like '%prbasetime%')))
	  
):ORACLE@

@SQLSERVER:
select '91' as "@order",
       'GEL' as "@name",
       'Detect Potential Impact on Processes with GEL script' as "@description",
       'Analyze each process and see if there is an impact during migration' as "@action",
       'Code' as "@th1",
       'Name' as "@th2",
       'Description' as "@th3",
       'Updated By' as "@th4",
       'Updated' as "@th5",
       'Script' as "@th6",
		(select t.* from (
select p.process_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'BPM_DEF_PROCESSES'
           and n.language_code = '@P_LANGUAGE@') as "name",
       isnull((select n.description
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'BPM_DEF_PROCESSES'
           and n.language_code = '@P_LANGUAGE@'), ' ') as "description",
       (select r.full_name from srm_resources r where r.user_id = s.last_updated_by) as "last_user",
       s.last_updated_date as "last_updated_date",	  
       'select p.process_code as "code",\n
       (select n.name\n
          from cmn_captions_nls n\n
         where n.pk_id = p.id\n
           and n.table_name = ''BPM_DEF_PROCESSES''\n
           and n.language_code = ''@P_LANGUAGE@'') as "name",\n
       st.step_code as "step",\n
       a.action_code as "action",\n
       s.script_text as "script"\n
  from bpm_def_processes        p,\n
       bpm_def_process_versions v,\n
       bpm_def_stages           stage,\n
       bpm_def_steps            st,\n
       bpm_def_step_actions     a,\n
       cmn_custom_scripts       s\n
 where stage.process_version_id = v.id\n
   and st.stage_id = stage.id\n
   and a.step_id = st.id\n
   and s.id = a.script_id\n
   and v.process_id = p.id\n
   and s.id = ' + cast(s.id as varchar) + ';' as "script"
  from bpm_def_processes        p,
       bpm_def_process_versions v,
       bpm_def_stages           stage,
       bpm_def_steps            step,
       bpm_def_step_actions     pa,
       cmn_custom_scripts       s
 where stage.process_version_id = v.id
   and step.stage_id = stage.id
   and pa.step_id = step.id
   and s.id = pa.script_id
   and v.process_id = p.id
   and (s.script_text like '%odf_aud_value_fct%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cal_events_get_nhresource_availability%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_calc_present_value%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_calc_pv_cost_for_inv%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_trunc_month_fct%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_sql_trace%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cal_event_nhresources%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cal_nhresource_types%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cal_nhresources%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_aggr_keys%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_aggr_values%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_aggr_values_validity%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_financial_values%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_pinned_investments%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_portfolio_contents%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_portfolio_roles%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_portfolios%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_priority_chart_conf%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%cmn_seq_pma_prtflio_incl_ctnt_types%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odf_ca_contract%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odf_ca_portfolio%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_aggr_keys%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_aggr_values%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_aggr_values_validity%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_ef_candidates%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_ef_investments%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_financial_values%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_pinned_investments%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_portfolio_contents%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_portfolio_roles%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_portfolios%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_priority_chart_conf%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%pma_prtflio_incl_ctnt_types%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odf_contract_v%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odf_contract_v2%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odf_portfolio_v%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odf_portfolio_v2%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odfsec_contract_v%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odfsec_contract_v2%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odfsec_portfolio_v%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%odfsec_portfolio_v2%' collate sql_latin1_general_cp1_ci_as
   or (s.script_text like '%cap_scenarios%' collate sql_latin1_general_cp1_ci_as and s.script_text like '%portfolio_id%' collate sql_latin1_general_cp1_ci_as)
   or (s.script_text like '%cmn_sec_right_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%aop_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%id%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%cmn_sec_users%' collate sql_latin1_general_cp1_ci_as and s.script_text like '%sqltrace_active%' collate sql_latin1_general_cp1_ci_as)
   or (s.script_text like '%cmn_ui_themes%' collate sql_latin1_general_cp1_ci_as and s.script_text like '%folder%' collate sql_latin1_general_cp1_ci_as)
   or (s.script_text like '%cmn_user_session_v%' collate sql_latin1_general_cp1_ci_as and s.script_text like '%sqltrace_active%' collate sql_latin1_general_cp1_ci_as)
   or (s.script_text like '%fin_cost_plan_details%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%plan_detail_1_key%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_detail_2_key%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prchargecode_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prrole_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%transclass_id%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%inv_projects%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_application_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_application_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_asset_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_asset_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
   or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_assignment_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasemax%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasepattern%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasepattern_caption%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasesum%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_assignment_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasemax%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasepattern%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasesum%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_costplan_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%plan_by_1_code_caption%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_2_code_caption%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_costplandetail_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%cost_pctplan%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%object_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_1_code%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_1_code_caption%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_2_code%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_2_code_caption%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_code%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_detail_1%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_detail_2%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_name%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prchargecode_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prrole_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%transclass_id%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_costplandetail_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%cost_pctplan%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%object_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_1_code%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_by_2_code%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_code%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_detail_1%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_detail_2%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%plan_name%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prchargecode_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prrole_id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%transclass_id%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_department_v%' collate sql_latin1_general_cp1_ci_as and s.script_text like '%last_updated_by%')
   or (s.script_text like '%odf_department_v2%' collate sql_latin1_general_cp1_ci_as and s.script_text like '%last_updated_by%')
   or (s.script_text like '%odf_idea_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_idea_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_inv_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_inv_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_investmenthierarchy_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_investmenthierarchy_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_other_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_other_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_product_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_product_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_project_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%schedule_variance%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%schedule_variance_color%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%schedule_variance_color_nls%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%schedule_variance_map%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%schedule_variance_map_nls%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_project_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%schedule_variance%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_service_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_service_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_task_v%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbaseduration%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed_image%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed_image_nls%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed_map%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed_map_nls%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%odf_task_v2%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbaseduration%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%prassignment%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbasemax%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasepattern%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasesum%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%prj_blb_slices%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%created_by%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%id%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%last_updated_by%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%last_updated_date%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%unit%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%prnote%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prcreatedby%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prmodby%' collate sql_latin1_general_cp1_ci_as))
   or (s.script_text like '%prtask%' collate sql_latin1_general_cp1_ci_as and
       (s.script_text like '%prbaseduration%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbaseisfixed%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or s.script_text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as)))

) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@
