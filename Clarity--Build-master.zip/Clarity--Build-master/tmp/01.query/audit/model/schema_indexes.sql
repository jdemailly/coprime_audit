/*
OBJECTIVE
  - Select Indexes
  - Compatible Oracle Only
  - Comparison to schema.xml to search for custom objects
HISTORY
  - 2016-06-20 : CoPrime (DMA) - Init
  - 2019-07-05 : CoPrime (DMA) - SQL Server
BUSINESS RULES
  - This result is compared with schema.xml (folder cfg/schema)
  - Oracle user_objects : Objects for current schema
  - Ignore Oracle Objects (CA compliant) :
    / Views ODFSEC_%, ODF_%
    / not user_indexes.index_type = 'LOB' : Ignore LOB Type
TESTED ON
  - Clarity 12.x, 13.x, 14.x
  - Oracle 11.2
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
        '93' as "order",
        'Oracle Custom Objects' as "name",
        'Detect Custom Indexes on Current Schema' as "description",
        'If the table is not custom, drop or disable index' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Table' as "th3",
        'Index Type' as "th4",
        'Status' as "th5",
        'Created' as "th6",
        'Flag' as "th7",
        'Script' as "th8"),
         xmlagg(xmlelement("Record", xmlforest("name", "type", "table_name", "index_type", "status", "created", "flag", "script")))).getclobval()
from (

--Indexes
select o.object_name as "name",
       o.object_type as "type",
       i.table_name as "table_name",
       i.index_type as "index_type",
       i.status as "status",
       to_char(o.created, 'yyyy-mm-dd') as "created",
       'WARN' as "flag",
       'alter index ' || o.object_name || ' disable;' as "script"
  from user_objects o
 inner join user_indexes i on i.index_name = o.object_name
 where o.object_type = 'INDEX'
   and not i.index_type = 'LOB' --Ignore LOB Type
   and not (o.object_name like 'ODF_CA_%' or o.object_name like 'ODFSEC_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%')
 order by o.object_name

)
:ORACLE@

@SQLSERVER:
select '93' as "@order",
       'SQL Server Custom Objects' as "@name",
       'Detect Custom Indexes on Current Schema' as "@description",
       'If the table is not custom, drop or disable index' as "@action",
       'Name' as "@th1",
       'Type' as "@th2",
       'Object Name' as "@th3",
       'Object Type' as "@th4",
       'Created' as "@th5",
       'Flag' as "@th6",
    (select t.* from (

--Tables
select o.name as "name",
       'INDEX' as "type",
       (select name from sys.all_objects where object_id = o.parent_object_id) as "object_name",
       (select type_desc from sys.all_objects where object_id = o.parent_object_id) as "object_type",
       convert(varchar(10), o.create_date, 126) as "created",
       'WARN' as "flag"
  from sys.all_objects o
 where o.schema_id = schema_id()
   and o.type_desc = 'PRIMARY_KEY_CONSTRAINT'
   and not (o.name like 'ODF_CA_%' or o.name like 'ODFSEC_%' or o.name like 'ODF_SSL_%' or o.name like 'ODF_SL_%')

) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@