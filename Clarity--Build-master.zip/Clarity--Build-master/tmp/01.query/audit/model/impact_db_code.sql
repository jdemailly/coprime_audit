/*
OBJECTIVE
  - Detect DB Objects (Package, View, Procedures) with potential impact on migration
  - See Data Model Analysis Document
HISTORY
  - 2014-03-11 : CoPrime (DMA) - Init
  - 2014-03-20 : CoPrime (DMA) - Script Debug and SQL Server Compatibility
  - 2015-07-08 : CoPrime (DMA) - Map SQL Server types, odf_aud_value_fct
  - 2016-06-23 : CoPrime (DMA) - Review Data Model, View Source Code
BUSINESS RULES
  - 13.0 Cost Plan Enhancement on XOG, remove XOG content <PlanData> :
    / v12   : <PlanData cost="700.0" end_date="2011-01-31" revenue="750.0" start_date="2011-01-16" units="7.0"/>
    / v13.0 : <Cost><segment finish="2008-01-31T00:00:00" start="2008-01-01T00:00:00" value="100.0"/></Cost>
  - user_views.text : Use of function dbms_xmlgen.getxml as a Workaround to get View Text and Search on It (Oracle only)
  - SQL Server      : Use of function collate sql_latin1_general_cp1_ci_as
  - Map SQL Server objects :
    / SQL_SCALAR_FUNCTION to FUNCTION
    / SQL_TABLE_VALUED_FUNCTION to FUNCTION
    / SQL_INLINE_TABLE_VALUED_FUNCTION to FUNCTION
    / SQL_TRIGGER to TRIGGER
    / SQL_STORED_PROCEDURE to PROCEDURE
    / USER_TABLE to TABLE
STAND BY
  - Search for tables and columns
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
        '93' as "order",
        'Oracle Source Code' as "name",
        'Potential Impact on Oracle objects during migration' as "description",
        'Analyze each Oracle Object and see if there is an impact during migration' as "action",
        'Name' as "th1",
        'Type' as "th2",
        'Line' as "th3",
        'Code' as "th4",
        'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "type", "line", "source_code", "script"))))
       .getclobval()
from (

--View : Use of function dbms_xmlgen.getxml to Get View Text and Search on It
select "name",
       "type",
       "line",
       "source_code",
       "script"
  from (select v1.view_name as "name",
               'VIEW' as "type",
               0 as "line",
               ' ' as "source_code",
               dbms_xmlgen.getxml('select text from user_views where view_name = ''' || v1.view_name || '''') as text,
               'select * from user_views where view_name = ''' || v1.view_name || ''';' as "script"
          from user_views v1
         where not v1.view_name like 'ODFSEC_%'
           and not v1.view_name like 'ODF_%'
           and not v1.view_name like 'RPT_%'
           and not v1.view_name like 'PRJ_%'
           and not v1.view_name like 'NBI_%'
           and not v1.view_name like 'CMN_%'
           and not v1.view_name like 'NTD_%'
           and not v1.view_name like 'CLB_%'
           and not v1.view_name like 'CAL_%'
           and not v1.view_name like 'INV_%'
           and not v1.view_name like 'OBS_%'
           and not v1.view_name like 'BPM_%'
           and not v1.view_name like 'BIZ_%') v
 where lower(v.text) like '%<plandata%'
    or lower(v.text) like '%odf_aud_value_fct%'
    or lower(v.text) like '%cal_events_get_nhresource_availability%'
    or lower(v.text) like '%pma_calc_present_value%'
    or lower(v.text) like '%pma_calc_pv_cost_for_inv%'
    or lower(v.text) like '%pma_trunc_month_fct%'
    or lower(v.text) like '%cmn_sql_trace%'
    or lower(v.text) like '%cal_event_nhresources%'
    or lower(v.text) like '%cal_nhresource_types%'
    or lower(v.text) like '%cal_nhresources%'
    or lower(v.text) like '%cmn_seq_pma_aggr_keys%'
    or lower(v.text) like '%cmn_seq_pma_aggr_values%'
    or lower(v.text) like '%cmn_seq_pma_aggr_values_validity%'
    or lower(v.text) like '%cmn_seq_pma_financial_values%'
    or lower(v.text) like '%cmn_seq_pma_pinned_investments%'
    or lower(v.text) like '%cmn_seq_pma_portfolio_contents%'
    or lower(v.text) like '%cmn_seq_pma_portfolio_roles%'
    or lower(v.text) like '%cmn_seq_pma_portfolios%'
    or lower(v.text) like '%cmn_seq_pma_priority_chart_conf%'
    or lower(v.text) like '%cmn_seq_pma_prtflio_incl_ctnt_types%'
    or lower(v.text) like '%odf_ca_contract%'
    or lower(v.text) like '%odf_ca_portfolio%'
    or lower(v.text) like '%pma_aggr_keys%'
    or lower(v.text) like '%pma_aggr_values%'
    or lower(v.text) like '%pma_aggr_values_validity%'
    or lower(v.text) like '%pma_ef_candidates%'
    or lower(v.text) like '%pma_ef_investments%'
    or lower(v.text) like '%pma_financial_values%'
    or lower(v.text) like '%pma_pinned_investments%'
    or lower(v.text) like '%pma_portfolio_contents%'
    or lower(v.text) like '%pma_portfolio_roles%'
    or lower(v.text) like '%pma_portfolios%'
    or lower(v.text) like '%pma_priority_chart_conf%'
    or lower(v.text) like '%pma_prtflio_incl_ctnt_types%'
    or lower(v.text) like '%odf_contract_v%'
    or lower(v.text) like '%odf_contract_v2%'
    or lower(v.text) like '%odf_portfolio_v%'
    or lower(v.text) like '%odf_portfolio_v2%'
    or lower(v.text) like '%odfsec_contract_v%'
    or lower(v.text) like '%odfsec_contract_v2%'
    or lower(v.text) like '%odfsec_portfolio_v%'
    or lower(v.text) like '%odfsec_portfolio_v2%'
    or (lower(v.text) like '%cap_scenarios%' and lower(v.text) like '%portfolio_id%')
    or (lower(v.text) like '%cmn_sec_right_v%' and (lower(v.text) like '%aop_id%' or lower(v.text) like '%id%'))
    or (lower(v.text) like '%cmn_sec_users%' and lower(v.text) like '%sqltrace_active%')
    or (lower(v.text) like '%cmn_ui_themes%' and lower(v.text) like '%folder%')
    or (lower(v.text) like '%cmn_user_session_v%' and lower(v.text) like '%sqltrace_active%')
    or (lower(v.text) like '%fin_cost_plan_details%' and
        (lower(v.text) like '%plan_detail_1_key%' or lower(v.text) like '%plan_detail_2_key%' or
         lower(v.text) like '%prchargecode_id%' or lower(v.text) like '%prrole_id%' or
         lower(v.text) like '%transclass_id%'))
    or (lower(v.text) like '%inv_projects%' and
        (lower(v.text) like '%prbasefinish%' or lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasetime%'))
    or (lower(v.text) like '%odf_application_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_application_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_asset_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_asset_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_assignment_v%' and
        (lower(v.text) like '%prbasefinish%' or lower(v.text) like '%prbasemax%' or
         lower(v.text) like '%prbasepattern%' or lower(v.text) like '%prbasepattern_caption%' or
         lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasesum%'))
    or (lower(v.text) like '%odf_assignment_v2%' and
        (lower(v.text) like '%prbasefinish%' or lower(v.text) like '%prbasemax%' or
         lower(v.text) like '%prbasepattern%' or lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasesum%'))
    or (lower(v.text) like '%odf_costplan_v%' and
        (lower(v.text) like '%plan_by_1_code_caption%' or lower(v.text) like '%plan_by_2_code_caption%'))
    or (lower(v.text) like '%odf_costplandetail_v%' and
        (lower(v.text) like '%cost_pctplan%' or lower(v.text) like '%object_id%' or
         lower(v.text) like '%plan_by_1_code%' or lower(v.text) like '%plan_by_1_code_caption%' or
         lower(v.text) like '%plan_by_2_code%' or lower(v.text) like '%plan_by_2_code_caption%' or
         lower(v.text) like '%plan_code%' or lower(v.text) like '%plan_detail_1%' or
         lower(v.text) like '%plan_detail_2%' or lower(v.text) like '%plan_name%' or
         lower(v.text) like '%prchargecode_id%' or lower(v.text) like '%prrole_id%' or
         lower(v.text) like '%transclass_id%'))
    or (lower(v.text) like '%odf_costplandetail_v2%' and
        (lower(v.text) like '%cost_pctplan%' or lower(v.text) like '%object_id%' or
         lower(v.text) like '%plan_by_1_code%' or lower(v.text) like '%plan_by_2_code%' or
         lower(v.text) like '%plan_code%' or lower(v.text) like '%plan_detail_1%' or
         lower(v.text) like '%plan_detail_2%' or lower(v.text) like '%plan_name%' or
         lower(v.text) like '%prchargecode_id%' or lower(v.text) like '%prrole_id%' or
         lower(v.text) like '%transclass_id%'))
    or (lower(v.text) like '%odf_department_v%' and lower(v.text) like '%last_updated_by%')
    or (lower(v.text) like '%odf_department_v2%' and lower(v.text) like '%last_updated_by%')
    or (lower(v.text) like '%odf_idea_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_idea_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_inv_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_inv_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_investmenthierarchy_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_investmenthierarchy_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_other_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_other_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_product_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_product_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_project_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasetime%' or
         lower(v.text) like '%schedule_variance%' or lower(v.text) like '%schedule_variance_color%' or
         lower(v.text) like '%schedule_variance_color_nls%' or lower(v.text) like '%schedule_variance_map%' or
         lower(v.text) like '%schedule_variance_map_nls%'))
    or (lower(v.text) like '%odf_project_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbasestart%' or lower(v.text) like '%prbasetime%' or
         lower(v.text) like '%schedule_variance%'))
    or (lower(v.text) like '%odf_service_v%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_service_v2%' and
        (lower(v.text) like '%inv_planned_npv%' or lower(v.text) like '%inv_planned_roi%' or
         lower(v.text) like '%planned_pv_cost%'))
    or (lower(v.text) like '%odf_task_v%' and
        (lower(v.text) like '%prbaseduration%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbaseisfixed%' or lower(v.text) like '%prbaseisfixed_image%' or
         lower(v.text) like '%prbaseisfixed_image_nls%' or lower(v.text) like '%prbaseisfixed_map%' or
         lower(v.text) like '%prbaseisfixed_map_nls%' or lower(v.text) like '%prbasestart%' or
         lower(v.text) like '%prbasetime%'))
    or (lower(v.text) like '%odf_task_v2%' and
        (lower(v.text) like '%prbaseduration%' or lower(v.text) like '%prbasefinish%' or
         lower(v.text) like '%prbaseisfixed%' or lower(v.text) like '%prbasestart%' or
         lower(v.text) like '%prbasetime%'))
    or (lower(v.text) like '%prassignment%' and
        (lower(v.text) like '%prbasemax%' or lower(v.text) like '%prbasepattern%' or lower(v.text) like '%prbasesum%'))
    or (lower(v.text) like '%prj_blb_slices%' and
        (lower(v.text) like '%created_by%' or lower(v.text) like '%id%' or lower(v.text) like '%last_updated_by%' or
         lower(v.text) like '%last_updated_date%' or lower(v.text) like '%unit%'))
    or (lower(v.text) like '%prnote%' and (lower(v.text) like '%prcreatedby%' or lower(v.text) like '%prmodby%'))
    or (lower(v.text) like '%prtask%' and (lower(v.text) like '%prbaseduration%' or lower(v.text) like '%prbasefinish%' or
                                           lower(v.text) like '%prbaseisfixed%' or lower(v.text) like '%prbasestart%' or
                                           lower(v.text) like '%prbasetime%'))

union all
--Procedure, Function, Package
select o.object_name as "name",
       o.object_type as "type",
       s.line        as "line",
       s.text        as "source_code",
       'select * from user_source where name = ''' || o.object_name || ''' and type = ''' || o.object_type || ''';' as "script"
  from user_objects o
 inner join user_source s on s.name = o.object_name
                         and s.type = o.object_type
 where lower(s.text) like '%<plandata%' or lower(s.text) like '%odf_aud_value_fct%' or lower(s.text) like '%cal_events_get_nhresource_availability%' or
       lower(s.text) like '%pma_calc_present_value%' or lower(s.text) like '%pma_calc_pv_cost_for_inv%' or
       lower(s.text) like '%pma_trunc_month_fct%' or lower(s.text) like '%cmn_sql_trace%' or
       lower(s.text) like '%cal_event_nhresources%' or lower(s.text) like '%cal_nhresource_types%' or
       lower(s.text) like '%cal_nhresources%' or lower(s.text) like '%cmn_seq_pma_aggr_keys%' or
       lower(s.text) like '%cmn_seq_pma_aggr_values%' or
       lower(s.text) like '%cmn_seq_pma_aggr_values_validity%' or
       lower(s.text) like '%cmn_seq_pma_financial_values%' or
       lower(s.text) like '%cmn_seq_pma_pinned_investments%' or
       lower(s.text) like '%cmn_seq_pma_portfolio_contents%' or
       lower(s.text) like '%cmn_seq_pma_portfolio_roles%' or lower(s.text) like '%cmn_seq_pma_portfolios%' or
       lower(s.text) like '%cmn_seq_pma_priority_chart_conf%' or
       lower(s.text) like '%cmn_seq_pma_prtflio_incl_ctnt_types%' or lower(s.text) like '%odf_ca_contract%' or
       lower(s.text) like '%odf_ca_portfolio%' or lower(s.text) like '%pma_aggr_keys%' or
       lower(s.text) like '%pma_aggr_values%' or lower(s.text) like '%pma_aggr_values_validity%' or
       lower(s.text) like '%pma_ef_candidates%' or lower(s.text) like '%pma_ef_investments%' or
       lower(s.text) like '%pma_financial_values%' or lower(s.text) like '%pma_pinned_investments%' or
       lower(s.text) like '%pma_portfolio_contents%' or lower(s.text) like '%pma_portfolio_roles%' or
       lower(s.text) like '%pma_portfolios%' or lower(s.text) like '%pma_priority_chart_conf%' or
       lower(s.text) like '%pma_prtflio_incl_ctnt_types%' or lower(s.text) like '%odf_contract_v%' or
       lower(s.text) like '%odf_contract_v2%' or lower(s.text) like '%odf_portfolio_v%' or
       lower(s.text) like '%odf_portfolio_v2%' or lower(s.text) like '%odfsec_contract_v%' or
       lower(s.text) like '%odfsec_contract_v2%' or lower(s.text) like '%odfsec_portfolio_v%' or
       lower(s.text) like '%odfsec_portfolio_v2%' or
       (lower(s.text) like '%cap_scenarios%' and lower(s.text) like '%portfolio_id%') or
       (lower(s.text) like '%cmn_sec_right_v%' and
       (lower(s.text) like '%aop_id%' or lower(s.text) like '%id%')) or
       (lower(s.text) like '%cmn_sec_users%' and lower(s.text) like '%sqltrace_active%') or
       (lower(s.text) like '%cmn_ui_themes%' and lower(s.text) like '%folder%') or
       (lower(s.text) like '%cmn_user_session_v%' and lower(s.text) like '%sqltrace_active%') or
       (lower(s.text) like '%fin_cost_plan_details%' and
       (lower(s.text) like '%plan_detail_1_key%' or lower(s.text) like '%plan_detail_2_key%' or
       lower(s.text) like '%prchargecode_id%' or lower(s.text) like '%prrole_id%' or
       lower(s.text) like '%transclass_id%')) or
       (lower(s.text) like '%inv_projects%' and
       (lower(s.text) like '%prbasefinish%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%')) or
       (lower(s.text) like '%odf_application_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_application_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_asset_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_asset_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_assignment_v%' and
       (lower(s.text) like '%prbasefinish%' or lower(s.text) like '%prbasemax%' or
       lower(s.text) like '%prbasepattern%' or lower(s.text) like '%prbasepattern_caption%' or
       lower(s.text) like '%prbasestart%' or lower(s.text) like '%prbasesum%')) or
       (lower(s.text) like '%odf_assignment_v2%' and
       (lower(s.text) like '%prbasefinish%' or lower(s.text) like '%prbasemax%' or
       lower(s.text) like '%prbasepattern%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasesum%')) or
       (lower(s.text) like '%odf_costplan_v%' and
       (lower(s.text) like '%plan_by_1_code_caption%' or lower(s.text) like '%plan_by_2_code_caption%')) or
       (lower(s.text) like '%odf_costplandetail_v%' and
       (lower(s.text) like '%cost_pctplan%' or lower(s.text) like '%object_id%' or
       lower(s.text) like '%plan_by_1_code%' or lower(s.text) like '%plan_by_1_code_caption%' or
       lower(s.text) like '%plan_by_2_code%' or lower(s.text) like '%plan_by_2_code_caption%' or
       lower(s.text) like '%plan_code%' or lower(s.text) like '%plan_detail_1%' or
       lower(s.text) like '%plan_detail_2%' or lower(s.text) like '%plan_name%' or
       lower(s.text) like '%prchargecode_id%' or lower(s.text) like '%prrole_id%' or
       lower(s.text) like '%transclass_id%')) or
       (lower(s.text) like '%odf_costplandetail_v2%' and
       (lower(s.text) like '%cost_pctplan%' or lower(s.text) like '%object_id%' or
       lower(s.text) like '%plan_by_1_code%' or lower(s.text) like '%plan_by_2_code%' or
       lower(s.text) like '%plan_code%' or lower(s.text) like '%plan_detail_1%' or
       lower(s.text) like '%plan_detail_2%' or lower(s.text) like '%plan_name%' or
       lower(s.text) like '%prchargecode_id%' or lower(s.text) like '%prrole_id%' or
       lower(s.text) like '%transclass_id%')) or
       (lower(s.text) like '%odf_department_v%' and lower(s.text) like '%last_updated_by%') or
       (lower(s.text) like '%odf_department_v2%' and lower(s.text) like '%last_updated_by%') or
       (lower(s.text) like '%odf_idea_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_idea_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_inv_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_inv_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_investmenthierarchy_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_investmenthierarchy_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_other_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_other_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_product_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_product_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_project_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbasestart%' or lower(s.text) like '%prbasetime%' or
       lower(s.text) like '%schedule_variance%' or lower(s.text) like '%schedule_variance_color%' or
       lower(s.text) like '%schedule_variance_color_nls%' or lower(s.text) like '%schedule_variance_map%' or
       lower(s.text) like '%schedule_variance_map_nls%')) or
       (lower(s.text) like '%odf_project_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbasestart%' or lower(s.text) like '%prbasetime%' or
       lower(s.text) like '%schedule_variance%')) or
       (lower(s.text) like '%odf_service_v%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_service_v2%' and
       (lower(s.text) like '%inv_planned_npv%' or lower(s.text) like '%inv_planned_roi%' or
       lower(s.text) like '%planned_pv_cost%')) or
       (lower(s.text) like '%odf_task_v%' and
       (lower(s.text) like '%prbaseduration%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbaseisfixed%' or lower(s.text) like '%prbaseisfixed_image%' or
       lower(s.text) like '%prbaseisfixed_image_nls%' or lower(s.text) like '%prbaseisfixed_map%' or
       lower(s.text) like '%prbaseisfixed_map_nls%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%')) or
       (lower(s.text) like '%odf_task_v2%' and
       (lower(s.text) like '%prbaseduration%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbaseisfixed%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%')) or
       (lower(s.text) like '%prassignment%' and
       (lower(s.text) like '%prbasemax%' or lower(s.text) like '%prbasepattern%' or
       lower(s.text) like '%prbasesum%')) or
       (lower(s.text) like '%prj_blb_slices%' and
       (lower(s.text) like '%created_by%' or lower(s.text) like '%id%' or
       lower(s.text) like '%last_updated_by%' or lower(s.text) like '%last_updated_date%' or
       lower(s.text) like '%unit%')) or
       (lower(s.text) like '%prnote%' and
       (lower(s.text) like '%prcreatedby%' or lower(s.text) like '%prmodby%')) or
       (lower(s.text) like '%prtask%' and
       (lower(s.text) like '%prbaseduration%' or lower(s.text) like '%prbasefinish%' or
       lower(s.text) like '%prbaseisfixed%' or lower(s.text) like '%prbasestart%' or
       lower(s.text) like '%prbasetime%'))
      
      

):ORACLE@

@SQLSERVER:
select '93' as "@order",
       'SQL Server Source Code' as "@name",
       'Potential Impact on SQL Server objects during migration' as "@description",
       'Analyze each SQL Server Object and see if there is an impact during migration' as "@action",
       'Name' as "@th1",
       'Type' as "@th2",
       'Created' as "@th3",
       'Script' as "@th4",
		(select t.* from (
select o.name as "name",
	   (case xtype
			when 'C' then 'Check Const'
			when 'D' then 'Default Const'
			when 'F' then 'Foreign Key Const'
			when 'L' then 'Log'
			when 'P' then 'PROCEDURE'
			when 'PK' then 'Primary Key Const'
			when 'RF' then 'Replication Filter Proc'
			when 'S' then 'System Table'
			when 'TR' then 'TRIGGER'
			when 'U' then 'TABLE'
			when 'UQ' then 'Unique Const'
			when 'V' then 'VIEW'
			when 'X' then 'PROCEDURE' --Extended Proc
			when 'FN' then 'FUNCTION' --User-Defined Function
			else 'Unknown'
		end) as "type",		
	   o.crdate as "created",
	   'select text from syscomments where id = ' + cast(c.id as varchar) as "script"
from sysobjects o
inner join syscomments c on c.id = o.id
where c.text like '%<plandata%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_aud_value_fct%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cal_events_get_nhresource_availability%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_calc_present_value%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_calc_pv_cost_for_inv%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_trunc_month_fct%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_sql_trace%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cal_event_nhresources%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cal_nhresource_types%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cal_nhresources%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_aggr_keys%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_aggr_values%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_aggr_values_validity%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_financial_values%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_pinned_investments%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_portfolio_contents%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_portfolio_roles%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_portfolios%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_priority_chart_conf%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%cmn_seq_pma_prtflio_incl_ctnt_types%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_ca_contract%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_ca_portfolio%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_aggr_keys%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_aggr_values%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_aggr_values_validity%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_ef_candidates%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_ef_investments%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_financial_values%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_pinned_investments%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_portfolio_contents%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_portfolio_roles%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_portfolios%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_priority_chart_conf%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%pma_prtflio_incl_ctnt_types%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_contract_v%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_contract_v2%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_portfolio_v%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odf_portfolio_v2%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odfsec_contract_v%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odfsec_contract_v2%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odfsec_portfolio_v%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%odfsec_portfolio_v2%' collate sql_latin1_general_cp1_ci_as
   or (c.text like '%cap_scenarios%' collate sql_latin1_general_cp1_ci_as and c.text like '%portfolio_id%' collate sql_latin1_general_cp1_ci_as)
   or (c.text like '%cmn_sec_right_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%aop_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%id%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%cmn_sec_users%' collate sql_latin1_general_cp1_ci_as and c.text like '%sqltrace_active%' collate sql_latin1_general_cp1_ci_as)
   or (c.text like '%cmn_ui_themes%' collate sql_latin1_general_cp1_ci_as and c.text like '%folder%' collate sql_latin1_general_cp1_ci_as)
   or (c.text like '%cmn_user_session_v%' collate sql_latin1_general_cp1_ci_as and c.text like '%sqltrace_active%' collate sql_latin1_general_cp1_ci_as)
   or (c.text like '%fin_cost_plan_details%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%plan_detail_1_key%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_detail_2_key%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prchargecode_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prrole_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%transclass_id%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%inv_projects%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_application_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_application_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_asset_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_asset_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
   or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_assignment_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasemax%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasepattern%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasepattern_caption%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasesum%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_assignment_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasemax%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasepattern%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasesum%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_costplan_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%plan_by_1_code_caption%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_2_code_caption%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_costplandetail_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%cost_pctplan%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%object_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_1_code%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_1_code_caption%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_2_code%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_2_code_caption%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_code%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_detail_1%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_detail_2%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_name%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prchargecode_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prrole_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%transclass_id%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_costplandetail_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%cost_pctplan%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%object_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_1_code%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_by_2_code%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_code%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_detail_1%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_detail_2%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%plan_name%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prchargecode_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prrole_id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%transclass_id%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_department_v%' collate sql_latin1_general_cp1_ci_as and c.text like '%last_updated_by%')
   or (c.text like '%odf_department_v2%' collate sql_latin1_general_cp1_ci_as and c.text like '%last_updated_by%')
   or (c.text like '%odf_idea_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_idea_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_inv_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_inv_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_investmenthierarchy_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_investmenthierarchy_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_other_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_other_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_product_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_product_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_project_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%schedule_variance%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%schedule_variance_color%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%schedule_variance_color_nls%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%schedule_variance_map%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%schedule_variance_map_nls%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_project_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%schedule_variance%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_service_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_service_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%inv_planned_npv%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%inv_planned_roi%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%planned_pv_cost%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_task_v%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbaseduration%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed_image%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed_image_nls%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed_map%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed_map_nls%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%odf_task_v2%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbaseduration%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%prassignment%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbasemax%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasepattern%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasesum%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%prj_blb_slices%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%created_by%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%id%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%last_updated_by%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%last_updated_date%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%unit%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%prnote%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prcreatedby%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prmodby%' collate sql_latin1_general_cp1_ci_as))
   or (c.text like '%prtask%' collate sql_latin1_general_cp1_ci_as and
       (c.text like '%prbaseduration%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasefinish%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbaseisfixed%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasestart%' collate sql_latin1_general_cp1_ci_as
       or c.text like '%prbasetime%' collate sql_latin1_general_cp1_ci_as))
) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@