/*
OBJECTIVE
  - Detect Tables with a bad naming (dot
  - On SQL Server, error occurs when generating table sequences
HISTORY
  - 2015-07-01 : CoPrime (DMA) - Map SQL Server Objects, Conditions
BUSINESS RULES
  - Oracle user_tables : Tables for current schema
  - SQL Server sys.tables : Tables for current schema
LOG
  - java.sql.SQLException: [CA Clarity][SQLServer JDBC Driver][SQLServer]The specified schema name "CMN_SEQ_NIKU" either does not exist or you do not have permission to use it.
TESTED ON
  - Clarity v12.x, v13.x
  - Oracle 11.2
  - SQL Server 2008R2, 2012 
*/

@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
        '93' as "order",
        'Oracle Custom Objects' as "name",
        'Detect Custom Tables with a bad naming (dot)' as "description",
        'Rename table or drop it' as "action",
        'Name' as "th1",
        'Created' as "th2",
        'Flag' as "th3",
        'Script' as "th4"),
         xmlagg(xmlelement("Record", xmlforest("name", "created", "flag", "script")))).getclobval()
from (

select t.table_name as "name",
       o.created    as "created",
       'NOK'        as "flag",
       'drop table ' || t.table_name || ';\nrename table ' || t.table_name || ' to ' || replace(t.table_name, '.', '') || ';' as "script"
  from user_tables  t,
       user_objects o
 where t.table_name = o.object_name
   and o.object_type = 'TABLE'
   and instr(t.table_name, '.') > 0

)
:ORACLE@

@SQLSERVER:
select '93' as "@order",
       'SQL Server Custom Objects' as "@name",
       'Detect Custom Tables with a bad naming (dot)' as "@description",
       'Rename table or drop it' as "@action",
       'Name' as "@th1",
       'Created' as "@th2",
       'Flag' as "@th3",
       'Script' as "@th4",
    (select t.* from (

select t.name as "name",
       t.create_date as "created",
       'NOK' as "flag",
       'drop table [' + t.name + ']' as "script"
  from sys.tables t
 where charindex('.', t.name) > 0

) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@
