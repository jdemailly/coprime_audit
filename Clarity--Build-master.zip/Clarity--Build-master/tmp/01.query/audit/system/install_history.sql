/*
OBJECTIVE
  - Get Clarity Installation History
HISTORY
  - 2014-03-11 : CoPrime (DMA) - Init
  - 2014-03-24 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - cmn_install_history : Table for Installation History 
TESTED ON
  - Oracle 11.x, SQL Server 2008R2
  - Clarity 12.x 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '12' as "order",
         'System Info' as "name",
         'Clarity Installation History (add-on, upgrade, database, etc.)' as "description",
         'Type' as "th1",
         'Value' as "th2",
         'Date' as "th3"),
       xmlagg(xmlelement(name "Record", xmlforest("type", "value", "date"))))
       .getclobval()
from (
select h.install_id        as "type",
       h.installed_version as "value",
       h.installed_date    as "date"
  from cmn_install_history h
 order by h.installed_date desc
):ORACLE@

@SQLSERVER:
select '12' as "@order",
       'System Info' as "@name",
       'Clarity Installation History (add-on, upgrade, database, etc.)' as "@description",
       'Type' as "@th1",
       'Value' as "@th2",
       'Date' as "@th3",
       (select t."type",
       		   t."value",
       		   convert(varchar(10), t."date", 126) as "date"
          from (
select h.install_id        as "type",
       h.installed_version as "value",
       h.installed_date    as "date"
  from cmn_install_history h         
) t order by t."date" desc
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@
