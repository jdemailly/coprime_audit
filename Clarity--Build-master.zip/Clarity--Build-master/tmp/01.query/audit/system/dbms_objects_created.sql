/*
OBJECTIVE
  - Info on Database
  - Get Object Creation Date
HISTORY
  - 2014-03-11 : CoPrime (DMA) - Init
  - 2014-02-24 : CoPrime (DMA) - SQL Server Compatibility and Split Query
BUSINESS RULES
  - user_objects : Oracle User View
  - sys.objects  : SQL Server Objects
  - sys.objects.schema_id = schema_id() : SQL Server Objects for current schema
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 12.x, 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '13' as "order",
         'System Info' as "name",
         'Count Oracle Objects by Creation Date' as "description",
         'Date' as "th1",
         'Count' as "th2"),
       xmlagg(xmlelement(name "Record", xmlforest("date", "count"))))
       .getclobval()
from (

select to_char(trunc(o.created), 'YYYY-MM-DD') as "date",
       count(*) as "count"
  from user_objects o
 group by trunc(o.created)
 order by trunc(o.created) desc

):ORACLE@

@SQLSERVER:
select '13' as "@order",
       'System Info' as "@name",
       'Count SQL Server Objects by Creation Date' as "@description",
       'Date' as "@th1",
       'Count' as "@th2",   
       (select t.date as "date",
               t.count as "count"
          from (

select left(convert(varchar, o.create_date, 126), 10) as "date",
       count(*) as "count"
  from sys.objects o
 where o.schema_id = schema_id()
 group by left(convert(varchar, o.create_date, 126), 10)

) t order by t."date" desc
for xml path('Record'), type)  for xml path('QueryResult')
:SQLSERVER@
