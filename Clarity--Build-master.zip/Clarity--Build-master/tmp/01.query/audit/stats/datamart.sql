/*
OBJECTIVE
  - Audit Clarity Database
  - Show Statistics
HISTORY
  - 2014-02-13 : CoPrime (DMA) - Init
BUSINESS RULES
  - Attributes of node QueryResult are header names
  - Each node Record is a row
  - Use of tag ORACLE and SQLSERVER to add compatibility for both DBMS
STAND BY
  select 'NBI_DIM_OBS_PP',
         count(*)
    from nbi_dim_obs_pp
  union all
  select 'NBI_LOG_MATRIX_DATES',
         count(*)
    from nbi_log_matrix_dates
  union all
  select 'NBI_PRTF_FM',
         count(*)
    from nbi_prtf_fm
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 13.1
*/
@ORACLE:
select xmlelement(name "QueryResult",
     xmlattributes(
     '35' as "order",
     'Statistics' as "name",
     'Datamart' as "description",
     'Table' as "th1",
     'Count' as "th2"),
     xmlagg(xmlelement(name "Record", xmlforest("table", "count"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '35'              as "@order",
       'Statistics'      as "@name",
       'Datamart' as "@description",
       'Table'           as "@th1",
       'Count'           as "@th2",
       (select t."table" as "table",
               cast(t.count as integer) as "count"
          from (:SQLSERVER@

select 'NBI_CFG_OBS_ASSIGNMENTS' as "table",
       count(*) as "count"
  from nbi_cfg_obs_assignments
union all
select 'NBI_CFG_STOPLIGHT_QUERIES',
       count(*)
  from nbi_cfg_stoplight_queries
union all
select 'NBI_DIM_CALENDAR_TIME',
       count(*)
  from nbi_dim_calendar_time
union all
select 'NBI_DIM_FISCAL_TIME',
       count(*)
  from nbi_dim_fiscal_time
union all
select 'NBI_DIM_OBS',
       count(*)
  from nbi_dim_obs
union all
select 'NBI_DIM_OBS_FLAT',
       count(*)
  from nbi_dim_obs_flat
union all
select 'NBI_EVENTS',
       count(*)
  from nbi_events
union all
select 'NBI_FM_PROJECT_TIME_SUMMARY',
       count(*)
  from nbi_fm_project_time_summary
union all
select 'NBI_FM_PT_FACTS',
       count(*)
  from nbi_fm_pt_facts
union all
select 'NBI_PM_PROJECT_TIME_SUMMARY',
       count(*)
  from nbi_pm_project_time_summary
union all
select 'NBI_PM_PT_FACTS',
       count(*)
  from nbi_pm_pt_facts
union all
select 'NBI_PRJ_MATRIX_DATES',
       count(*)
  from nbi_prj_matrix_dates
union all
select 'NBI_PROJECT_CURRENT_FACTS',
       count(*)
  from nbi_project_current_facts
union all
select 'NBI_PROJECT_FORECAST',
       count(*)
  from nbi_project_forecast
union all
select 'NBI_PROJ_RES_RATES_AND_COSTS',
       count(*)
  from nbi_proj_res_rates_and_costs
union all
select 'NBI_PROJ_RES_RATES_AND_COSTSCP',
       count(*)
  from nbi_proj_res_rates_and_costscp
union all
select 'NBI_PRT_FACTS',
       count(*)
  from nbi_prt_facts
union all
select 'NBI_RESOURCE_CURRENT_FACTS',
       count(*)
  from nbi_resource_current_facts
union all
select 'NBI_RESOURCE_TIME_SUMMARY',
       count(*)
  from nbi_resource_time_summary
union all
select 'NBI_ROLLUP_SQL',
       count(*)
  from nbi_rollup_sql
union all
select 'NBI_RT_FACTS',
       count(*)
  from nbi_rt_facts
union all
select 'NBI_RUN_LOGS',
       count(*)
  from nbi_run_logs
union all
select 'NBI_R_FACTS',
       count(*)
  from nbi_r_facts

 ) t
         
@SQLSERVER:
for xml path('Record'), type) for xml path('QueryResult')
:SQLSERVER@
