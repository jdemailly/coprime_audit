/*
OBJECTIVE
  - Shows Time Slices statistics
HISTORY
  - 2014-03-25 : CoPrime (DMA) - Init
BUSINESS RULES
  - prj_blb_slicerequests.table_name = 'PRJ_BLB_SLICES' : Look for PRJ_BLB_SLICES only
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
     xmlattributes(
      '34' as "order",
      'Statistics' as "name",
      'Time Slices' as "description",
      'Name' as "th1",
      'Count' as "th2"),
     xmlagg(xmlelement(name "Record", xmlforest("name", "count"))))
       .getclobval()
from (:ORACLE@

@SQLSERVER:
select '34'          as "@order",
       'Statistics'  as "@name",
       'Time Slices' as "@description",
       'Name'        as "@th1",
       'Count'       as "@th2",
       (select t.name as "name",
               cast(t.count as integer) as "count"
          from (:SQLSERVER@

select 'Slice ' @+@ r.request_name as "name",
       (select count(*) from prj_blb_slices s where s.slice_request_id = r.id) as "count"
  from prj_blb_slicerequests r
 where r.table_name = 'PRJ_BLB_SLICES'

 ) t         
@SQLSERVER:
for xml path('Record'), type) for xml path('QueryResult')
:SQLSERVER@
