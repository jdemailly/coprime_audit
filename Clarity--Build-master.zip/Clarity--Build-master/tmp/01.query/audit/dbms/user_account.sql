/*
OBJECTIVE
  - User Account and Grants
HISTORY
  - 2016-06-15 : CoPrime (DMA) - Init
  - 2016-06-23 : CoPrime (DMA) - Grant, Role
BUSINESS RULES
  - View user_users : Users
STAND BY
  - SQL Server 2008R2, 2012
TESTED ON
  - Oracle 11.x
  - Clarity 12.x 13.x
*/

@ORACLE:
select xmlelement(name "QueryResult",
  xmlattributes(
    '22' as "order",
    'Oracle' as "name",
    'Oracle User' as "description",
    'Check that User is Unlocked and has correct Grants' as "action",
    'Property' as "th1",
    'Value' as "th2",
    'Flag' as "th3"),
    xmlagg(xmlelement(name "Record", xmlforest(property, value, flag))))
       .getclobval()
from (

with

--User
us as
 (select u.username,
         u.account_status,
         u.lock_date,
         u.expiry_date,
         u.default_tablespace
    from user_users u
   where u.username = user)

--Select
select 'Username' as property,
       username   as value,
       null       as flag,
       null       as script
  from us
union all
select 'Status',
       account_status,
       null,
       null
  from us
union all
select 'Default Tablespace',
       default_tablespace,
       null,
       null
  from us
union all
select 'Lock Date',
       to_char(lock_date, 'YYYY-MM-DD HH24:MM:SS'),
       'NOK',
       '--Unlock User\n
alter user ' || user || ' account unlock;'
  from us
 where lock_date is not null
union all
select 'Expiry Date',
       to_char(expiry_date, 'YYYY-MM-DD HH24:MM:SS'),
       'WARN',
       '--Set Password Life Time to unlimited\n
alter profile default limit password_life_time unlimited;\n
--Unlock User\n
alter user ' || user || ' account unlock;'
  from us
 where expiry_date is not null
--Grant
union all
select 'Privilege',
       privilege,
       null,
       null
  from user_sys_privs
union all
select 'Role',
       granted_role,
       null,
       null
  from user_role_privs
union all
select property,
       value,
       null,
       null
  from (select 'Privilege through Role ' || r.role as property,
               r.privilege as value
          from role_sys_privs r
         inner join user_role_privs ro on ro.granted_role = r.role
         order by r.role)

):ORACLE@
