/*
OBJECTIVE
  - Detect DB Invalid Objects with potential impact on migration
HISTORY
  - 2014-03-12 : CoPrime (DMA) - Init
  - 2014-04-01 : CoPrime (DMA) - Script recompile
  - 2014-04-24 : CoPrime (DMA) - Flag Warning
  - 2016-07-06 : CoPrime (DMA) - Compilation Script
BUSINESS RULES
  - Oracle
    / Use of dbms_utility.compile_schema to recompile all objects
    / Use of function sys_context('userenv', 'current_schema') to get current schema
STAND BY
  - SQL Server (sp_recompile or FMTONLY)
  select null for xml path ('QueryResult')
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '24' as "order",
         'Oracle' as "name",
         'Detect Oracle Invalid Objects on current schema' as "description",
         'Run following script to recompile all objects on current schema and analyze each invalid object' as "action",
         'declare\n
  cursor my_sqls is\n
    select case\n
             when o.object_type in (''PACKAGE'', ''PROCEDURE'', ''FUNCTION'', ''TRIGGER'', ''VIEW'', ''TYPE'') then\n
              ''alter '' || lower(o.object_type) || '' '' || lower(o.object_name) || '' compile''\n
             when o.object_type = ''PACKAGE BODY'' then\n
              ''alter package '' || lower(o.object_name) || '' compile body''\n
           end as script\n
      from user_objects o\n
     where not o.status = ''VALID''\n
     order by o.object_name;\n
begin\n
  for my_sql in my_sqls loop\n
    execute immediate my_sql.script;\n
  end loop;\n
end;' as "script",
         'Name' as "th1",
         'Type' as "th2",
         'Status' as "th3",
         'Flag' as "th4",
         'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "type", "status", "flag", "script"))))
       .getclobval()
from (

--Select
select o.object_name as "name",
       o.object_type as "type",
       o.status as "status",
       'WARN' as "flag",
       case
         when o.object_type in ('PACKAGE', 'PROCEDURE', 'FUNCTION', 'TRIGGER', 'VIEW', 'TYPE') then
          'alter ' || lower(o.object_type) || ' ' || lower(o.object_name) || ' compile'
         when o.object_type = 'PACKAGE BODY' then
          'alter package ' || lower(o.object_name) || ' compile body'
       end as "script"
  from user_objects o
 where not o.status = 'VALID'

):ORACLE@