/*
OBJECTIVE
  - Info on Database
  - Get count(object) by type
HISTORY
  - 2014-03-11 : CoPrime (DMA) - Init
  - 2014-02-24 : CoPrime (DMA) - SQL Server Compatibility and Split Query
BUSINESS RULES
  - user_objects : Oracle User View
  - sys.objects  : SQL Server Objects
  - sys.objects.schema_id = schema_id() : SQL Server Objects for current schema
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
         '29' as "order",
         'Oracle' as "name",
         'Count Oracle Objects by Type' as "description",
         'Type' as "th1",
         'Count' as "th2"),
       xmlagg(xmlelement(name "Record", xmlforest("type", "count"))))
       .getclobval()
from (

select o.object_type as "type",
       count(*) as "count"
  from user_objects o
 group by o.object_type
 order by o.object_type

):ORACLE@

@SQLSERVER:
select '29' as "@order",
       'SQL Server' as "@name",
       'Count SQL Server Objects by Type' as "@description",
       'Type' as "@th1",
       'Count' as "@th2",   
       (select t.type as "type",
               t.count as "count"
          from (

select o.type_desc as "type",
       count(*) as "count"
  from sys.objects o
 where o.schema_id = schema_id()
 group by o.type_desc

) t order by t."type"
for xml path('Record'), type)  for xml path('QueryResult')
:SQLSERVER@
