/*
OBJECTIVE
  - Detect Tables with no primary or foreign key (null value)
HISTORY
  - 2015-07-01 : CoPrime (DMA) - Init for Table
  - 2015-07-15 : CoPrime (DMA) - Update Script, Control on all Tables for SQL Server, prcalendar for Oracle
  - 2015-07-28 : CoPrime (DMA) - Foreign key prprojectid, prresourceid, prtimeperiodid
  - 2015-08-06 : CoPrime (DMA) - Column in Result
  - 2016-07-30 : CoPrime (DMA) - PRTASK.PRPROJECTID as WARN
BUSINESS RULES
  - Error when installing PMO Accelerator (admin content csk) if prtimeentry.prid is null
  - Error on Calendar Upgrade (14.1) if prcalendar.prid is null (select top 1000 prid, prvalue from prcalendar where sqlcurve is null never ends)
  - prtask.prprojectid may be null (ignore table prchargecode)
  - prcalendar.prresource may be null for Base Calendars (ignore table prcalendar)
DEBUG
  <statementRef id="union.dynamicSQL" inputSource="map" sortColumnPath="/data/header/sortInfo/@sortColumn" sortDirectionPa
  th="/data/header/sortInfo/@sortDirection" slicePath="/data/header/pagination/sliceInfo/@slice" sliceSizePath="/data/head
  er/pagination/sliceInfo/@sliceSize" xmlns="http://schemas.niku.com/2002/pmd"/>
  Using input:
  {dynamic=insert into ODF_CA_TIMEENTRY (id, created_date, created_by,last_updated_date, last_updated_by) select prtimeent
  ry.prid odf_pk ,getdate(), 1, getdate(), 1 from prtimeentry where not exists (select 'row exists' from odf_ca_timeentry
  where id = prtimeentry.prid)}
  Using dynamic SQL:
  tag: @dynamic@ SQL:insert into ODF_CA_TIMEENTRY (id, created_date, created_by,last_updated_date, last_updated_by) select
  prtimeentry.prid odf_pk ,getdate(), 1, getdate(), 1 from prtimeentry where not exists (select 'row exists' from odf_ca_
  timeentry where id = prtimeentry.prid)
          at com.niku.union.persistence.PersistenceController.createException(PersistenceController.java:2084)
          at com.niku.union.persistence.PersistenceController.handleSQLException(PersistenceController.java:2188)
          at com.niku.union.persistence.PersistenceController.processSql(PersistenceController.java:2818)
          at com.niku.union.persistence.PersistenceController.processStatement(PersistenceController.java:867)
          at com.niku.union.persistence.PersistenceController.processStatements(PersistenceController.java:767)
          at com.niku.union.persistence.PersistenceController.doProcessRequest(PersistenceController.java:575)
          at com.niku.union.persistence.PersistenceController.processRequest(PersistenceController.java:305)
          at com.niku.odf.object.Utils.executeDynamicPMDQuery(Utils.java:2405)
          at com.niku.odf.object.Utils.populateODF_CA_Table(Utils.java:2183)
          at com.niku.odf.object.Bootstrap.createCustomAttributeTables(Bootstrap.java:737)
          at com.niku.odf.object.Bootstrap.main(Bootstrap.java:1286)
          at com.niku.odf.object.Bootstrap.main(Bootstrap.java:1079)
          at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
          at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:57)
          at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
          at java.lang.reflect.Method.invoke(Method.java:606)
          at com.niku.nsa.service.AdminManager.runExecutable(AdminManager.java:1962)
          at com.niku.nsa.service.AdminManager.processXOGDriver(AdminManager.java:1873)
          at com.niku.nsa.service.AdminManager.installContent(AdminManager.java:1669)
          at com.niku.nsa.service.AdminManager.doContentDeploy(AdminManager.java:965)
          at com.niku.nsa.service.AdminManager.invokeAction(AdminManager.java:312)
          at com.niku.nsa.service.AdminManager.execute(AdminManager.java:187)
          at com.niku.nsa.service.Admin.main(Admin.java:77)
          at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
          at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:57)
          at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
          at java.lang.reflect.Method.invoke(Method.java:606)
          at com.werken.forehead.Forehead.run(Forehead.java:551)
          at com.werken.forehead.Forehead.main(Forehead.java:581)
  Caused by: java.sql.SQLIntegrityConstraintViolationException: [CA Clarity][SQLServer JDBC Driver][SQLServer]Cannot inser
  t the value NULL into column 'id', table 'CLARITY.niku.ODF_CA_TIMEENTRY'; column does not allow nulls. INSERT fails.
STAND BY
  - Oracle : Do the same for all tables
TESTED ON
  - Oracle 11.2
  - SQL Server 2008R2
  - Clarity 12.x, 13.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
       xmlattributes(
       '25' as "order",
       'Oracle' as "name",
       'Table records with primary or foreign key null' as "description",
       'Delete row' as "action",
       'Table' as "th1",
       'Columns' as "th2",
       'Count' as "th3",
       'Flag' as "th4",
       'Script' as "th5"),
       xmlagg(xmlelement(name "Record", xmlforest("name", "column", "count", "flag", "script"))))
       .getclobval()
from (

select t.*
  from (select 'PRTIMEENTRY' as "name",
               'PRID' as "column",
               count(*) as "count",
               'NOK' as "flag",
               'begin\n\tdbms_output.put_line(''Deleting records with no primary key in prtimeentry.'');\n\tdelete from prtimeentry where prid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;' as "script"
          from prtimeentry e
         where e.prid is null
        union all
        select 'PRTIMESHEET',
               'PRRESOURCEID',
               count(*),
               'NOK',
               'begin\n\tdbms_output.put_line(''Deleting records with no foreign key prresourceid in prtimesheet.'');\n\tdelete from prtimesheet where prresourceid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;'
          from prtimesheet t
         where t.prresourceid is null
        union all
        select 'PRTIMESHEET',
               'PRTIMEPERIODID',
               count(*),
               'NOK',
               'begin\n\tdbms_output.put_line(''Deleting records with no foreign key prtimeperiodid in prtimesheet.'');\n\tdelete from prtimesheet where prtimeperiodid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;' as "script"
          from prtimesheet t
         where t.prtimeperiodid is null
        union all
        select 'PRCALENDAR',
               'PRID',
               count(*),
               'NOK',
               'begin\n\tdbms_output.put_line(''Deleting records with no primary key in prcalendar.'');\n\tdelete from prcalendar where prid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;'
          from prcalendar c
         where c.prid is null
        union all
        select 'PRTASK',
               'PRPROJECTID',
               count(*),
               'WARN',
               'begin\n\tdbms_output.put_line(''Deleting records with foreign key prprojectid null in prtask.'');\n\tdelete from prtask where prprojectid is null;\n\tdbms_output.put_line(sql%rowcount || '' delete(s) done.'');\n\tcommit;\nend;'
          from prtask t
         where t.prprojectid is null
         ) t
 where t."count" > 0

)
:ORACLE@

@SQLSERVER:
set nocount on;
declare @tmp table (name varchar(100), col varchar(100), count integer);
declare @my_table varchar(100);
declare @my_column varchar(100);
declare @my_sql varchar(500);
declare v_tables cursor for
select t.table_name, c.column_name
  from information_schema.tables  t,
       information_schema.columns c
 where t.table_name = c.table_name
   and (c.column_name in ('prid', 'id', 'prtimeperiodid')
    or (c.column_name = 'prprojectid' and not c.table_name = 'PRCHARGECODE')
    or (c.column_name = 'prresourceid' and not c.table_name = 'PRCALENDAR'))
   and not t.table_type = 'VIEW'
 order by t.table_name;

--Open Cursor
open v_tables
fetch next from v_tables
into @my_table, @my_column

--Parse Cursor
while @@FETCH_STATUS = 0
begin
  set @my_sql = 'select ''' + @my_table + ''', ''' + @my_column + ''', count(*) from ' + @my_table + ' where ' + @my_column + ' is null';
  insert @tmp
  exec (@my_sql)
  fetch next from v_tables into @my_table, @my_column;
end

--Close Cursor
close v_tables;
deallocate v_tables;

select '25' as "@order",
       'SQL Server' as "@name",
       'Table records with primary or foreign key null' as "@description",
       'Delete row' as "@action",
       'Table' as "@th1",
       'Column' as "@th2",
       'Count' as "@th3",
       'Flag' as "@th4",
       'Script' as "@th5",
       (select t.*
          from (

select *,
       'NOK' as "flag",
       'begin\n\tprint ''Deleting records with primary or foreign key ' + col + ' null in ' + name + '.'';\n\tdelete from ' + name + ' where ' + col + ' is null;\n\tprint cast(@@rowcount as varchar) + '' delete(s) done.'';\nend;' as "script"
  from @tmp
 where count > 0
         
) t
for xml path('Record'), type)
for xml path('QueryResult')
:SQLSERVER@