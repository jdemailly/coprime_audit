/*
OBJECTIVE
  - Configuration Prerequisites for Oracle and SQL Server
  - See CA document CAClarityPPM_InstallationGuide_ENU.pdf
HISTORY
  - 2014-02-14 : CoPrime (DMA) - Init
  - 2014-03-06 : CoPrime (DMA) - CREATE PROCEDURE Prerequisite for 13.2+
  - 2014-03-20 : CoPrime (DMA) - Script Debug
  - 2015-06-22 : CoPrime (DMA) - SQL Server, Database Properties Oracle, Test on Version
  - 2016-06-01 : CoPrime (DMA) - Oracle v12, Change Flag on Privilege and Role
  - 2016-06-24 : CoPrime (DMA) - Statistics, System Parameters
  - 2016-07-06 : CoPrime (DMA) - Script System
BUSINESS RULES
  - Clarity version is calculated from cmn_install_history
  - Use of function dbms_utility.get_parameter_value
  - ORACLE only :
    / Database National Character Set must be UTF8/AL16UTF16
    / Database Character Set must be UTF8 until 12.1
    / Database Character Set must be AL32UTF8 since 13.0
    / Instance Database Parameter NLS_SORT must be BINARY
    / Instance Database Parameter NLS_COMP must be BINARY
    / Instance Database Parameter NLS_DATE_FORMAT must be YYYY-MM-DD HH24:MI:SS
    / User must have privilege ALTER SESSION since 13.0
    / User must have privilege CREATE SESSION
    / User must have privilege CREATE JOB since 14.2
    / User must have privilege CREATE TABLE
    / User must have privilege CREATE PROCEDURE since 13.2
    / User must have privilege CREATE TRIGGER
    / User must have privilege CREATE VIEW
    / User must have privilege QUERY REWRITE
    / User must have privilege UNLIMITED TABLESPACE
    / User must have role CONNECT
    / User must have role RESOURCE
    / Statistics must be Gathered
    / Parameter QUERY_REWRITE_ENABLED Set to true
    / Parameter CURSOR_SHARING Set to FORCE
    / Parameter _B_TREE_BITMAP_PLANS Set to false
    / Parameter OPTIMIZER_MODE Set to ALL_ROWS
  - SQL SERVER only :
    / Database Collation must be set to SQL_Latin1_General_CP1_CI_AS
    / Database property ARITHABORT must be set to ON
    / Database property ANSI_NULLS must be set to ON
    / Database property QUOTED_IDENTIFIER must be set to ON
    / Database property COMPATIBILITY_LEVEL must be 100
    / Database property is_read_committed_snapshot_on must be set to ON
    / Database login must have permission VIEW SERVER STATE
TESTED ON
  - Oracle 11.x
  - SQL Server 2008R2, 2012
  - Clarity 12.x, 13.x
*/

@ORACLE:
select xmlelement(name "QueryResult",
      xmlattributes(
        '21' as "order",
        'Oracle' as "name",
        'Oracle Prerequisites for Clarity' as "description",
        'Check each NOK prerequisite and apply given SQL script' as "action",
        'Rule' as "th1",
        'Flag' as "th2",
        'Script' as "th3"),
      xmlagg(xmlelement(name "Record", xmlforest("rule", "flag", "script"))))
       .getclobval()
from (

with

--Clarity Version on 3 Digits
version as
 (select to_number(substr(replace(installed_version, '.', ''), 1, 3)) as version
    from (select installed_version
            from cmn_install_history
           where install_id in ('database', 'release_version')
           order by installed_date desc)
   where rownum = 1)
  
--Database Character Set must be UTF8 12.1-
select 'Database Character Set must be UTF8 until 12.1' || decode(p.value, 'UTF8', '', ' (Actual = ' || p.value || ')') as "rule",
       decode(p.value, 'UTF8', 'OK', 'WARN') as "flag",
       'Reinstall Oracle Instance' as "script"
  from version v,
       nls_database_parameters p
 where p.parameter = 'NLS_CHARACTERSET'
   and v.version < 130

--Database Character Set must be AL32UTF8 13.0+
union all
select 'Database Character Set must be AL32UTF8 since 13.0' || decode(p.value, 'AL32UTF8', '', ' (Actual = ' || p.value || ')') as "rule",
       decode(p.value, 'AL32UTF8', 'OK', 'WARN') as "flag",
       'Reinstall Oracle Instance' as "script"
  from version v,
       nls_database_parameters p
 where p.parameter = 'NLS_CHARACTERSET'
   and v.version >= 130
  
--Database National Character Set must be UTF8/AL16UTF16
union all
select 'Database National Character Set must be UTF8/AL16UTF16' || decode(p.value, 'UTF8', '', 'AL16UTF16', '', ' (Actual = ' || p.value || ')'),
       decode(p.value, 'UTF8', 'OK', 'AL16UTF16', 'OK', 'WARN'),
       'Reinstall Oracle Instance'
  from nls_database_parameters p
 where p.parameter = 'NLS_NCHAR_CHARACTERSET'

--Instance Database Parameter NLS_SORT must be BINARY
union all
select 'Instance Database Parameter NLS_SORT must be BINARY' || decode(upper(p.value), 'BINARY', '', ' (Actual = ' || p.value || ')'),
       decode(upper(p.value), 'BINARY', 'OK', 'NOK'),
       'alter system set nls_sort = binary scope = spfile;'
  from nls_instance_parameters p
 where p.parameter = 'NLS_SORT'

--Instance Database Parameter NLS_COMP must be BINARY
union all
select 'Instance Database Parameter NLS_COMP must be BINARY' || decode(upper(p.value), 'BINARY', '', ' (Actual = ' || p.value || ')'),
       decode(upper(p.value), 'BINARY', 'OK', 'NOK'),
       'alter system set nls_comp = binary scope = spfile;'
  from nls_instance_parameters p
 where p.parameter = 'NLS_COMP'

--Instance Database Parameter NLS_DATE_FORMAT must be YYYY-MM-DD HH24:MI:SS
union all
select 'Instance Database Parameter NLS_DATE_FORMAT must be ''YYYY-MM-DD HH24:MI:SS''' || decode(p.value, 'YYYY-MM-DD HH24:MI:SS', '', ' (Actual = ' || p.value || ')'),
       decode(p.value, 'YYYY-MM-DD HH24:MI:SS', 'OK', 'NOK'),
       'alter system set nls_date_format = ''YYYY-MM-DD HH24:MI:SS'' scope = spfile;'
  from nls_instance_parameters p
 where p.parameter = 'NLS_DATE_FORMAT'

--User must have privilege ALTER SESSION since 13.0
union all
select 'User ' || user || ' must have privilege ALTER SESSION since 13.0',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'ALTER SESSION') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'ALTER SESSION') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 130 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant alter session to ' || user || ';'
  from version v
 
--User must have privilege CREATE SESSION
union all
select 'User ' || user || ' must have privilege CREATE SESSION',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE SESSION') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE SESSION') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 130 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant create session to ' || user || ';'
  from version v
 
--User must have privilege CREATE TABLE
union all
select 'User ' || user || ' must have privilege CREATE TABLE',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE TABLE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE TABLE') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant create table to ' || user || ';'
  from dual
 
--User must have privilege CREATE PROCEDURE since 13.2
union all
select 'User ' || user || ' must have privilege CREATE PROCEDURE since 13.2',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE PROCEDURE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE PROCEDURE') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 132 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant create procedure to ' || user || ';'
  from version v
 
--User must have privilege CREATE JOB since 14.2
union all
select 'User ' || user || ' must have privilege CREATE JOB since 14.2',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE JOB') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE JOB') > 0 then
          'OK'
         else
         --Not Granted
          (case
            when v.version < 142 then
             'WARN'
            else
             'NOK'
          end)
       end,
       'grant create job to ' || user || ';'
  from version v
 
--User must have privilege CREATE TRIGGER
union all
select 'User ' || user || ' must have privilege CREATE TRIGGER',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE TRIGGER') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE TRIGGER') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant create trigger to ' || user || ';'
  from dual

--User must have privilege CREATE VIEW
union all
select 'User ' || user || ' must have privilege CREATE VIEW',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'CREATE VIEW') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'CREATE VIEW') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant create view to ' || user || ';'
  from dual

--User must have privilege QUERY REWRITE
union all
select 'User ' || user || ' must have privilege QUERY REWRITE',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'QUERY REWRITE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'QUERY REWRITE') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant query rewrite to ' || user || ';'
  from dual

--User must have privilege UNLIMITED TABLESPACE
union all
select 'User ' || user || ' must have privilege UNLIMITED TABLESPACE',
       case
       --Granted on User : OK
         when (select count(*) from user_sys_privs where privilege = 'UNLIMITED TABLESPACE') > 0 then
          'OK'
       --Granted through Role : OK
         when (select count(*)
                 from user_role_privs ro
                inner join role_sys_privs r on r.role = ro.granted_role
                where r.privilege = 'UNLIMITED TABLESPACE') > 0 then
          'OK'
       --Not Granted
         else
          'NOK'
       end,
       'grant unlimited tablespace to ' || user || ';'
  from dual

--User must have role CONNECT
union all
select 'User ' || user || ' must have role CONNECT',
       decode(count(*), 1, 'OK', 'NOK'),
       'grant connect to ' || user || ';'
  from user_role_privs r
 where r.granted_role = 'CONNECT'

--User must have role RESOURCE
union all
select 'User ' || user || ' must have role RESOURCE',
       decode(count(*), 1, 'OK', 'NOK'),
       'grant resource to ' || user || ';'
  from user_role_privs r
 where r.granted_role = 'RESOURCE'

--Statistics must be Gathered if older than 15 days
union all
select 'Statistics must be Gathered if older than 15 days',
       case
         when trunc(sysdate) - 15 > trunc(min(last_analyzed)) then
          'NOK'
         else
          'OK'
       end,
       'begin\n\tcmn_job_analyze_sp(p_job_run_id => 1, p_job_user_id => 1, p_db_schema => user);\nend;'
  from (select min(t.last_analyzed) as last_analyzed
          from user_tables t
        union all
        select min(last_analyzed)
          from user_tab_partitions
        union all
        select min(last_analyzed)
          from user_tab_subpartitions
        union all
        select min(last_analyzed)
          from user_indexes
        union all
        select min(last_analyzed)
          from user_ind_partitions
        union all
        select min(last_analyzed)
          from user_ind_subpartitions)

--Parameter QUERY_REWRITE_ENABLED must be Set to True
union all
select 'Parameter QUERY_REWRITE_ENABLED must be Set to True',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''QUERY_REWRITE_ENABLED'', i, s);\n
  dbms_output.put_line(''QUERY_REWRITE_ENABLED : '' || s);\n
end;\n
\n
alter system set query_rewrite_enabled = true scope = spfile;'
  from dual

--Parameter CURSOR_SHARING must be Set to FORCE
union all
select 'Parameter CURSOR_SHARING must be Set to FORCE',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''CURSOR_SHARING'', i, s);\n
  dbms_output.put_line(''CURSOR_SHARING : '' || s);\n
end;\n
\n
alter system set cursor_sharing = FORCE scope = spfile;'
  from dual

--Parameter _B_TREE_BITMAP_PLANS must be Set to False
union all
select 'Parameter _B_TREE_BITMAP_PLANS must be Set to False',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''_B_TREE_BITMAP_PLANS'', i, s);\n
  dbms_output.put_line(''_B_TREE_BITMAP_PLANS : '' || i);\n
end;\n
\n
alter system set "_b_tree_bitmap_plans" = false scope = spfile;'
  from dual

--Parameter OPTIMIZER_MODE must be Set to ALL_ROWS
union all
select 'Parameter OPTIMIZER_MODE must be Set to ALL_ROWS',
       'WARN',
       'declare\n
  i binary_integer;\n
  o binary_integer;\n
  s varchar2(256);\n
begin\n
  o := dbms_utility.get_parameter_value(''OPTIMIZER_MODE'', i, s);\n
  dbms_output.put_line(''OPTIMIZER_MODE : '' || s);\n
end;\n
\n
alter system set optimizer_mode = ALL_ROWS scope = spfile;'
  from dual
         
):ORACLE@

@SQLSERVER:
with version as (
  select left(convert(varchar, serverproperty('productversion')), charindex('.', convert(varchar, serverproperty('productversion'))) - 1) as version)
select '21' as "@order",
       'SQL Server' as "@name",
       'SQL Server Prerequisites for Clarity' as "@description",
       'Check each NOK prerequisite and apply given SQL script' as "@action",
       'Rule' as "@th1",
       'Flag' as "@th2",
       'Script' as "@th3",
       (select t.*
          from (

--Database property COLLATION must be set to SQL_Latin1_General_CP1_CI_AS
select 'Database collation must be set to SQL_Latin1_General_CP1_CI_AS' as "rule",
       case
         when convert(varchar, serverproperty('collation')) = 'SQL_Latin1_General_CP1_CI_AS' then
          'OK'
         else
          'NOK'
       end as "flag",
       'Reinstall SQL Server Instance' as "script"
union all
--Database property ARITHABORT must be set to ON
select 'Database property ARITHABORT must be set to ON' as "rule",
       case
         when d.is_arithabort_on = 1 then
          'OK'
         else
          'NOK'
       end as "flag",
       'USE MASTER\ngo\nALTER DATABASE ' + db_name() + '\nSET ARITHABORT ON\ngo' as "script"
  from sys.databases d
 where d.database_id = db_id()
--Database property ANSI_NULLS must be set to ON
union all
select 'Database property ANSI_NULLS must be set to ON',
       case
         when d.is_ansi_nulls_on = 1 then
          'OK'
         else
          'NOK'
       end,
       'USE MASTER\ngo\nALTER DATABASE ' + db_name() + '\nSET ANSI_NULLS ON\ngo'
  from sys.databases d
 where d.database_id = db_id()
--Database property QUOTED_IDENTIFIER must be set to ON
union all
select 'Database property QUOTED_IDENTIFIER must be set to ON',
       case
         when d.is_quoted_identifier_on = 1 then
          'OK'
         else
          'NOK'
       end,
       'USE MASTER\ngo\nALTER DATABASE ' + db_name() + '\nSET QUOTED_IDENTIFIER ON\ngo'
  from sys.databases d
 where d.database_id = db_id()
--Database property COMPATIBILITY_LEVEL must be 100
union all
select 'Database property COMPATIBILITY_LEVEL must be ' + (select version + '0' from version),
       case
         when d.compatibility_level = (select version + '0' from version) then
          'OK'
         else
          'NOK'
       end,
       'USE MASTER\ngo\nEXEC SP_DBCMPTLEVEL ' + db_name() + ', ' + (select version + '0' from version) + '\ngo'
  from sys.databases d
 where d.database_id = db_id()
--Database property is_read_committed_snapshot_on must be set to ON
union all
select 'Database property is_read_committed_snapshot_on must be set to ON',
       case
         when d.is_read_committed_snapshot_on = 1 then
          'OK'
         else
          'NOK'
       end,
       'USE MASTER\ngo\nALTER DATABASE ' + db_name() + '\nSET READ_COMMITTED_SNAPSHOT ON\ngo'
  from sys.databases d
 where d.database_id = db_id()
--Database login must have permission VIEW SERVER STATE
union all
select 'Database login ' + original_login() + ' must have permission VIEW SERVER STATE',
       case
         when count(*) = 1 then
          'OK'
         else
          'NOK'
       end,
       'USE MASTER\ngo\nGRANT VIEW SERVER STATE to ' + db_name() + '\ngo'      
  from sys.server_permissions p
 where p.class_desc = 'SERVER'
   and p.permission_name = 'VIEW SERVER STATE'
) t
for xml path('Record'), type) for xml path('QueryResult')
:SQLSERVER@
