/*
OBJECTIVE
  - Version : Set Package Version in Clarity
HISTORY
  - 2018-02-28 : CoPrime (DMA) - Init
  - 2019-01-31 : CoPrime (DMA) - Exception
BUSINESS RULES
  - See Function XTD_COMMON.param_imp for Oracle
  - See Parameter P_VERSION_MAIN
TESTED ON
  - Oracle 11.2, 12.1
  - Clarity 13.x, 14.x, 15.x
*/
@ORACLE:
begin
  execute immediate 'begin
  xtd_common.param_imp(p_configuration_code => ''MAIN'',
                       p_code               => ''version'',
                       p_name               => ''Current Version'',
                       p_description        => ''Current Main and Minor Version'',
                       p_string1            => ''@P_VERSION_MAIN@'',
                       p_date1              => sysdate);
end;';
exception
  when others then
    null;
end;
:ORACLE@