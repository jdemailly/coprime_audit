
                /*
OBJECTIVE
  - Get DB Version for Oracle and SQL Server
HISTORY
  - 2014-09-17 : CoPrime (DMA) - Init
  - 2015-06-11 : CoPrime (DMA) - Change to view nls_database_parameters
  - 2015-06-19 : CoPrime (DMA) - Get SQL Server Version
BUSINESS RULES
  - Oracle     : Use of standard view nls_database_parameters NLS_RDBMS_VERSION
  - SQL Server : Use of function serverproperty('productversion') to get version and serverproperty('productlevel') to get Service Pack
STAND BY
  - select * from v$version where rownum = 1
TESTED ON
  - Oracle 11.2
  - SQL Server 2012
*/

select value from nls_database_parameters where parameter = 'NLS_RDBMS_VERSION'



              