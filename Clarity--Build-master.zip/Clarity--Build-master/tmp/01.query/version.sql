
                /*
OBJECTIVE
  - Get Clarity Version
HISTORY
  - 2014-03-31 : CoPrime (DMA) - Init
BUSINESS RULES
  - cmn_install_history.install_id in ('database', 'contentPack::clarityContent', 'release_version') : Installation History
  - Select first one order by cmn_install_history.installed_date desc
TESTED ON
  - Clarity v12.x, v13.x
  - SQL Server 2008R2, Oracle 11.2  
*/

select installed_version
  from (select h.installed_version
          from cmn_install_history h
         where h.install_id in ('database', 'contentPack::clarityContent', 'release_version')
         order by h.installed_date desc)
 where rownum = 1


              