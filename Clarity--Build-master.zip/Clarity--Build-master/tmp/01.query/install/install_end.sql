/*
OBJECTIVE
  - Installation : End
HISTORY
  - 2014-02-19 : CoPrime (DMA) - Move to Configuration File
  - 2015-09-16 : CoPrime (DMA) - Package XTD_SUPPORT
  - 2017-02-08 : CoPrime (DMA) - Review Package Validity
  - 2018-02-01 : CoPrime (DMA) - Review Test
  - 2018-03-29 : CoPrime (DMA) - Common Package
  - 2018-10-10 : CoPrime (DMA) - Warning, Error Total
BUSINESS RULES
  - Stores Date in Configuration Object
  - See Function XTD_SUPPORT.install_start for Oracle
  - Use of tags :
    / P_VERSION to Write Current Package Version
    / P_WARNING_TOTAL to Write Number of Warnings
    / P_ERROR_TOTAL to Write Number of Errors
TESTED ON
  - Oracle 11.2, 12.1
  - Clarity 13.x, 14.x, 15.x
*/
@ORACLE:
begin
  execute immediate 'begin
  xtd_support.install_end(p_version       => ''@P_VERSION@'',
                          p_warning_total => @P_WARNING_TOTAL@,
                          p_error_total   => @P_ERROR_TOTAL@);
end;';
exception
  when others then
    null;
end;
:ORACLE@