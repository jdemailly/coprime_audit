/*
OBJECTIVE
  - Installation : End with Error
HISTORY
  - 2014-02-19 : CoPrime (DMA) - Move to Configuration File
  - 2017-02-08 : CoPrime (DMA) - Review Package Validity
  - 2018-02-01 : CoPrime (DMA) - Review Test
  - 2018-03-29 : CoPrime (DMA) - Common Package
  - 2018-10-16 : CoPrime (DMA) - Execute Immediate
BUSINESS RULES
  - Stores date in configuration object
  - Use of tag P_VERSION to write current package version
  - See function XTD_SUPPORT.install_end for Oracle
  - Use of tags P_MESSAGE and P_STACK to catch variables content
TESTED ON
  - Oracle 11.2, 12.1
  - Clarity 13.x, 14.x, 15.x
*/
@ORACLE:
begin
  execute immediate 'begin
  xtd_support.install_end(p_version => ''@P_VERSION@'',
                          p_error   => ''@P_MESSAGE@'',
                          p_stack   => ''@P_STACK@'');
end;';
exception
  when others then
    null;
end;
:ORACLE@