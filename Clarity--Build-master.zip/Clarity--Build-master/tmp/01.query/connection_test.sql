
                /*
OBJECTIVE
  - Test connection in SQL Server and Oracle
HISTORY
  - 2014-02-19 : CoPrime (DMA) - Move to Configuration File
BUSINESS RULES
  - Oracle     : Use of select 1 from dual
  - SQL Server : Use of select 1
TESTED ON
  - Oracle v11, SQL Server 2008R2  
*/
select 1 from dual
              