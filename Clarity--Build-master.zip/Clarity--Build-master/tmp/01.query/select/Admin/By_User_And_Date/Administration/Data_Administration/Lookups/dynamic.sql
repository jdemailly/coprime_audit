/*
OBJECTIVE
  - Lookup : Dynamic (Administration > Data Administration > Lookups)
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2014-11-26 : CoPrime (DMA) - Remove Criteria on is_system
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-04-06 : CoPrime (DMA) - Ignore System 2
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2016-12-21 : CoPrime (DMA) - Admin Visible
  - 2017-01-25 : CoPrime (DMA) - Lookup OBJECT_LOOKUP
  - 2017-02-03 : CoPrime (DMA) - Caption
BUSINESS RULES
  - cmn_list_of_values.lookup_source_code = 'LOOKUP_SOURCE_DYNAMIC' : Dynamic Lookup only
  - not cmn_lookup_types.is_system = 2                              : Ignore System Level 2
  - cmn_lookup_types.is_admin_visible = 1                           : Admin Visible Only
  - cmn_lookup_types.lookup_type like 'OBJECT_LOOKUP_%'             : Lookup Linked to Object
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@
 
--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'lookup_dynamic' as "type",
       l.lookup_type as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUP_TYPES'
           and n.language_code = p.p_language) as "name",
       (select r.full_name from srm_resources r where r.user_id = l.last_updated_by) as "last_updated_by",
       l.last_updated_date as "last_updated_date"
  from param p
 inner join cmn_lookup_types l on 1 = 1
 inner join cmn_list_of_values v on v.lookup_type_code = l.lookup_type
 where v.lookup_source_code = 'LOOKUP_SOURCE_DYNAMIC' --Dynamic Only
   and not l.is_system = 2 --Ignore System Level 2
   and l.is_admin_visible = 1 --Admin Visible Only
   and (l.lookup_type not like 'OBJECT_LOOKUP_%' or (l.lookup_type like 'OBJECT_LOOKUP_%' and l.last_updated_date > (l.created_date + 1 / 24))) --Ignore OBJECT_LOOKUP if not Updated After Creation
   and ( --Modified by User Since Last Date
        (l.last_updated_date >= p.p_date and l.last_updated_by = p.p_user) or
        (v.last_updated_date >= p.p_date and v.last_updated_by = p.p_user) or
       --At Least One Caption Modified by User Since Last Date
        (select max(n.last_updated_date)
           from cmn_captions_nls n
          inner join cmn_lookup_types l1 on n.pk_id = l1.id
                                        and n.table_name = 'CMN_LOOKUP_TYPES'
          where n.last_updated_by = p.p_user
            and l1.id = l.id) >= p.p_date)
 order by l.lookup_type

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@