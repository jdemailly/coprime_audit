/*
OBJECTIVE
  - Detect Transaction Classes : URI Administration > Finance > Setup [Classifications]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - transclass : Transaction Class Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'transaction_class' as "type",
       tc.transclass as "code",
       tc.shortdesc as "name",
       (select full_name from srm_resources where user_id = tc.last_updated_by) as "last_updated_by",
       tc.last_updated_date as "last_updated_date"
  from param p
 inner join transclass tc on tc.last_updated_date >= p.p_date
                         and tc.last_updated_by = p.p_user
 order by tc.transclass

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@