/*
OBJECTIVE
  - Lookup : Dependent (Administration > Data Administration > Lookups)
HISTORY
  - 2014-08-22 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2016-12-21 : CoPrime (DMA) - Admin Visible
BUSINESS RULES
  - nvl(cmn_list_of_values.parent_id, 0) = 0                          : Only Parent Lookup
  - cmn_list_of_values.lookup_source_code = 'LOOKUP_SOURCE_DEPENDENT' : Dependent Lookup only
  - cmn_lookup_types.is_admin_visible = 1                             : Admin Visible Only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 20008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'lookup_dependent' as "type",
       l.lookup_type as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUP_TYPES'
           and n.language_code = p.p_language) as "name",
       (select full_name from srm_resources where user_id = l.last_updated_by) as "last_updated_by",
       l.last_updated_date as "last_updated_date"
  from param p
 inner join cmn_lookup_types l on 1 = 1
 inner join cmn_list_of_values v on v.lookup_type_code = l.lookup_type
 where v.lookup_source_code = 'LOOKUP_SOURCE_DEPENDENT' --Dependent Only
   and @NVL@(v.parent_id, 0) = 0 --Ignore Childs
   and l.is_admin_visible = 1 --Admin Visible Only
   and (
       --Modified by User
        (l.last_updated_date >= p.p_date and l.last_updated_by = p.p_user) or
        (v.last_updated_date >= p.p_date and v.last_updated_by = p.p_user) or
       --At Least One Value Modified by User
        (select max(l1.last_updated_date)
           from cmn_lookups l1
          where l1.lookup_type = l.lookup_type
            and l1.last_updated_by = p.p_user) >= p.p_date)
 order by l.lookup_type

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@