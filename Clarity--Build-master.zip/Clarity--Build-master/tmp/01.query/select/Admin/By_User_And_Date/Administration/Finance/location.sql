/*
OBJECTIVE
  - Detect Locations : URI Administration > Finance > Setup [Locations]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2015-01-16 : CoPrime (DMA) - Only One Row
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - locations : Location Table
  - entity    : Entity Table
  - Locations are XOGged out from Entity
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user
    from dual)

--Select
select 'location' as "type",
       e.entity as "code",
       'Locations from entity' as "name"
  from param  p,
       entity e
 where exists (select 1
          from locations l
         where l.entity_id = e.id
           and l.last_updated_by = p.p_user
           and l.last_updated_date >= p.p_date)
 order by e.entity

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@
