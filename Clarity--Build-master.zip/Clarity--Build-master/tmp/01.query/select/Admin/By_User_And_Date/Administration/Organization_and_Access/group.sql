/*
OBJECTIVE
  - Detect Groups : URI Administration > Organization and Access > Groups
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2017-03-14 : CoPrime (DMA) - Global Right
  - 2018-10-01 : CoPrime (DMA) - Instance, OBS Right
BUSINESS RULES
  - cmn_sec_groups                           : Group Table
  - cmn_sec_groups.group_role_type = 'group' : Right Group only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'group' as "type",
       g.group_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = g.id
           and n.table_name = 'CMN_SEC_GROUPS'
           and n.language_code = p.p_language) as "name",
       (select r.full_name from srm_resources r where r.user_id = g.last_updated_by) as "last_updated_by",
       g.last_updated_date as "last_updated_date"
  from param p,
       cmn_sec_groups g
 where g.group_role_type = 'GROUP' --Of Type GROUP Only
   and g.is_system = 0 --Ignore System
   and g.is_active = 1 --Active Only
   and ( --Modified by User Since Last Date
       (g.last_updated_date >= p.p_date and g.last_updated_by = p.p_user) or
        --Instance Right Modified by User Since Last Date
       (select max(a.last_updated_date)
          from cmn_sec_assgnd_obj_perm a
         where a.principal_id = g.id
           and a.principal_type = 'GROUP'
           and a.last_updated_by = p.p_user) >= p.p_date or
        --OBS Right Modified by User Since Last Date
       (select max(last_updated_date)
          from cmn_sec_assgnd_right
         where principal_id = g.id
           and principal_type = 'GROUP'
           and last_updated_by = p.p_user) >= p.p_date or
        --Global Right Modified by User Since Last Date
       (select max(r.last_updated_date)
          from cmn_sec_groups r
         inner join cmn_sec_group_hierarchies h on h.group_id = r.id
         where r.is_active = 1
           and h.parent_group_id = g.id
           and r.last_updated_by = p.p_user) >= p.p_date
       )
 order by g.group_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@