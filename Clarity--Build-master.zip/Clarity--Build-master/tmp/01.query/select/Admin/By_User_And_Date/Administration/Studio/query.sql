/*
OBJECTIVE
  - Query : URI Administration > Studio > Queries
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2017-02-07 : CoPrime (DMA) - Attribute, Caption
BUSINESS RULES
  - cmn_gg_nsql_queries : Query Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'query' as "type",
       q.query_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = q.id
           and n.table_name = 'CMN_GG_NSQL_QUERIES'
           and n.language_code = p.p_language) as "name",
       (select full_name from srm_resources where user_id = q.last_updated_by) as "last_updated_by",
       q.last_updated_date as "last_updated_date"
  from param               p,
       cmn_gg_nsql_queries q
 where 1 = 1
   and ( --Query Modified by User
        (q.last_updated_date >= p.p_date and q.last_updated_by = p.p_user) or
       --At Least One Attribute Modified by User
        (select max(f.last_updated_date)
           from cmn_nsql_query_filters f
          inner join cmn_nsql_queries q1 on q1.id = f.cmn_nsql_queries_id
          where f.last_updated_by = p.p_user
            and q1.id = q.cmn_nsql_queries_id) >= p.p_date or
       --At Least One Caption Modified by User
        (select max(last_updated_date)
           from cmn_captions_nls
          where pk_id = q.id
            and table_name = 'CMN_GG_NSQL_QUERIES'
            and last_updated_by = p.p_user) >= p.p_date
        )
 order by q.query_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@