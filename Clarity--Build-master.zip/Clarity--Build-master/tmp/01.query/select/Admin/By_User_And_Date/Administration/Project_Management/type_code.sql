/*
OBJECTIVE
  - Detect Charge Codes : URI Administration > Project Management > Input Type Codes
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - prtypecode                            : Input Type Code Table
  - prtypecode.prexternalid != 'MIGRATED' : Ignore MIGRATED Input Type Code
  - prtypecode.prisopen = -1              : Active Input Type Code (be aware, open is -1)
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'type_code' as "type",
       t.prexternalid as "code",
       t.prname as "name",
       (select r.full_name from srm_resources r where r.user_id = t.prmodby) as "last_updated_by",
       t.prmodtime as "last_updated_date"
  from param p
 inner join prtypecode t on t.prmodtime >= p.p_date
                        and t.prmodby = p.p_user
 where t.prexternalid != 'MIGRATED' --Ignore Standard MIGRATED
   and t.prisopen = -1 --Ative Only
 order by t.prexternalid

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@