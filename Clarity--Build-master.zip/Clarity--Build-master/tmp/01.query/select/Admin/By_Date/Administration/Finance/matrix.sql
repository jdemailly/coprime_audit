/*
OBJECTIVE
  - Detect Matrixes : URI Administration > Finance > Manage Matrix
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - ppa_matrix               : Matrix Table
  - ppa_matrix.matrixkey = 1 : Ignore system Matrix
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'matrix' as "type",
       m.description as "code",
       m.comments as "name",
       (select full_name from srm_resources where user_id = m.last_updated_by) as "last_updated_by",
       m.last_updated_date as "last_updated_date"
  from param      p,
       ppa_matrix m
 where not m.matrixkey = 1 --Ignore Standard Matrix
   and ( --Modified
        m.last_updated_date >= p.p_date or
       --At Least One Value Modified
        (select max(v.last_updated_date) from ppa_matrixvalues v where v.matrixkey = m.matrixkey) >= p.p_date)
 order by m.description

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@