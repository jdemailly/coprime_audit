/*
OBJECTIVE
  - Detect Process Notifications : URI Administration > Data Administration > Processes [Notifications]
HISTORY
  - 2018-03-22 : CoPrime (DMA) - Init
  - 2018-07-05 : CoPrime (DMA) - SQL Server
BUSINESS RULES
  - bpm_def_processes         : Process Table
  - cmn_process_notifications : Process Notifications
TESTED ON
  - Clarity 12.x, 13.x, 14.x
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'process_notification' as "type",
       p.process_code @+@ '.' @+@ n.notification_code as "code",
       (select name
          from cmn_captions_nls
         where table_name = 'CMN_PROCESS_NOTIFICATIONS'
           and language_code = pa.p_language
           and pk_id = n.id) as "name",
       (select full_name from srm_resources where user_id = n.last_updated_by) as "last_updated_by",
       n.last_updated_date as "last_updated_date"
  from param pa
 inner join cmn_process_notifications n on 1 = 1
 inner join bpm_def_processes p on p.id = n.process_id
 where n.is_customized = 1
   and n.last_updated_date >= pa.p_date --Modified
 order by p.process_code @+@ '.' @+@ n.notification_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@