/*
OBJECTIVE
  - Detect Views : URI Administration > Studio > Views
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2017-11-20 : CoPrime (DMA) - View Unit, Partition
  - 2018-07-12 : CoPrime (DMA) - Action Menu
  - 2018-10-11 : CoPrime (DMA) - Object, Type, Code
BUSINESS RULES
  - odf_objects : Objects Table
  - Views are Exported with Name <Partition Code>.<Object Code>.<View Type>.<View Code>
TESTED ON
  - Clarity 12.x, 13.x, 14.x, 15.x
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

@ORACLE:
select "type",
       "code",
       "name",
       "last_updated_by",
       "last_updated_date"
from
(:ORACLE@
--Object
select 'view' as "type",
       o.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = o.id
           and n.table_name = 'ODF_OBJECTS'
           and n.language_code = p.p_language) as "name",
       (select full_name from srm_resources where user_id = o.last_updated_by) as "last_updated_by",
       o.last_updated_date as "last_updated_date"
  from param       p,
       odf_objects o
 where exists
 (select 1
          from odf_views v
         where v.object_code = o.code
           and v.is_customized = 1 --Customized
           and ( --Modified
                v.last_updated_date >= p.p_date or
               --At Least One Attribute in View Modified
                (select max(a.last_updated_date) from odf_view_attributes a where a.view_id = v.id) >= p.p_date or
               --At Least One Menu Item in View Modified
                (v.caption = 'General' and (select max(g.last_updated_date)
                                              from odf_view_action_groups g
                                             inner join odf_views v2 on v2.id = g.view_id
                                             where v2.object_code = v.object_code
                                               and v2.view_type = v.view_type) >= p.p_date) or
               --Menu Action Modified
                (select max(last_updated_date) from odf_view_actions where object_code = v.object_code) >= p.p_date))

--Object.Type
union all
select distinct 'view' as "type",
       case v.partition_code when 'NIKU.ROOT' then '' else v.partition_code @+@ '.' end @+@ v.object_code @+@ '.' @+@ v.view_type as "code",
       v.object_code @+@ '.' @+@ v.view_type as "name",
       ' ' as "last_updated_by",
       @NOW@ as "last_updated_date"
  from param     p,
       odf_views v
 where v.is_customized = 1 --Customized
   and v.object_code in (select code from odf_objects) --Object Related
   and not v.view_subtype = 'master' --Ignore Master
   and ( --Modified
        v.last_updated_date >= p.p_date or
       --At Least One Attribute in View Modified
        (select max(a.last_updated_date) from odf_view_attributes a where a.view_id = v.id) >= p.p_date or
       --At Least One Menu Item in View Modified
        (v.caption = 'General' and (select max(g.last_updated_date)
                                      from odf_view_action_groups g
                                     inner join odf_views v2 on v2.id = g.view_id
                                     where v2.object_code = v.object_code
                                       and v2.view_type = v.view_type) >= p.p_date) or
       --Menu Action Modified
        (select max(last_updated_date) from odf_view_actions where object_code = v.object_code) >= p.p_date)
        
--Object.Type.Code
union all
select 'view',
       case v.partition_code when 'NIKU.ROOT' then '' else v.partition_code @+@ '.' end @+@ v.object_code @+@ '.' @+@ v.view_type @+@ '.' @+@ v.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = v.id
           and n.table_name = 'ODF_VIEWS'
           and n.language_code = p.p_language),
       (select full_name from srm_resources where user_id = v.last_updated_by),
       v.last_updated_date
  from param     p,
       odf_views v
 where v.is_customized = 1 --Customized
   and v.object_code in (select code from odf_objects) --Object Related
   and not v.view_subtype = 'master' --Ignore Master
   and ( --Modified
        v.last_updated_date >= p.p_date or
       --At Least One Attribute in View Modified
        (select max(a.last_updated_date) from odf_view_attributes a where a.view_id = v.id) >= p.p_date or
       --At Least One Menu Item in View Modified
        (v.caption = 'General' and (select max(g.last_updated_date)
                                      from odf_view_action_groups g
                                     inner join odf_views v2 on v2.id = g.view_id
                                     where v2.object_code = v.object_code
                                       and v2.view_type = v.view_type) >= p.p_date) or
       --Menu Action Modified
        (select max(last_updated_date) from odf_view_actions where object_code = v.object_code) >= p.p_date)
@ORACLE:)
order by "code"

):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@