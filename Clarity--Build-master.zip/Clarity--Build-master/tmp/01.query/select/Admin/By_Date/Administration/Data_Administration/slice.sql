/*
OBJECTIVE
  - Slices : URI Administration > Data Administration > Time Slices
HISTORY
  - 2017-10-17 : CoPrime (DMA) - Init
  - 2018-04-17 : CoPrime (DMA) - Ignore ::
  - 2018-07-05 : CoPrime (DMA) - SQL Server
BUSINESS RULES
  - prj_blb_slicerequests                            : Slice Request Table
  - prj_blb_slicerequests.is_template = 0            : Ignore Template
  - prj_blb_slicerequests.is_synchronous = 0         : Ignore Synchronous
  - prj_blb_slicerequests.request_name not like '::' : Ignore Two Dots
TESTED ON
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x, 15.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'slice' as "type",
       r.request_name as "code",
       r.request_name as "name",
       (select full_name from srm_resources where user_id = r.last_updated_by) as "last_updated_by",
       r.last_updated_date as "last_updated_date"
  from param p
 inner join prj_blb_slicerequests r on r.last_updated_date >= p.p_date
 where r.is_template = 0 --Ignore Template
   and r.is_synchronous = 0 --Ignore Synchronous
   and @INSTR@(r.request_name, '::') = 0 --Ignore ::
 order by r.request_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@