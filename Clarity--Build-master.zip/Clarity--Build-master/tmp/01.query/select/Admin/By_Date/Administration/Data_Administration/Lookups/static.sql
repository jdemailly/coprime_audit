/*
OBJECTIVE
  - Lookup : Static by Date (Administration > Data Administration > Lookups)
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-08-04 : CoPrime (DMA) - Caption
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2016-12-21 : CoPrime (DMA) - Admin Visible
  - 2017-01-25 : CoPrime (DMA) - Value Admin Visible, CMN_PAGE_INSTANCE_TYPE, CMN_ACTION_PARAM_TYPES
BUSINESS RULES
  - cmn_lookup_types.is_system = 0                                 : Ignore System Lookups
  - cmn_list_of_values.lookup_source_code = 'LOOKUP_SOURCE_STATIC' : Static Lookup only
  - cmn_lookup_types.is_admin_visible = 1                          : Admin Visible Only
  - cmn_lookups.is_admin_visible = 1                               : Value Admin Visible Only
  - cmn_lookups.lookup_type <> 'CMN_PAGE_INSTANCE_TYPE'            : Ignore CMN_PAGE_INSTANCE_TYPE
  - cmn_lookups.lookup_type <> 'CMN_ACTION_PARAM_TYPES'            : Ignore CMN_ACTION_PARAM_TYPES
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'lookup_static' as "type",
       l.lookup_type as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = l.id
           and n.table_name = 'CMN_LOOKUP_TYPES'
           and n.language_code = p.p_language) as "name",
       (select full_name from srm_resources where user_id = l.last_updated_by) as "last_updated_by",
       l.last_updated_date as "last_updated_date"
  from param p
 inner join cmn_lookup_types l on 1 = 1
 inner join cmn_list_of_values v on v.lookup_type_code = l.lookup_type
 where v.lookup_source_code = 'LOOKUP_SOURCE_STATIC' --Static Only
   and l.is_admin_visible = 1 --Admin Visible Only
   and l.lookup_type not in ('CMN_PAGE_INSTANCE_TYPE', 'CMN_ACTION_PARAM_TYPES') --Ignore CMN_PAGE_INSTANCE_TYPE, CMN_ACTION_PARAM_TYPES Lookup
   and ( --Modified
        l.last_updated_date >= p.p_date or
        v.last_updated_date >= p.p_date or
        --At Least One Value Modified
         (select max(v.last_updated_date)
            from cmn_lookups v
           where v.is_admin_visible = 1 --Admin Visible Only
             and v.lookup_type = l.lookup_type) >= p.p_date or
        --At Least One Caption Modified
         (select max(n.last_updated_date)
            from cmn_captions_nls n
           inner join cmn_lookups l1 on n.pk_id = l1.id
                                    and n.table_name = 'CMN_LOOKUPS'
           where l1.is_admin_visible = 1 --Admin Visible Only
             and l1.lookup_type = l.lookup_type) >= p.p_date)
 order by l.lookup_type

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@
