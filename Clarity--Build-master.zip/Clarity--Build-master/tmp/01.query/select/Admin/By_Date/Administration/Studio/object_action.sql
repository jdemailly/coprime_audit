/*
OBJECTIVE
  - Detect Objects : URI Administration > Studio > Objects
HISTORY
  - 2017-11-21 : CoPrime (DMA) - Init
  - 2018-07-12 : CoPrime (DMA) - Child Object
BUSINESS RULES
  - odf_objects : Objects Table
  - Select Actions Only
TESTED ON
  - Clarity 12.x, 13.x, 14.x, 15.x
  - Oracle 11.2
  - SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'object_action' as "type",
       o.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = o.id
           and n.table_name = 'ODF_OBJECTS'
           and n.language_code = p.p_language) as "name",
       (select full_name from srm_resources where user_id = o.last_updated_by) as "last_updated_by",
       o.last_updated_date as "last_updated_date"
  from param       p,
       odf_objects o
 where (select max(a.last_updated_date) from odf_actions a where a.object_code = o.code) >= p.p_date --At Least One Action Modified
 order by o.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@