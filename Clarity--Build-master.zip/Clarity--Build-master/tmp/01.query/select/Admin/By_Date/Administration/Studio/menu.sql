/*
OBJECTIVE
  - Menu : URI Administration > Studio > Menu Manager
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2017-03-28 : CoPrime (DMA) - Section
  - 2017-06-07 : CoPrime (DMA) - Review Date
  - 2019-05-07 : CoPrime (DMA) - Sub-Menu Modified
BUSINESS RULES
  - cmn_portlets                                                            : Administration Menus are stored in Portlets Table
  - cmn_portlets.portlet_code in ('union.adminLeftNav', 'union.appLeftNav') : Application and Administration Menu only
TESTED ON
  - Oracle 11.2, SQL Server 2008R2
  - Clarity 12.1, 13.x, 14.x, 15.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'menu' as "type",
       case p.portlet_code
         when 'union.adminLeftNav' then
          'admin'
         when 'union.appLeftNav' then
          'application'
       end @+@ '.' @+@ ma.action_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'CMN_PORTLETS'
           and n.language_code = pa.p_language) as "name",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from param        pa
 inner join cmn_portlets p on p.portlet_code in ('union.adminLeftNav', 'union.appLeftNav')
 --Section
 inner join cmn_menu_items m on m.container_id = p.id
                            and m.container_type_code = 'MENU'
                            and m.parent_menu_id is null
 inner join cmn_actions ma on ma.id = m.action_id
 where 1 = 1
   and ( --Modified
        p.last_updated_date >= pa.p_date or
       --Section Modified
        m.last_updated_date >= pa.p_date or
       --Action Modified
        ma.last_updated_date >= pa.p_date or
        --Sub-Menu Item
        exists (select 1 from cmn_menu_items where parent_menu_id = m.id and last_updated_date >= pa.p_date))
 order by p.portlet_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@