/*
OBJECTIVE
  - Detect Pages : URI Administration > Studio > Portlet Pages
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2014-08-25 : CoPrime (DMA) - Use Page Type
  - 2015-11-23 : CoPrime (DMA) - Remove Criteria on System Page Boolean
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2017-01-25 : CoPrime (DMA) - Page odf%Frame
  - 2017-03-21 : CoPrime (DMA) - SubPage Last Updated Date
  - 2017-04-04 : CoPrime (DMA) - Ignore User Page
  - 2017-07-06 : CoPrime (DMA) - SubPage
  - 2017-10-06 : CoPrime (DMA) - Review Customizable Condition
  - 2018-04-18 : CoPrime (DMA) - Odf Page
BUSINESS RULES
  - cmn_pages.page_type_code                     : Page Type (page, tabpage, etc.)
  - cmn_pages.page_type_code <> 'tab'            : Ignore Tab Pages (XOG only tabpage)
  - cmn_pages.page_type_code <> 'template'       : Ignore Template Pages
  - cmn_pages.page_type_code <> 'subtab'         : Ignore Subtab Pages
  - substr(lower(p.page_code), 1, 6) != 'system' : Ignore System Pages
  - cmn_pages.page_code like 'odf%Frame'         : Page Linked to Object
  - not cmn_pages.principal_type = 'USER'        : Ignore User Page
  - cmn_pages.is_customizable = 1                : Customizable
TESTED ON
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x, 15.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'page_' @+@ lower(p.page_type_code) as "type",
       p.page_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'CMN_PAGES'
           and n.language_code = pa.p_language) as "name",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from param pa,
       cmn_pages p
 where p.page_type_code not in ('tab', 'template', 'subtab') --Keep Master Tab Only
   and @SUBSTR@(lower(p.page_code), 1, 6) != 'system' --Ignore System
   and not p.principal_type = 'USER' --Ignore User Page
   and (p.page_code not like 'odf%Frame' or
       (p.page_code like 'odf%Frame' and
       (p.last_updated_date > (p.created_date + 1 / 24) or
       (select max(last_updated_date) from cmn_pages where parent_page_id = p.id) >= pa.p_date))) --Exclude odf Pages Linked to Objects if not Updated after Creation
   and (p.is_customizable = 1 or exists (select 1
                                           from cmn_pages sp
                                          where sp.parent_page_id = p.id
                                            and sp.is_customizable = 1)) --Customizable or At Least one Sub Page Customizable
   and (--Modified Since Last Date
       p.last_updated_date >= pa.p_date or
       --One SubPage Modified Since Last Date
       (select max(last_updated_date) from cmn_pages where parent_page_id = p.id) >= pa.p_date or
       --One Portlet on SubPage Modified Since Last Date by User
       (select max(pp.last_updated_date)
          from cmn_pages p1
         inner join cmn_page_portlets pp on pp.page_id = p1.id
         where p1.parent_page_id = p.id) >= pa.p_date
       )
 order by p.page_type_code,
          p.page_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@