/*
OBJECTIVE
  - Detect Partition Model : URI Administration > Studio > Partition Models
HISTORY
  - 2017-11-27 : CoPrime (DMA) - Init
BUSINESS RULES
  - cmn_partition_models : Partition Models
TESTED ON
  - Clarity 12.x, 13.x, 14.x, 15.x
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'partition' as "type",
       m.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = m.id
           and n.table_name = 'CMN_PARTITION_MODELS'
           and n.language_code = p.p_language) as "name",
       (select r.full_name from srm_resources r where r.user_id = m.last_updated_by) as "last_updated_by",
       m.last_updated_date as "last_updated_date"
  from param p
 inner join cmn_partition_models m on 1 = 1
 where --Modified Since Date
        m.last_updated_date >= p.p_date
 order by m.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@
