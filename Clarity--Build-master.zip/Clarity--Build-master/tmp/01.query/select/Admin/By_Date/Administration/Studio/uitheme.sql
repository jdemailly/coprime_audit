/*
OBJECTIVE
  - Detect UI Themes : URI Administration > Studio > UI Theme
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - cmn_ui_themes : UI Theme Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'uitheme' as "type",
       u.code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = u.id
           and n.table_name = 'CMN_UI_THEMES'
           and n.language_code = p.p_language) as "name",
       (select full_name from srm_resources where user_id = u.last_updated_by) as "last_updated_by",
       u.last_updated_date as "last_updated_date"
  from param p
 inner join cmn_ui_themes u on u.last_updated_date >= p.p_date
 order by u.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@