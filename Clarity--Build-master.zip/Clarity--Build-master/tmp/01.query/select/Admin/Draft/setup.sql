/*
Getting all custom objects instances
/QueryResult/Record/type
/QueryResult/Record/code
/QueryResult/Record/name
  <QueryResult>
    <Record>
        <type>department</type>
        <code>dummy</code>
        <name>Tous les d�partements</name>
        <last_updated_by>dummy</last_updated_by>
        <last_updated_date>2012-12-03</last_updated_date>
    </Record>
  </QueryResult>
*/
declare
  type my_refcur is ref cursor;
  my_cur    my_refcur;
  my_sql    varchar2(5000);
  my_date   date;
  my_format varchar2(10) := 'YYYY-MM-DD';
  cursor my_objects is
    select o.code from odf_objects o where lower(o.code) like lower('%xtd_%');
begin
  dbms_output.put_line('<QueryResult>');
  for my_rec in my_objects loop
    my_sql := 'select max(last_updated_date) from odf_ca_' || my_rec.code;
    execute immediate my_sql
      into my_date;
    if my_date is not null then
      dbms_output.put_line('<Record>');
      dbms_output.put_line('  <type>object_instance</type>');
      dbms_output.put_line('  <code>' || my_rec.code || '</code>');
      dbms_output.put_line('  <name>All instances of ' || my_rec.code || '</name>');
      dbms_output.put_line('  <last_updated_by>dummy</last_updated_by>');
      dbms_output.put_line('  <last_updated_date>' || to_char(my_date, my_format) || '</last_updated_date>');
      dbms_output.put_line('</Record>');
    end if;
  end loop;
  dbms_output.put_line('</QueryResult>');
end;
