/*
OBJECTIVE
  - Detect Resources : URI Application > Resource Management > Resources
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - srm_resources                 : Resource Table
  - prj_resources.prisrole = 0    : Exclude Roles
  - srm_resources.is_external = 1 : External only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'resource' as "type",
       r.unique_name as "code",
       r.full_name as "name",
       (select full_name from srm_resources where user_id = r.last_updated_by) as "last_updated_by",
       r.last_updated_date as "last_updated_date"
  from srm_resources r
 inner join prj_resources rp on rp.prid = r.id
 where rp.prisrole = 0 --Resource Only
   and r.is_external = 1 --External Only
 order by r.unique_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@