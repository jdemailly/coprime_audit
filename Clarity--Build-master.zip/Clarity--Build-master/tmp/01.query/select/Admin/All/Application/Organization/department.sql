/*
OBJECTIVE
  - Detect Departments : URI Application > Organization > Departments
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2014-11-25 : CoPrime (DMA) - Group by Entity
BUSINESS RULES
  - departments : Department Table
  - Department are Exported with Entity Code
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code")))).getclobval()
  from (:ORACLE@

--Select
select 'department' as "type",
       e.entity as "code"
  from entity e
 where exists (select 1 from departments d where d.entity_id = e.id)
 order by e.entity

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@