/*
OBJECTIVE
  - Detect Companies : URI Application > Financial Management > Companies
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - srm_companies              : Company Table
  - srm_companies.status = 419 : Only Active Companies
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'company' as "type",
       c.company_id as "code",
       c.company_name as "name",
       (select full_name from srm_resources where user_id = c.last_updated_by) as "last_updated_by",
       c.last_updated_date as "last_updated_date",
       c.company_name as "export"
  from srm_companies c
 where c.status = 419 --Active Only
 order by c.company_id

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@