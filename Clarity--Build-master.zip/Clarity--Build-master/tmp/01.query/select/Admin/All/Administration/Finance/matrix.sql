/*
OBJECTIVE
  - Detect Matrixes : URI Administration > Finance > Manage Matrix
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - ppa_matrix               : Matrix Table
  - ppa_matrix.matrixkey = 1 : Ignore System Matrix
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'matrix' as "type",
       m.description as "code",
       m.comments as "name",
       (select full_name from srm_resources where user_id = m.last_updated_by) as "last_updated_by",
       m.last_updated_date as "last_updated_date"
  from ppa_matrix m
 where not m.matrixkey = 1 --Ignore Standard Matrix
 order by m.description

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@