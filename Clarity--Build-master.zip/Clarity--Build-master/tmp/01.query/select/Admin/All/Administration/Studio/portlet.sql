/*
OBJECTIVE
  - Portlet : URI Administration > Studio > Portlets
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2014-08-25 : CoPrime (DMA) - Use Portlet Type
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2016-11-25 : CoPrime (DMA) - Grid
  - 2017-02-08 : CoPrime (DMA) - Caption
  - 2017-02-14 : CoPrime (DMA) - Aggregate Row
  - 2017-07-06 : CoPrime (DMA) - Filter Section
  - 2017-09-25 : CoPrime (DMA) - Principal Type
BUSINESS RULES
  - Installation Date is Calculated from cmn_install_history database and release_version Elements
  - cmn_portlets.portlet_type_code      : Portlet Type (graph, filter, grid, etc.)
  - cmn_portlets.is_system = 0          : Ignore System Portlets
  - cmn_portlets.principal_type <> USER : Ignore User Portlets
TESTED ON
  - Clarity 12.x, 13.x, 14.x, 15.x
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'portlet_' @+@ lower(p.portlet_type_code) as "type",
       p.portlet_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'CMN_PORTLETS'
           and n.language_code = pa.p_language) as "name",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from param        pa,
       cmn_portlets p
 where @NVL@(p.is_system, 0) = 0 --Ignore System
   and p.principal_type <> 'USER' --Ignore User Portlet
   and ( --Modified Since First Installation
        p.last_updated_date >= pa.p_date or
        --Grid Modified
        (select last_updated_date from cmn_grids where principal_type <> 'USER' and portlet_id = p.id) >= pa.p_date or
        --At Least One Column Modified
         (select max(c.last_updated_date)
            from cmn_grid_cols c
           inner join cmn_grids g on g.id = c.grid_id
           where g.portlet_id = p.id
             and g.principal_type <> 'USER') >= pa.p_date or
        --Caption Modified
         (select max(last_updated_date)
            from cmn_captions_nls
           where pk_id = p.id
             and table_name = 'CMN_PORTLETS') >= pa.p_date or
        --View Filter Modified
         (select max(v.last_updated_date)
            from odf_views v
           where v.view_type = 'filter'
             and v.object_code = @STRING:(p.id):STRING@
             and v.principal_type <> 'USER') >= pa.p_date or
        --View Section Modified
         (select max(s.last_updated_date)
            from odf_view_sections s
           inner join odf_views v on v.id = s.view_id
           where v.view_type = 'filter'
             and v.object_code = @STRING:(p.id):STRING@
             and v.principal_type <> 'USER') >= pa.p_date or
        --Attribute View Modified
         (select max(a.last_updated_date)
            from odf_view_attributes a
           inner join odf_views v on v.id = a.view_id
           where v.view_type = 'filter'
             and v.object_code = @STRING:(p.id):STRING@
             and v.principal_type <> 'USER') >= pa.p_date or
        --At Least One Aggregate Row Modified
         (select max(a.last_updated_date)
            from cmn_grid_col_aggs a
           inner join cmn_grid_cols c on c.id = a.col_id
           inner join cmn_grids g on g.id = c.grid_id
           where g.id = p.id
             and g.principal_type <> 'USER') >= pa.p_date
        )
 order by p.portlet_type_code,
          p.portlet_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@