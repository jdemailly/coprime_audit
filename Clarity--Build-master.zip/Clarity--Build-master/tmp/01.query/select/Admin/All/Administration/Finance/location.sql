/*
OBJECTIVE
  - Detect Locations : URI Administration > Finance > Setup [Locations]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2015-01-16 : CoPrime (DMA) - Only one Row
BUSINESS RULES
  - locations : Location Table
  - Locations are XOGged out from Entity
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name")))).getclobval()
  from (:ORACLE@

--Select
select 'location' as "type",
       e.entity as "code",
       'Locations from Entity' as "name"
  from entity e
 where exists (select 1 from locations l where l.entity_id = e.id)
 order by e.entity

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@
