/*
OBJECTIVE
  - Detect Charge Codes : URI Administration > Project Management > Charge Codes
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - prchargecode                            : Charge Code Table
  - prchargecode.prexternalid != 'MIGRATED' : Ignore MIGRATED Charge Code
  - prchargecode.prisopen = 1               : Active Charge Code Only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'charge_code' as "type",
       c.prexternalid as "code",
       c.prname as "name",
       (select full_name from srm_resources where user_id = c.prmodby) as "last_updated_by",
       c.prmodtime as "last_updated_date"
  from prchargecode c
 where c.prexternalid != 'MIGRATED' --Ignore Standard MIGRATED
   and c.prisopen = 1 --Open Only
 order by c.prexternalid

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@