/*
OBJECTIVE
  - Detect Skills : URI Administration > Data Administration > Skills Hierarchy
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2015-01-16 : CoPrime (DMA) - Only One Row
  - 2016-03-04 : CoPrime (DMA) - Active
BUSINESS RULES
  - rsm_skills               : Skill Table
  - rsm_skills.is_active = 1 : Active
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name")))).getclobval()
  from (:ORACLE@

--Select
select 'skill' as "type",
       'dummy' as "code",
       'All Skills' as "name"
  from dual
 where exists (select 1 from rsm_skills where is_active = 1)

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@
