/*
OBJECTIVE
  - Detect Vendors : URI Administration > Finance > Setup [Vendors]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - apmaster : Vendor Table
  - apmaster.status_type = 1 : Status Active only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'vendor' as "type",
       ve.vendor_code as "code",
       ve.address_name as "name",
       (select full_name from srm_resources where user_id = ve.last_updated_by) as "last_updated_by",
       ve.last_updated_date as "last_updated_date"
  from apmaster ve
 where ve.status_type = 1 --Active Only
 order by ve.vendor_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@