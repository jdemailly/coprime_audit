/*
OBJECTIVE
  - Detect Cost Plus Codes : URI Administration > Finance > Cost Plus Codes
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - costplus : Cost Plus Code Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'cost_plus' as "type",
       c.costpluscode as "code",
       c.shortdesc as "name",
       (select full_name from srm_resources where user_id = c.last_updated_by) as "last_updated_by",
       c.last_updated_date as "last_updated_date"
  from costplus c
 order by c.costpluscode

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@