/*
OBJECTIVE
  - Detect Resource Classes : URI Administration > Finance > Setup [Classifications]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - pac_fos_resource_class            : Resource Class Table
  - pac_fos_resource_class.active = 1 : Active Resource Classes only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'resource_class' as "type",
       rc.resource_class as "code",
       rc.description as "name",
       (select full_name from srm_resources where user_id = rc.last_updated_by) as "last_updated_by",
       rc.last_updated_date as "last_updated_date"
  from pac_fos_resource_class rc
 where rc.active = 1 --Active Only
 order by rc.resource_class

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@