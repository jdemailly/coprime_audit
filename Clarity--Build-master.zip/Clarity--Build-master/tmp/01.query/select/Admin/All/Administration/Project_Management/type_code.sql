/*
OBJECTIVE
  - Detect Charge Codes : URI Administration > Project Management > Input Type Codes
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - prtypecode                            : Input Type Code Table
  - prtypecode.prexternalid != 'MIGRATED' : Ignore MIGRATED Input Type Code
  - prtypecode.prisopen = -1              : Active Input Type Code (be aware, open is -1)
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'type_code' as "type",
       t.prexternalid as "code",
       t.prname as "name",
       (select r.full_name from srm_resources r where r.user_id = t.prmodby) as "last_updated_by",
       t.prmodtime as "last_updated_date"
  from prtypecode t
 where t.prexternalid != 'MIGRATED' --Ignore Standard MIGRATED
   and t.prisopen = -1 --Open Only
 order by t.prexternalid

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@