/*
OBJECTIVE
  - Detect Pages : URI Administration > Studio > Portlet Pages
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2014-08-25 : CoPrime (DMA) - Use Page Type
  - 2015-11-23 : CoPrime (DMA) - Remove Criteria on System Page Boolean
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
  - 2017-01-25 : CoPrime (DMA) - Page odf%Frame
  - 2017-03-21 : CoPrime (DMA) - SubPage Last Updated Date
  - 2017-04-04 : CoPrime (DMA) - Ignore User Page
  - 2017-07-06 : CoPrime (DMA) - SubPage
  - 2017-10-06 : CoPrime (DMA) - Review Customizable Condition
  - 2018-04-18 : CoPrime (DMA) - Odf Page
BUSINESS RULES
  - Installation Date is calculated from cmn_install_history database and release_version elements
  - cmn_pages.page_type_code                     : Page type (page, tabpage, etc.)
  - cmn_pages.page_type_code <> 'tab'            : Ignore tab pages (XOG only tabpage)
  - cmn_pages.page_type_code <> 'template'       : Ignore template pages
  - cmn_pages.page_type_code <> 'subtab'         : Ignore subtab pages
  - substr(lower(p.page_code), 1, 6) != 'system' : Ignore system pages
  - cmn_pages.page_code like 'odf%Frame'         : Page Linked to Object
  - not cmn_pages.principal_type = 'USER'        : Ignore User Page
  - cmn_pages.is_customizable = 1                : Customizable
STAND BY
  - cmn_pages.is_system = 0                      : Ignore system pages
TESTED ON
  - Oracle 11.2, 12.1
  - SQL Server 2008R2
  - Clarity 12.x, 13.x, 14.x, 15.x
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'page_' @+@ lower(p.page_type_code) as "type",
       p.page_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'CMN_PAGES'
           and n.language_code = pa.p_language) as "name",
       (select r.full_name from srm_resources r where r.user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from param pa,
       cmn_pages p
 where p.page_type_code not in ('tab', 'template', 'subtab') --Main Tab Only
   and @SUBSTR@(lower(p.page_code), 1, 6) != 'system' --Ignore System
   and not p.principal_type = 'USER' --Ignore User Page
   and (p.page_code not like 'odf%Frame' or
       (p.page_code like 'odf%Frame' and
       (p.last_updated_date > (p.created_date + 1 / 24) or
       (select max(last_updated_date) from cmn_pages where p.last_updated_by = pa.p_user and parent_page_id = p.id) >= pa.p_date))) --Exclude odf Pages Linked to Objects if not Updated after Creation
     and (p.is_customizable = 1 or exists (select 1
                                           from cmn_pages sp
                                          where sp.parent_page_id = p.id
                                            and sp.is_customizable = 1)) --Customizable or At Least one Sub Page Customizable
   and ( --Modified by User
        (p.last_updated_date >= pa.p_date and p.last_updated_by = pa.p_user) or
       --One SubPage Modified by User and Since Last Date
       (select max(last_updated_date)
          from cmn_pages
         where parent_page_id = p.id
           and p.last_updated_by = pa.p_user) >= pa.p_date or
       --One Portlet on SubPage Modified Since Last Date by User
       (select max(pp.last_updated_date)
          from cmn_pages p1
         inner join cmn_page_portlets pp on pp.page_id = p1.id
         where p1.parent_page_id = p.id
           and pp.last_updated_by = pa.p_user) >= pa.p_date
       )
 order by p.page_type_code,
          p.page_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@