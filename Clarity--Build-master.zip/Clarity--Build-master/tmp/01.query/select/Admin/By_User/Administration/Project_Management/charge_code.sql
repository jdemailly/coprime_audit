/*
OBJECTIVE
  - Detect Charge Codes : URI Administration > Project Management > Charge Codes
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - prchargecode : Charge Code Table
  - prchargecode.prexternalid != 'MIGRATED' : Ignore MIGRATED charge code
  - prchargecode.prisopen = 1 : Active charge code only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'charge_code' as "type",
       c.prexternalid as "code",
       c.prname as "name",
       (select full_name from srm_resources where user_id = c.prmodby) as "last_updated_by",
       c.prmodtime as "last_updated_date"
  from param p
 inner join prchargecode c on c.prmodby = p.p_user
 where c.prexternalid != 'MIGRATED' --Ignore Standard MIGRATED
   and c.prisopen = 1 --Open Only
 order by c.prexternalid

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@