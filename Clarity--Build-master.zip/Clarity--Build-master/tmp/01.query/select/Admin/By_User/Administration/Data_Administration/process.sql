/*
OBJECTIVE
  - Detect Processes : URI Administration > Data Administration > Processes
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - Installation Date is calculated from cmn_install_history database and release_version elements
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'process' as "type",
       p.process_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = p.id
           and n.table_name = 'BPM_DEF_PROCESSES'
           and n.language_code = pa.p_language) as "name",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from param             pa,
       bpm_def_processes p
 where ( --Modified by User
        (p.last_updated_date >= pa.p_date and p.last_updated_by = pa.p_user) or
       --At Least One Verson Modified by User
        (select max(v.last_updated_date)
           from bpm_def_process_versions v
          where v.process_id = p.id
            and v.last_updated_by = pa.p_user) >= pa.p_date or
       --At Least One Stage Modified by User
        (select max(stage.last_updated_date)
           from bpm_def_process_versions v
          inner join bpm_def_stages stage on stage.process_version_id = v.id
          where v.process_id = p.id
            and stage.last_updated_by = pa.p_user) >= pa.p_date or
       --At Least One Step Modified by User
        (select max(step.last_updated_date)
           from bpm_def_process_versions v
          inner join bpm_def_stages stage on stage.process_version_id = v.id
          inner join bpm_def_steps step on step.stage_id = stage.id
          where v.process_id = p.id
            and step.last_updated_by = pa.p_user) >= pa.p_date or
       --At Least One Action Modified by User
        (select max(stepaction.last_updated_date)
           from bpm_def_process_versions v
          inner join bpm_def_stages stage on stage.process_version_id = v.id
          inner join bpm_def_steps step on step.stage_id = stage.id
          inner join bpm_def_step_actions stepaction on stepaction.step_id = step.id
          where v.process_id = p.id
            and stepaction.last_updated_by = pa.p_user) >= pa.p_date or
       --At Least One Script Modified by User
        (select max(s.last_updated_date)
           from bpm_def_process_versions v
          inner join bpm_def_stages stage on stage.process_version_id = v.id
          inner join bpm_def_steps step on step.stage_id = stage.id
          inner join bpm_def_step_actions stepaction on stepaction.step_id = step.id
          inner join cmn_custom_scripts s on s.id = stepaction.script_id
          where v.process_id = p.id
            and s.last_updated_by = pa.p_user) >= pa.p_date)
 order by p.process_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@