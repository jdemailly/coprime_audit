/*
OBJECTIVE
  - Detect Vendors : URI Administration > Finance > Setup [Vendors]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - apmaster                 : Vendor Table
  - apmaster.status_type = 1 : Status Active only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'vendor' as "type",
       ve.vendor_code as "code",
       ve.address_name as "name",
       (select full_name from srm_resources where user_id = ve.last_updated_by) as "last_updated_by",
       ve.last_updated_date as "last_updated_date"
  from param p
 inner join apmaster ve on ve.last_updated_by = p.p_user
 where ve.status_type = 1 --Active Only
 order by ve.vendor_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@