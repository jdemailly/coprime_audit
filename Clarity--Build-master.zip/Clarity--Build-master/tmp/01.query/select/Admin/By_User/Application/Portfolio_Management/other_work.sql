/*
OBJECTIVE
  - Detect Other Works : URI Application > Portfolio Management > Other Work
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - inv_investments                           : Investment Table
  - inv_investments.odf_object_code = 'other' : Investment of type Other Work only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select @P_DATE@ as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'other_work' as "type",
       i.code as "code",
       i.name as "name",
       (select full_name from srm_resources where user_id = i.last_updated_by) as "last_updated_by",
       i.last_updated_date as "last_updated_date"
  from param p
 inner join inv_investments i on i.last_updated_by = p.p_user
 where i.odf_object_code = 'other'
 order by i.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@