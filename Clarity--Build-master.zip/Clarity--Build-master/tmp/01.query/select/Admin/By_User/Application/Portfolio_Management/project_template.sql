/*
OBJECTIVE
  - Detect Project Templates : URI Application > Portfolio Management > Projects
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - srm_projects : Project Table
  - srm_projects.is_program = 0 : Exclude Programs
  - srm_projects.is_template = 1 : Project Template only
  - inv_investments.odf_object_code = 'project' : Investment of type Project only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'project_template' as "type",
       p.unique_name as "code",
       p.name as "name",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from param pa
 inner join srm_projects p on p.last_updated_by = pa.p_user
 inner join inv_investments i on i.id = p.id
 where i.odf_object_code = 'project' --Project Only
   and p.is_program = 0 --Ignore Program
   and p.is_template = 1 --Template Only
 order by p.unique_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@