/*
OBJECTIVE
  - Detect Departments : URI Application > Organization > Departments
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2014-11-25 : CoPrime (DMA) - Group by Entity
  - 2016-03-03 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - departments : Department Table
  - Department are exported with entity code
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'department' as "type",
       e.entity as "code"
  from param  p,
       entity e
 where exists (select 1
          from departments d
         where d.entity_id = e.id
           and d.last_updated_by = p.p_user)

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@