/*
OBJECTIVE
  - Detect Resource Requisitions : URI Application > Resource Management > Resource Requisitions
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - rsm_req_requisitions : Resource Requisition Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'requisition' as "type",
       r.requisition_code as "code",
       r.name as "name",
       (select full_name from srm_resources where user_id = r.last_updated_by) as "last_updated_by",
       r.last_updated_date as "last_updated_date"
  from rsm_req_requisitions r
 order by "code"

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@