/*
OBJECTIVE
  - Detect Timesheets : URI Application > Personal > Timesheets
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - prtimesheet               : Timesheet Table
  - prtimeperiod.prisopen = 1 : Period Open Only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'timesheet' as "type",
       r.unique_name @+@ '.' @+@
       @ORACLE:to_char(p.prstart, 'YYYY-MM-DD'):ORACLE@
       @SQLSERVER:convert(varchar(10), p.prstart, 120):SQLSERVER@ as "code",
       r.full_name @+@ ' from ' @+@
       @ORACLE:to_char(p.prstart, 'YYYY-MM-DD'):ORACLE@
       @SQLSERVER:convert(varchar(10), p.prstart, 120):SQLSERVER@
       @+@ ' to ' @+@
       @ORACLE:to_char(p.prfinish, 'YYYY-MM-DD'):ORACLE@
       @SQLSERVER:convert(varchar(10), p.prfinish, 120):SQLSERVER@ as "name",
       (select full_name from srm_resources where user_id = s.prmodby) as "last_updated_by",
       s.prmodtime as "last_updated_date"
  from prtimesheet s
 inner join prtimeperiod p on p.prid = s.prtimeperiodid
 inner join srm_resources r on r.id = s.prresourceid
 where p.prisopen = 1 --Open Only
 order by r.unique_name,
          p.prstart desc

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@