/*
OBJECTIVE
  - Detect Planning Releases, URI : Application > Requirements Planning > Release Planning
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - rqp_release_plans : Releases Planning Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'release_plan' as "type",
       r.code as "code",
       r.name as "name",
       (select full_name from srm_resources where user_id = r.last_updated_by) as "last_updated_by",
       r.last_updated_date as "last_updated_date"
  from rqp_release_plans r
 order by r.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@