/*
OBJECTIVE
  - Detect Projects : Application > Portfolio Management > Projects
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - srm_projects                                : Project Table
  - inv_investments.odf_object_code = 'project' : Investment of type project only
  - srm_projects.is_program = 0                 : Ignore Programs
  - srm_projects.is_template = 0                : Ignore Project Template
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'project' as "type",
       p.unique_name as "code",
       p.name as "name",
       (select r.full_name from srm_resources r where r.user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from srm_projects p
 inner join inv_investments i on i.id = p.id
 where i.odf_object_code = 'project' --Project Only
   and p.is_program = 0 --Ignore Program
   and p.is_template = 0 --Ignore Template
 order by p.unique_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@