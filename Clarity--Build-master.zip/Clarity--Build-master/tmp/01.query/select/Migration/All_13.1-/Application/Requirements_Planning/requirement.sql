/*
OBJECTIVE
  - Detect Requirements : URI Application > Requirements Planning > Requirements
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - rqp_requirements : Requirement Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'requirement' as "type",
       r.code as "code",
       r.title as "name",
       (select full_name from srm_resources where user_id = r.last_updated_by) as "last_updated_by",
       r.last_updated_date as "last_updated_date"
  from rqp_requirements r
 order by r.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@