/*
OBJECTIVE
  - Detect Benefit Plans : URI Application > Portfolio Management [Benefit Plan]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - File Name Template               : <srm_projects.unique_name>.<fin_plans.code>
  - fin_plans                        : Financial Plan Table
  - fin_plans.plan_type_code is null : Benefit Plan only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'benefit_plan' as "type",
       p.unique_name @+@ '.' @+@ f.code as "code",
       f.name as "name",
       (select full_name from srm_resources r where r.user_id = f.last_updated_by) as "last_updated_by",
       f.last_updated_date as "last_updated_date"
  from fin_plans f
 inner join srm_projects p on p.id = f.object_id
 where f.plan_type_code is null
 order by "code"

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@