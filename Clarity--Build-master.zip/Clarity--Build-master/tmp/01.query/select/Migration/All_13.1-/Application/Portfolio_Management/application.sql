/*
OBJECTIVE
  - Detect Applications : URI Application > Portfolio Management > Applications
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - inv_investments                                 : Investment Table
  - inv_investments.odf_object_code = 'application' : Investment of type 'application' only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'application' as "type",
       i.code as "code",
       i.name as "name",
       (select full_name from srm_resources where user_id = i.last_updated_by) as "last_updated_by",
       i.last_updated_date as "last_updated_date"
  from inv_investments i
 where i.odf_object_code = 'application' --Application Only
 order by i.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@