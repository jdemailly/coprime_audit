/*
OBJECTIVE
  - Detect Change Requests : URI Application > Portfolio Management [Issue]
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-09-07 : CoPrime (DMA) - Index RIM_RISKS_AND_ISSUES_U1
BUSINESS RULES
  - rim_risks_and_issues                     : Risk, Change Request and Issue Table
  - rim_risks_and_issues.type_code = 'issue' : Issue only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'issue' as "type",
       r.rim_risk_issue_code as "code",
       r.name as "name",
       (select full_name from srm_resources where user_id = r.last_updated_by) as "last_updated_by",
       r.last_updated_date as "last_updated_date"
  from rim_risks_and_issues r
 inner join srm_projects p on p.id = r.pk_id
 where r.type_code = 'ISSUE' --Issue Only
 order by "code"

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@