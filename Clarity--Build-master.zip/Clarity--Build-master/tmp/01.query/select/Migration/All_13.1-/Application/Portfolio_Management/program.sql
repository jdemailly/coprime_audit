/*
OBJECTIVE
  - Detect Programs : URI Application > Portfolio Management > Programs
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - srm_projects                : Project / Program Table
  - srm_projects.is_program = 1 : Program Only
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'program' as "type",
       p.unique_name as "code",
       p.name as "name",
       (select r.full_name from srm_resources r where r.user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from srm_projects p
 where p.is_program = 1 --Program Only
 order by p.unique_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@