/*
OBJECTIVE
  - Detect Scenarios
  - URI :
    / Application > IT Service Management
    / Application > Portfolio Management
    / Application > Demand Management
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - cap_scenarios : Scenario Table
  - XOG out by cmn_sec_users.user_name
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'scenario' as "type",
       u.user_name as "code",
       s.name as "name",
       (select full_name from srm_resources where user_id = s.last_updated_by) as "last_updated_by",
       s.last_updated_date as "last_updated_date"
  from cap_scenarios s
 inner join cmn_sec_users u on u.id = s.user_id
 order by u.user_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@