/*
OBJECTIVE
  - Detect Transactions : URI Application > Financial Management > Transactions
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - ppa_wip             : Transaction Table
  - ppa_wip.status <> 2 : Ignore Adjusted WIP
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'transaction' as "type",
       t.project_code as "code",
       @ORACLE:to_char(t.transdate, 'YYYY-MM-DD'):ORACLE@
       @SQLSERVER:convert(varchar(10), t.transdate, 120):SQLSERVER@
       @+@ ' on Project ' @+@ t.project_code @+@ ' Task ' @+@
       (select @NVL@(prexternalid, prname) from prtask where prid = t.task_id) @+@ ' Resource ' @+@ t.resource_code @+@
       ' Amount ' @+@ t.quantity as "name",
       (select full_name from srm_resources where unique_name = t.lastupdtdby_resource_code) as "last_updated_by",
       t.lastupdatedate as "last_updated_date"
  from ppa_wip t
 where t.status <> 2 --Ignore Adjusted WIP
 order by t.project_code,
          t.transdate desc

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@