/*
OBJECTIVE
  - Detect Users : URI Administration > Organization and Access > Resources
HISTORY
  - 2011-01-01 : CoPrime (DMA) - Init
  - 2016-03-04 : CoPrime (DMA) - Use of With Feature
  - 2016-09-08 : CoPrime (DMA) - Index CMN_SEC_USERS_U2
BUSINESS RULES
  - cmn_sec_users : User Table
TESTED ON
  - Clarity 12.1, 13.x, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Parameters
with param as
 (select (select min(h.installed_date) from cmn_install_history h where h.install_id in ('database', 'release_version')) as p_date,
         (select id from cmn_sec_users where @UPPER@(user_name) = @UPPER@('@P_USER@')) as p_user,
         lower('@P_LANGUAGE@') as p_language
    from dual)

--Select
select 'user' as "type",
       u.user_name as "code",
       r.full_name as "name",
       (select full_name from srm_resources where user_id = u.last_updated_by) as "last_updated_by",
       u.last_updated_date as "last_updated_date"
  from param p
 inner join cmn_sec_users u on u.last_updated_date >= p.p_date
 inner join srm_resources r on r.user_id = u.id
 order by u.user_name

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@