/*
OBJECTIVE
  - Detect Chargebacks
  - URI :
    / Home > IT Service Management
    / Home > Portfolio Management
    / Home > Demand Management
HISTORY
  - 2017-11-21 : CoPrime (DMA) - Init
BUSINESS RULES
  - cbk_gl_allocation : GL Allocations
TESTED ON
  - Clarity 12.x, 13.x, 14.x, 15.x
  - Oracle 11.2, 12.1,
  - SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'glallocation' as "type",
       a.allocation_code as "code",
       a.allocation_code as "name",
       (select full_name from srm_resources r where r.user_id = a.last_updated_by) as "last_updated_by",
       a.last_updated_date as "last_updated_date"
  from cbk_gl_allocation a
 order by a.allocation_code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@