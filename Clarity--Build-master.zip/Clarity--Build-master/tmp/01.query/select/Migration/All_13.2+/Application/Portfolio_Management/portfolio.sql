/*
OBJECTIVE
  - Detect Portfolios : URI Application > Portfolio Management > Portfolios
HISTORY
  - 2014-01-01 : CoPrime (DMA) - Init
BUSINESS RULES
  - pfm_portfolios               : Portfolio Table
  - pfm_portfolios.is_active = 1 : Active portfolio only
TESTED ON
  - Clarity 13.2+, 14.x
  - Oracle 11.2, SQL Server 2008R2
*/
@ORACLE:
select xmlelement(name "QueryResult",
                  xmlagg(xmlelement(name "Record",
                                    xmlforest("type", "code", "name", "last_updated_by", "last_updated_date")))).getclobval()
  from (:ORACLE@

--Select
select 'portfolio' as "type",
       p.code as "code",
       p.name as "name",
       (select full_name from srm_resources where user_id = p.last_updated_by) as "last_updated_by",
       p.last_updated_date as "last_updated_date"
  from pfm_portfolios p
 where p.is_active = 1 --Active Only
 order by p.code

@ORACLE:):ORACLE@
@SQLSERVER:
 for xml path ('Record'),
     root ('QueryResult')
:SQLSERVER@