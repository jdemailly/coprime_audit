/*
OBJECTIVE
  - Select DBMS Objects and Table Columns
  - Compatible SQL Server and Oracle
  - Comparison to schema.xml to search for custom objects
HISTORY
  - 2014-08-13 : CoPrime (DMA) - Init
  - 2014-08-25 : CoPrime (DMA) - Ignore Indexes SYS
  - 2015-06-10 : CoPrime (DMA) - Map SQL Server Objects
  - 2015-07-24 : CoPrime (DMA) - BNP Cardiff
  - 2015-09-02 : CoPrime (DMA) - Oracle Package Type
  - 2017-09-21 : CoPrime (DMA) - Remove schema_id()
BUSINESS RULES
  - This result is compared with schema.xml (folder cfg/schema)
  - Oracle user_objects : Objects for current schema
  - Ignore Oracle Objects (CA compliant) :
    / Indexes ODF_CA_%, ODFSEC_%, ODF_SSL_%, ODF_SL_%, SYS_%
    / Lobs SYS_LOB%
    / Sequences ODF_CA_%
    / Views ODFSEC_%, ODF_%
    / Tables ODF_CA_%, ODF_SSL_%, ODF_SL_%
    / Types SYS_PLSQL_%
    / Function ODF_AUD_%
  - Oracle : Package Body Type is ignored, keep Package only
  - SQL Server sys.all_objects : All Objects
  - sys.all_objects.schema_id = schema_id() : Current Schema is given by standard function schema_id()
  - Ignore SQL Server Objects (CA compliant) :
    / Default constraints DF__%
    / Primary constraints ODF_CA_%, PK__%
    / Views ODFSEC_%, ODF_%
    / Tables ODF_CA_%
    / Functions ODF_AUD_%
  - Map SQL Server objects :
    / SQL_SCALAR_FUNCTION to FUNCTION
    / SQL_TABLE_VALUED_FUNCTION to FUNCTION
    / SQL_INLINE_TABLE_VALUED_FUNCTION to FUNCTION
    / SQL_TRIGGER to TRIGGER
    / SQL_STORED_PROCEDURE to PROCEDURE
    / USER_TABLE to TABLE
TESTED ON
  - Clarity v12.x, v13.x
  - Oracle 11.2, 12.1
  - SQL Server 2008R2, 2012
*/
@ORACLE:
select xmlelement(name "QueryResult", xmlagg(xmlelement("Record", xmlforest("type", "name", "code", "last_updated_date"))))
       .getclobval()
  from (select o.object_type as "type",
               o.object_name as "code",
               o.object_name as "name",
               to_char(o.created, 'yyyy-mm-dd') as "last_updated_date"
          from user_objects o
         where not (o.object_type = 'INDEX' and (o.object_name like 'ODF_CA_%' or o.object_name like 'ODFSEC_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%' or o.object_name like 'SYS_%'))
           and not (o.object_type = 'LOB' and o.object_name like 'SYS_LOB%')
           and not (o.object_type = 'SEQUENCE' and o.object_name like 'ODF_CA_%')
           and not (o.object_type = 'TABLE' and (o.object_name like 'ODF_CA_%' or o.object_name like 'ODF_SSL_%' or o.object_name like 'ODF_SL_%'))
           and not (o.object_type = 'TYPE' and o.object_name like 'SYS_PLSQL_%')
           and not (o.object_type = 'VIEW' and (o.object_name like 'ODFSEC_%' or o.object_name like 'ODF_%'))
           and not (o.object_type = 'FUNCTION' and o.object_name like 'ODF_AUD_%')
           and not (o.object_type = 'PACKAGE BODY')
         order by o.object_name)
:ORACLE@

@SQLSERVER:
select (select t.* from (
select case
      when o.type_desc = 'USER_TABLE' then 'TABLE'
      when o.type_desc = 'SQL_SCALAR_FUNCTION' then 'FUNCTION'
      when o.type_desc = 'SQL_TABLE_VALUED_FUNCTION' then 'FUNCTION'
      when o.type_desc = 'SQL_INLINE_TABLE_VALUED_FUNCTION' then 'FUNCTION'
      when o.type_desc = 'SQL_TRIGGER' then 'TRIGGER'
      when o.type_desc = 'SQL_STORED_PROCEDURE' then 'PROCEDURE'
      else o.type_desc
    end as "type",
    o.name as "name",
    o.name as "code",
    convert(varchar(10), o.create_date, 126)  as "last_updated_date"
  from sys.all_objects o
 where not (o.type_desc = 'DEFAULT_CONSTRAINT' and o.name like 'DF__%')
   and not (o.type_desc = 'PRIMARY_KEY_CONSTRAINT' and (o.name like 'ODF_CA_%' or o.name like 'PK__%'))
   and not (o.type_desc = 'VIEW' and (o.name like 'ODFSEC_%' or o.name like 'ODF_%'))
   and not (o.type_desc = 'USER_TABLE' and (o.name like 'ODF_CA_%' or o.name like 'ODF_SSL_%' or o.name like 'ODF_SL_%' or o.name like 'CMN_SEQ_%'))
   and not (o.type_desc = 'SQL_SCALAR_FUNCTION' and (o.name like 'ODF_AUD_%' or o.name like 'CMN_ID_CURRVAL_FCT_%'))
) t
for xml path ('Record'), type)
for xml path ('QueryResult')
:SQLSERVER@
