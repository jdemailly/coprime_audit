/*
OBJECTIVE
  - Get Calendars
  - URI Administration > Project Management > Base Calendars
HISTORY
  - 2014-02-20 : CoPrime (DMA) - Init
  - 2014-03-05 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
  - Use of function datepart and SET DATEFIRST 1 (monday) for SQL Server
*/
@ORACLE:
select xmlelement("calendars", xmlagg(xmlelement("calendar", xmlattributes(c.prname as "name"),
       --Aggregate working and non-working days
        (select xmlagg(xmlelement("day", xmlattributes(decode(s.slice, 0, 'false', 'true') as "work"), s.slice_date))
           from prj_resources         rp,
                prj_blb_slices        s,
                prj_blb_slicerequests r
          where r.id = s.slice_request_id
            and r.request_name = 'DAILYRESOURCEAVAILCURVE'
            and s.prj_object_id = rp.prid
            and rp.prid = 1
            and rp.prcalendarid = c.prid
            and ((to_char(s.slice_date, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') not in ('SAT', 'SUN') and s.slice = 0) or
                (to_char(s.slice_date, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') in ('SAT', 'SUN') and s.slice > 0))))))
       .getclobval()
  from prcalendar c
 where c.prresourceid is null
   and c.prmodtime >=
       (select min(h.installed_date) as "date" from cmn_install_history h where h.install_id = 'release_version')
 order by c.prname
:ORACLE@

@SQLSERVER:
SET DATEFIRST 1
select c.prname as "@name",
       --Aggregate working and non-working days
       (select case
                 when s.slice = 0 then
                  'false'
                 else
                  'true'
               end as "@work",
               s.slice_date as "text()"
          from prj_resources         rp,
               prj_blb_slices        s,
               prj_blb_slicerequests r
         where r.id = s.slice_request_id
           and r.request_name = 'DAILYRESOURCEAVAILCURVE'
           and s.prj_object_id = rp.prid
           and rp.prid = 1
           and rp.prcalendarid = c.prid
           and ((datepart(dw, s.slice_date) not in (6, 7) and s.slice = 0) or
               (datepart(dw, s.slice_date) in (6, 7) and s.slice > 0))
           for xml path('day'), type)
  from prcalendar c
 where c.prresourceid is null
   and c.prmodtime >=
       (select min(h.installed_date) as "date" from cmn_install_history h where h.install_id = 'release_version')
 order by c.prname
   for xml path('calendar'), root('calendars')
:SQLSERVER@