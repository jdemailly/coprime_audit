/*
OBJECTIVE
  - Get Risk Settings
  - URI Administration > Project Management > Risk Settings
HISTORY
  - 2014-02-20 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
*/
@ORACLE:
select xmlelement("risk_settings", xmlagg(xmlelement("risk_setting", xmlattributes("code", "name", "value"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"  as "@code",
       t."name"  as "@name",
       t."value" as "@value"
from (:SQLSERVER@
       
select op.option_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_OPTIONS'
           and n.pk_id = op.id) as "name",
       ov.value as "value"
  from cmn_options       op,
       cmn_option_values ov
 where ov.option_id = op.id
   and op.option_code in ('RIM_RISK_THRESHOLD')
   and not ((op.option_code = 'RIM_RISK_THRESHOLD' and ov.value = '0'))
union all
select 'RISK.IMPACT.' @+@ @STRING:m.y_code:STRING@ @+@ '.PROBABILITY.' @+@ @STRING:m.x_code:STRING@ as "code",
       'Impact : ' @+@ (select n.name
                         from cmn_lookups      l,
                              cmn_captions_nls n
                        where n.pk_id = l.id
                          and n.language_code = '@P_LANGUAGE@'
                          and n.table_name = 'CMN_LOOKUPS'
                          and l.lookup_type = 'RIM_IMPACT'
                          and l.lookup_enum = m.y_code) @+@ ' - Probability : ' @+@
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'RIM_PROBABILITY'
           and l.lookup_enum = m.x_code) as "name",
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'RCF_STANDARD_LMH'
           and l.lookup_enum = m.v_code) as "value"
  from itl_mappings m
 where m.type = 'risk'
   and not ((m.x_code = 1 and m.y_code = 1 and m.v_code = 0) or (m.x_code = 1 and m.y_code = 2 and m.v_code = 0) or
        (m.x_code = 1 and m.y_code = 3 and m.v_code = 50) or (m.x_code = 2 and m.y_code = 1 and m.v_code = 0) or
        (m.x_code = 2 and m.y_code = 2 and m.v_code = 50) or (m.x_code = 2 and m.y_code = 3 and m.v_code = 100) or
        (m.x_code = 3 and m.y_code = 1 and m.v_code = 50) or (m.x_code = 3 and m.y_code = 2 and m.v_code = 100) or
        (m.x_code = 3 and m.y_code = 3 and m.v_code = 100))
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('risk_setting'),
        root('risk_settings')
:SQLSERVER@
