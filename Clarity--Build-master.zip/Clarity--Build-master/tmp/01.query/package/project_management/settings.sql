/*
OBJECTIVE
  - Get Settings
  - URI : Administration > Project Management > Settings
HISTORY
  - 2014-02-19 : CoPrime (DMA) - Move to Configuration File
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - Use of functions xmlelement and xmlattributes to build XML for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
*/
@ORACLE:
select xmlelement("settings", xmlagg(xmlelement("setting",
                               xmlattributes("code" as "code", "name" as "name", nvl("value", 0) as "value")))) .getclobval()
from(:ORACLE@
@SQLSERVER:
select t."code"  as "@code",
       t."name"  as "@name",
       t."value" as "@value"
from (:SQLSERVER@

select op.option_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_OPTIONS'
           and n.pk_id = op.id) as "name",
       ov.value as "value"
  from cmn_options       op,
       cmn_option_values ov
 where ov.option_id = op.id
   and op.option_code in ('PRJ_CAP_FILTER_INIT_OBS_UNIT',
                          'PRJ_CAP_FILTER_INIT_OBS',
                          'SCH_EXPORT_CUR_BASELINE_ONLY',
                          'FIRST_MONTH_FISCAL_YEAR',
                          'OFFLINE_TIMESHEET_ENABLED',
                          'STAFF_TO_PARTICIPANTS_ENABLED',
                          'PRJ_DEFAULT_LOAD_PATTERN',
                          'OPPORTUNITY_ENABLED',
                          'PRJ_EFFORT_DISP_UNIT',
                          'PRJ_POST_FUTURE_TIMESHEETS',
                          'PRJ_CHG_ENABLE_PRJ_CHARGECODE',
                          'PRJ_DISABLE_EFFORTTASK_CREATE',
                          'PRJ_DISABLE_TASK_REASSIGN',
                          'PRJ_EDIT_ALLOC_WHEN_LOCKED',
                          'PRJ_FORCE_OTENTRY_WHEN_HDBKD',
                          'PRJ_SHOW_TASKS_WHEN_HDBKD',
                          'PRJ_ALLOW_MIXED_BOOK',
                          'PRJ_OVERRIDE_REQ_APPROVE',
                          'PRJ_REQ_BOOK_DECREMENT_VALUE',
                          'PRJ_RES_TO_ROLE_DEFAULT',
                          'RIM_NOTIFY_ON_DELETE')
   and not ((op.option_code = 'PRJ_CAP_FILTER_INIT_OBS_UNIT' and ov.value is null) or
        (op.option_code = 'PRJ_CAP_FILTER_INIT_OBS' and ov.value is null) or
        (op.option_code = 'SCH_EXPORT_CUR_BASELINE_ONLY' and ov.value is null) or
        (op.option_code = 'FIRST_MONTH_FISCAL_YEAR' and ov.value = '1') or
        (op.option_code = 'OFFLINE_TIMESHEET_ENABLED' and ov.value = 'false') or
        (op.option_code = 'STAFF_TO_PARTICIPANTS_ENABLED' and ov.value = 'true') or
        (op.option_code = 'PRJ_DEFAULT_LOAD_PATTERN' and ov.value = '3') or
        (op.option_code = 'OPPORTUNITY_ENABLED' and ov.value = '0') or
        (op.option_code = 'PRJ_EFFORT_DISP_UNIT' and ov.value = 'hours') or
        (op.option_code = 'PRJ_POST_FUTURE_TIMESHEETS' and @NVL@(ov.value, 0) = '1') or
        (op.option_code = 'PRJ_CHG_ENABLE_PRJ_CHARGECODE' and ov.value = '0') or
        (op.option_code = 'PRJ_DISABLE_EFFORTTASK_CREATE' and ov.value is null) or
        (op.option_code = 'PRJ_DISABLE_TASK_REASSIGN' and ov.value is null) or
        (op.option_code = 'PRJ_EDIT_ALLOC_WHEN_LOCKED' and ov.value is null) or
        (op.option_code = 'PRJ_FORCE_OTENTRY_WHEN_HDBKD' and ov.value = '0') or
        (op.option_code = 'PRJ_SHOW_TASKS_WHEN_HDBKD' and ov.value = '0') or
        (op.option_code = 'PRJ_ALLOW_MIXED_BOOK' and ov.value = '1') or
        (op.option_code = 'PRJ_OVERRIDE_REQ_APPROVE' and ov.value is null) or
        (op.option_code = 'PRJ_REQ_BOOK_DECREMENT_VALUE' and ov.value = '0') or
        (op.option_code = 'PRJ_RES_TO_ROLE_DEFAULT' and ov.value is null) or
        (op.option_code = 'RIM_NOTIFY_ON_DELETE' and ov.value is null))
union all
select 'prsite.prroundallocpct',
       'Round Allocations to Nearest %',
       @ORACLE:ltrim(to_char(round(s.prroundallocpct, 2), '0.00')):ORACLE@
       @SQLSERVER:cast(cast(s.prroundallocpct * 100 as numeric(10, 2)) as varchar(5)):SQLSERVER@
  from prsite s
 where not s.prroundallocpct = 0.25
union all
select 'prsite.prguidelines',
       'Guidelines URL',
       s.prguidelines
  from prsite s
 where not s.prguidelines is null
union all
select 'prsite.prweekstart',
       'First Day of Work Week',
       @STRING:s.prweekstart:STRING@
  from prsite s
 where not s.prweekstart = 1

@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('setting'),
        root('settings')
:SQLSERVER@
