/*
OBJECTIVE
  - Get Time Periods
  - URI Administration > Project Management > Time Reporting Periods
HISTORY
  - 2014-02-20 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
*/
@ORACLE:
select xmlelement("timeperiods", xmlagg(xmlelement("timeperiod", xmlattributes("start", "finish"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."start"  as "@start",
       t."finish"  as "@finish"
from (:SQLSERVER@

select p.prstart  as "start",
       p.prfinish as "finish"
  from prtimeperiod p
 where p.prisopen = 1
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('timeperiod'),
        root('timeperiods')
:SQLSERVER@