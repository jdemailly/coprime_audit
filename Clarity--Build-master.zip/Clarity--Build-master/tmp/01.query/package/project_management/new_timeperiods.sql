/*
OBJECTIVE
  - Get Time Periods since last extract
  - URI Administration > Project Management > Time Reporting Periods
HISTORY
  - 2014-02-24 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
  - Use of tag P_DATE
*/
@ORACLE:
select xmlelement("new_timeperiods", xmlagg(xmlelement("new_timeperiod", xmlattributes("start", "finish"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."start"  as "@start",
       t."finish"  as "@finish"
from (:SQLSERVER@

select p.prstart  as "start",
       p.prfinish as "finish"
  from prtimeperiod p
 where p.prisopen = 1
   and p.prmodtime >= @P_DATE@
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('new_timeperiod'),
        root('new_timeperiods')
:SQLSERVER@