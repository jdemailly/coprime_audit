/*
OBJECTIVE
  - Get Timesheet Options
  - URI Administration > Project Management > Timesheet Options
HISTORY
  - 2014-02-20 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - See difference with initial value
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
*/
@ORACLE:
select xmlelement("timesheet_options", xmlagg(xmlelement("timesheet_option", xmlattributes("code", "name", "value"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"  as "@code",
       t."name"  as "@name",
       t."value" as "@value"
from (:SQLSERVER@

select op.option_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_OPTIONS'
           and n.pk_id = op.id) as "name",
       ov.value as "value"
  from cmn_options       op,
		cmn_option_values ov
 where ov.option_id = op.id
   and op.option_code like 'NKT%'
   and ov.created_by = 1
   and not ((op.option_code = 'NKT.GEN.ENABLE_NOTE_DATE' and ov.value = 'false') or
		(op.option_code = 'NKT.GEN.LOOKUP_4_USER_VALUE1' and ov.value = 'PRTIMEENTRY_USER_LOV1') or
		(op.option_code = 'NKT.GEN.DISPLAY_HOURLY' and ov.value = 'true') or
		(op.option_code = 'NKT.TB.TA_RANGE_START' and ov.value = '7') or
		(op.option_code = 'NKT.GEN.DISABLE_INDIRECT' and ov.value = 'false') or
		(op.option_code = 'NKT.GEN.AUTOPOPULATE_VALUES' and ov.value = 'false') or
		(op.option_code = 'NKT.GEN.AUTOPOPULATE' and ov.value = 'false') or
		(op.option_code = 'NKT.Cust.PRECISION' and ov.value = '2') or
		(op.option_code = 'NKT.TB.TA_RANGE_FINISH' and ov.value = '7') or
		(op.option_code = 'NKT.GEN.DISABLE_NONASSIGN' and ov.value = 'false'))
union all
@ORACLE:
select 'prview prviewmember',
		'Defaut Content and Layout',
		(select listagg(m.prname, ', ') within group(order by m.prsequence)
		   from prviewmember m
		  where m.prviewid = v.prid
		  group by m.prviewid)
  from prview v
 where v.prname = 'Timesheet'
   and v.pruserid is null
   and not (select listagg(m.prname, ', ') within group(order by m.prsequence)
			  from prviewmember m
			 where m.prviewid = v.prid
			 group by m.prviewid) = 'notes, proj_name, task_name, typecode, chargecode, actuals, total, etc'
:ORACLE@
@SQLSERVER:
select 'prview prviewmember',
	   'Defaut Content and Layout',
	   (select m.prname + ', ' as "text()"
		  from prviewmember m
		 where m.prviewid = 5000002
		 order by m.prsequence
		   for xml path(''))
  from prview v
 where v.prname = 'Timesheet'
   and v.pruserid is null
   and not (select m.prname + ', ' as "text()"
			  from prviewmember m
			 where m.prviewid = 5000002
			 order by m.prsequence
			   for xml path('')) = 'notes, proj_name, task_name, typecode, chargecode, actuals, total, etc'
:SQLSERVER@ 
union all
select 'prviewmember.sort',
		'Default Sorting Column',
		'Description'
  from prviewmember m,
		prview       v
 where v.prname = 'Timesheet'
   and v.pruserid is null
   and m.prviewid = v.prid
   and m.prname = 'proj_name'
   and m.prsort = 1
union all
select 'prviewmember.sort',
		'Sorting Order',
		'Descending'
  from prviewmember m,
		prview       v
 where v.prname = 'Timesheet'
   and v.pruserid is null
   and m.prviewid = v.prid
   and m.prname in ('proj_name', 'task_name')
   and m.prsort = 3
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('timesheet_option'),
        root('timesheet_options')
:SQLSERVER@