/*
OBJECTIVE
  - Time Slices from Last Extract
  - URI : Administration > Data Administration > Time Slices
HISTORY
  - 2014-02-24 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
  - 2014-03-28 : CoPrime (DMA) - Template Condition
  - 2016-08-01 : CoPrime (DMA) - Index CMN_LOOKUPS_U1
BUSINESS RULES
  - prj_blb_slicerequests.field     : Lookup BLB_SLICE_ITEM
  - prj_blb_slicerequests.period    : Lookup BLB_SLICE_PERIOD
  - prj_blb_slicerequests.frequency : Lookup BLB_SLICE_PERIOD
  - prj_blb_slicerequests.is_template = 0 : Ignore template Slice Period
  - Use of functions xmlelement, xmlattributes and xmlagg to build XMLTYPE for Oracle
  - Use of function getclobval to convert XMLTYPE into text for Oracle
  - Use of tag P_DATE to catch last extract
*/
@ORACLE:
select xmlelement("new_time_slices", xmlagg(xmlelement("new_time_slice", xmlattributes("code", "item", "number_periods", "period", "rollover_interval", "from_date", "expiration_date"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"              as "@code",
       t."item"              as "@item",
       t."number_periods"    as "@number_periods",
       t."period"            as "@period",
       t."rollover_interval" as "@rollover_interval",
       t."from_date"         as "@from_date",
       t."expiration_date"   as "@expiration_date"
from (:SQLSERVER@

--Main
select sr.request_name as "code",
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'BLB_SLICE_ITEM'
           and l.lookup_enum = sr.field) as "item",
       sr.num_periods as "number_periods",
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'BLB_SLICE_PERIOD'
           and l.lookup_enum = sr.period) as "period",
       (select n.name
          from cmn_lookups      l,
               cmn_captions_nls n
         where n.pk_id = l.id
           and n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_LOOKUPS'
           and l.lookup_type = 'BLB_SLICE_PERIOD'
           and l.lookup_enum = sr.frequency) as "rollover_interval",
       sr.from_date as "from_date",
       sr.expiration_date as "expiration_date"
  from prj_blb_slicerequests sr
 where sr.is_template = 0
   and sr.last_updated_date >= @P_DATE@
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('new_time_slice'),
        root('new_time_slices')
:SQLSERVER@