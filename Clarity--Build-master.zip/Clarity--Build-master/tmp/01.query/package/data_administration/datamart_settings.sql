/*
OBJECTIVE
  - Get Datamart Settings
  - URI Administration > Data Administration > Datamart Settings)
HISTORY
  - 2014-02-19 : CoPrime (DMA) - Move to Configuration File
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - See difference with initial value
  - cmn_option_values.last_updated_date is not relevant
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
*/
@ORACLE:
select xmlelement("datamart_settings", xmlagg(xmlelement("datamart_setting", xmlattributes("code" as "code", "name" as "name", "value" as "value")))).getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"  as "@code",
       t."name"  as "@name",
	   t."value" as "@value"
from (:SQLSERVER@

select op.option_code as "code",
       case op.option_code
         when 'NBI_CURRENCY_CODE' then
          'Datamart Currency'
         when 'NBI_ENTITY_CODE' then
          'Datamart Entity'
         when 'NBI_EXTRACT_PM_PTFS' then
          'Extract project management time facts and summary'
         when 'NBI_EXTRACT_FM_PTFS' then
          'Extract financial management time facts and summary'
         when 'NBI_EXTRACT_RTFS' then
          'Extract resource time facts and summary'
       end as "name",
       ov.value as "value"
  from cmn_options       op,
       cmn_option_values ov
 where ov.option_id = op.id
   and op.option_code in
       ('NBI_CURRENCY_CODE', 'NBI_ENTITY_CODE', 'NBI_EXTRACT_PM_PTFS', 'NBI_EXTRACT_FM_PTFS', 'NBI_EXTRACT_RTFS')
   and not ((op.option_code = 'NBI_CURRENCY_CODE' and ov.value is null) or
        (op.option_code = 'NBI_ENTITY_CODE' and ov.value is null) or
        (op.option_code = 'NBI_EXTRACT_PM_PTFS' and ov.value = 1) or
        (op.option_code = 'NBI_EXTRACT_FM_PTFS' and ov.value = 1) or
        (op.option_code = 'NBI_EXTRACT_RTFS' and ov.value = 1))
union
select 'Project_OBS_Mapping_' @+@ c.obs_column_name as "code",
       'Project Organizational Breakdown Structure Mapping',
       (select 'OBS : ' @+@ t.unique_name @+@ ' - Default OBS Unit : ' @+@ u.unique_name
          from prj_obs_types t,
               prj_obs_units u
         where u.type_id = t.id
           and t.id = c.obs_type_id
           and u.id = c.obs_unit_default)
  from nbi_cfg_obs_assignments c
 where c.object_type = 'PROJECT'
   and not (c.obs_type_id is null)
union
select 'Resource_OBS_Mapping_' @+@ c.obs_column_name as "code",
       'Resource Organizational Breakdown Structure Mapping',
       (select 'OBS : ' @+@ t.unique_name @+@ ' - Default OBS Unit : ' @+@ u.unique_name
          from prj_obs_types t,
               prj_obs_units u
         where u.type_id = t.id
           and t.id = c.obs_type_id
           and u.id = c.obs_unit_default)
  from nbi_cfg_obs_assignments c
 where c.object_type = 'RESOURCE'
   and not (c.obs_type_id is null)
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('datamart_setting'),
        root('datamart_settings')
:SQLSERVER@