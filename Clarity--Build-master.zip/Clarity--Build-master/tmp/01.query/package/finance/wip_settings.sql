/*
OBJECTIVE
  - Get WIP settings
  - URI Administration > Finance > WIP Settings
HISTORY
  - 2014-02-20 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - See value difference with initial value
  - Use of functions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of function getclobval to convert into text for Oracle
*/
@ORACLE:
select xmlelement("wip_settings", xmlagg(xmlelement("wip_setting", xmlattributes("code", "name", "value"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"  as "@code",
       t."name"  as "@name",
	   t."value" as "@value"
from (:SQLSERVER@
      
select 'SOURCE.FIELD.1.ENTITY' as "code",
       'Source Fields - Entity' as "name",
       case n.sourcefieldentity
         when 'PE' then
          'Project Entity'
         when 'CE' then
          'Client Entity'
         when 'EE' then
          'Employee Entity'
       end as "value"
  from nameoptions n
 where not n.sourcefieldentity = 'PE'
union all
select 'SOURCE.FIELD.2.LOCATION' as "code",
       'Source Fields - Location' as "name",
       case n.sourcefieldlocation
         when 'PL' then
          'Project Location'
         when 'CL' then
          'Client Location'
         when 'EL' then
          'Employee Location'
       end as "value"
  from nameoptions n
 where not n.sourcefieldlocation = 'PL'
union all
select 'SOURCE.FIELD.3.DEPARTMENT' as "code",
       'Source Fields - Department' as "name",
       case n.sourcefielddepartment
         when 'PD' then
          'Project Department'
         when 'CD' then
          'Client Department'
         when 'ED' then
          'Employee Department'
       end as "value"
  from nameoptions n
 where not n.sourcefielddepartment = 'PD'
union all
select 'WIP.AGING.LEVELS.4.LEVEL1' as "code",
       'WIP Aging Levels in Days - Level 1' as "name",
       @STRING:n.agebracket1:STRING@
  from nameoptions n
 where not n.agebracket1 = 30
union all
select 'WIP.AGING.LEVELS.5.LEVEL2' as "code",
       'WIP Aging Levels in Days - Level 2' as "name",
       @STRING:n.agebracket2:STRING@
  from nameoptions n
 where not n.agebracket2 = 60
union all
select 'WIP.AGING.LEVELS.6.LEVEL3' as "code",
       'WIP Aging Levels in Days - Level 3' as "name",
       @STRING:n.agebracket3:STRING@
  from nameoptions n
 where not n.agebracket3 = 90
union all
select 'WIP.AGING.LEVELS.7.LEVEL4' as "code",
       'WIP Aging Levels in Days - Level 4' as "name",
       @STRING:n.agebracket4:STRING@
  from nameoptions n
 where not n.agebracket4 = 120
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('wip_setting'),
        root('wip_settings')
:SQLSERVER@