/*
OBJECTIVE
  - Get finance Investment Classes since last extract
  - URI : Administration > Finance > Setup [Classifications] > Investment Classes
HISTORY
  - 2014-02-24 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - See value difference with initial value
  - Use of funtions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of getclobval to convert XMLTYPE into text for Oracle
  -
*/
@ORACLE:
select xmlelement("new_investment_classes", xmlagg(xmlelement("new_investment_class", xmlattributes("code", "name", "description"))))
       .getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"        as "@code",
       t."name"        as "@name",
	   t."description" as "@description"
from (:SQLSERVER@
 
select ic.projclass   as "code",
	   ic.shortdesc   as "name",
	   ic.description as "description"
  from projclass ic
 where ic.last_updated_date >= @P_DATE@
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('new_investment_class'),
        root('new_investment_classes')
:SQLSERVER@