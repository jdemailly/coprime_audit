/*
OBJECTIVE
  - Processing Finance Options
  - URI : Administration > Finance > Processing
HISTORY
  - 2014-02-20 : CoPrime (DMA) - Init
  - 2014-03-03 : CoPrime (DMA) - SQL Server Compatibility
  - 2016-08-01 : CoPrime (DMA) - Index CMN_CAPTIONS_NLS_U1
BUSINESS RULES
  - See value difference with initial value
  - Use of funtions xmlelement and xmlattributes to build XMLTYPE for Oracle
  - Use of getclobval to convert XMLTYPE into text for Oracle
*/
@ORACLE:
select xmlelement("processings", xmlagg(xmlelement("processing", xmlattributes("code", "name", "value")))).getclobval()
  from (:ORACLE@
@SQLSERVER:
select t."code"  as "@code",
       t."name"  as "@name",
	   t."value" as "@value"
from (:SQLSERVER@

--Main
select op.option_code as "code",
       (select n.name
          from cmn_captions_nls n
         where n.language_code = '@P_LANGUAGE@'
           and n.table_name = 'CMN_OPTIONS'
           and n.pk_id = op.id) as "name",
       ov.value as "value"
  from cmn_options       op,
       cmn_option_values ov
 where ov.option_id = op.id
   and op.option_code in ('CMN_RETAIN_CURRENCY_PRECISION')
   and not ((op.option_code = 'CMN_RETAIN_CURRENCY_PRECISION' and ov.value = '1'))
union all
select 'ALLOWNONCHARGEABLEOVERRIDE' as "code",
       'Allow Chargeable Override' as "name",
       @STRING:o.allownonchargeableoverride:STRING@ as "value"
  from nameoptions o
 where not o.allownonchargeableoverride = 1
union all
select 'FILTER_FINANCIAL_OBS' as "code",
       'Hide Financial OBS' as "name",
       @STRING:o.filter_financial_obs:STRING@ as "value"
  from nameoptions o
 where not o.filter_financial_obs = 0
union all
select 'ENTITY_SECURITY' as "code",
       'Entity-based Security' as "name",
       case o.entity_security
         when 0 then
          'None'
         when 1 then
          'Strict'
         when 2 then
          'Parent'
       end as "value"
  from nameoptions o
 where not o.entity_security = 0
       
@ORACLE:):ORACLE@
@SQLSERVER:) t
for xml path('processing'),
        root('processings')
:SQLSERVER@
