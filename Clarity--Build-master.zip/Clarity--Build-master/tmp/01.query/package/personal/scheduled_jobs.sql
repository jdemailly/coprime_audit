/*
OBJECTIVE
  - Select Scheduled jobs (Application > Personal > Reports and Jobs)
HISTORY
  - 2014-02-19 : CoPrime (DMA) - Move to Configuration File
  - 2014-03-04 : CoPrime (DMA) - SQL Server Compatibility
BUSINESS RULES
  - Use of xmlelement, xmlattributes functions for Oracle
  - Use of function getclobval() to convert XMLTYPE into text for Oracle
  - Use of xml path keyword for SQL Server
TESTED ON
  - Oracle v11, SQL Server 2008, 2008R2
  - Clarity v13
*/
@ORACLE:
select xmlelement("scheduled_jobs",
       xmlagg(xmlelement("scheduled_job",
                               xmlattributes(j.name as "name", (select n.name
                                                           from cmn_captions_nls n
                                                          where n.pk_id = d.id
                                                            and n.table_name = 'CMN_SCH_JOB_DEFINITIONS'
                                                            and n.language_code = lower('@P_LANGUAGE@')) as "type_name",
                                                            to_char(j.start_date, 'DD/MM/YYYY') as "start_date",
                                                            j.minutes || ' ' || j.hours || ' ' || j.days_of_month || ' ' || j.months || ' ' ||
                                                        j.days_of_week as "crontab"),
                               xmlelement("notifications",
                                          (select xmlagg(xmlelement("notification",
                                                                    xmlattributes(nd.notification_key as "notification_key",
                                                                                  na.principal_type as "principal_type"),
                                                                    decode(lower(na.principal_type),
                                                                           'user',
                                                                           (select u.first_name || ', ' || u.last_name || ' (' ||
                                                                                   u.user_name || ')'
                                                                              from cmn_sec_users u
                                                                             where u.id = na.principal_id),
                                                                           'group',
                                                                           (select n.name || ' (' || g.group_code || ')'
                                                                              from cmn_sec_groups   g,
                                                                                   cmn_captions_nls n
                                                                             where n.pk_id = g.id
                                                                               and n.table_name = 'CMN_SEC_GROUPS'
                                                                               and n.language_code = lower('@P_LANGUAGE@')
                                                                               and g.id = na.principal_id))))
                                             from clb_notification_assocs na,
                                                  clb_notification_defs   nd
                                            where nd.id = na.notification_def_id
                                              and not lower(nd.notification_key) = 'scheduler_job_failed_no_msg'
                                              and na.instance_id = j.id)),
                               xmlelement("parameters",
                                          (select xmlagg(xmlelement("parameter",
                                                                    xmlattributes(n.name as "title",
                                                                                  decode(nvl(a.referenced_object_id, '__NULL__'),
                                                                                         '__NULL__',
                                                                                         '',
                                                                                         decode(a.referenced_object_id,
                                                                                                'PROCESS_INST_STATUS_4_DELETE',
                                                                                                (select nl.name
                                                                                                   from cmn_captions_nls nl,
                                                                                                        cmn_lookups      l
                                                                                                  where nl.pk_id = l.id
                                                                                                    and nl.table_name =
                                                                                                        'CMN_LOOKUPS'
                                                                                                    and nl.language_code = lower('@P_LANGUAGE@')
                                                                                                    and l.lookup_code =
                                                                                                        av.attribute_value
                                                                                                    and l.lookup_type =
                                                                                                        'BPM_PROCESS_INSTANCE_STATES'),
                                                                                                'BROWSE_NON_OBJECT_PROCESSES',
                                                                                                (select np.name
                                                                                                   from bpm_def_processes p,
                                                                                                        cmn_captions_nls  np
                                                                                                  where np.pk_id = p.id
                                                                                                    and np.table_name =
                                                                                                        'BPM_DEF_PROCESSES'
                                                                                                    and np.language_code = lower('@P_LANGUAGE@')
                                                                                                    and p.process_code =
                                                                                                        av.attribute_value))) as
                                                                                  "value_help",
                                                                                  av.attribute_value as "value",
                                                                                  a.referenced_object_id as "referenced_object_id",
                                                                                  va.display_order as "order")))
                                             from cmn_attribute_values     av,
                                                  cmn_attributes           a,
                                                  cmn_attribute_value_sets avs,
                                                  cmn_business_objects     bo,
                                                  cmn_object_views         v,
                                                  cmn_view_attributes      va,
                                                  cmn_captions_nls         n
                                            where a.id = av.attribute_id
                                              and avs.id = av.attribute_set_id
                                              and avs.business_object_instance_id = j.id
                                              and bo.id = avs.business_object_id
                                              and bo.table_name = 'CMN_SCH_JOB_DEFINITIONS'
                                              and bo.pk_id = d.id
                                              and v.object_id = bo.id
                                              and v.view_type = 'properties'
                                              and va.object_view_id = v.id
                                              and va.attribute_id = a.id
                                              and n.pk_id = va.id
                                              and n.table_name = 'CMN_VIEW_ATTRIBUTES'
                                              and n.language_code = lower('@P_LANGUAGE@')
                                              and av.attribute_value is not null))))) .getclobval()
			  from cmn_sch_jobs            j,
			       cmn_sch_job_definitions d
			 where d.id = j.job_definition_id
			   and j.status_code = 'SCHEDULED'
:ORACLE@

@SQLSERVER:
select j.name as "@name",
       (select n.name
          from cmn_captions_nls n
         where n.pk_id = d.id
           and n.table_name = 'CMN_SCH_JOB_DEFINITIONS'
           and n.language_code = lower('@P_LANGUAGE@')) as "@type_name",
       rtrim(convert(char, j.start_date, 103)) as "@start_date",
       j.minutes + ' ' + j.hours + ' ' + j.days_of_month + ' ' + j.months + ' ' + j.days_of_week as "@crontab",
       (select nd.notification_key as "@notification_key",
               na.principal_type as "@principal_type",
               case lower(na.principal_type)
                 when 'user' then
                  (select u.first_name + ', ' + u.last_name + ' (' + u.user_name + ')'
                     from cmn_sec_users u
                    where u.id = na.principal_id)
                 when 'group' then
                  (select n.name + ' (' + g.group_code + ')'
                     from cmn_sec_groups   g,
                          cmn_captions_nls n
                    where n.pk_id = g.id
                      and n.table_name = 'CMN_SEC_GROUPS'
                      and n.language_code = lower('@P_LANGUAGE@')
                      and g.id = na.principal_id)
               end
          from clb_notification_assocs na,
               clb_notification_defs   nd
         where nd.id = na.notification_def_id
           and not lower(nd.notification_key) = 'scheduler_job_failed_no_msg'
           and na.instance_id = j.id
           for xml path('notification'), root('notifications'), type),
       (select n.name as "@title",
               case
                 when isnull(a.referenced_object_id, '__NULL__') = '__NULL__' then
                  ''
                 when a.referenced_object_id = 'PROCESS_INST_STATUS_4_DELETE' then
                  (select nl.name
                     from cmn_captions_nls nl,
                          cmn_lookups      l
                    where nl.pk_id = l.id
                      and nl.table_name = 'CMN_LOOKUPS'
                      and nl.language_code = lower('@P_LANGUAGE@')
                      and l.lookup_code = av.attribute_value
                      and l.lookup_type = 'BPM_PROCESS_INSTANCE_STATES')
                 when a.referenced_object_id = 'BROWSE_NON_OBJECT_PROCESSES' then
                  (select np.name
                     from bpm_def_processes p,
                          cmn_captions_nls  np
                    where np.pk_id = p.id
                      and np.table_name = 'BPM_DEF_PROCESSES'
                      and np.language_code = lower('@P_LANGUAGE@')
                      and p.process_code = av.attribute_value)
               end as "@value_help",              
               av.attribute_value     as "@value",
               a.referenced_object_id as "@referenced_object_id",
               va.display_order       as "@order"
          from cmn_attribute_values     av,
               cmn_attributes           a,
               cmn_attribute_value_sets avs,
               cmn_business_objects     bo,
               cmn_object_views         v,
               cmn_view_attributes      va,
               cmn_captions_nls         n
         where a.id = av.attribute_id
           and avs.id = av.attribute_set_id
           and avs.business_object_instance_id = j.id
           and bo.id = avs.business_object_id
           and bo.table_name = 'CMN_SCH_JOB_DEFINITIONS'
           and bo.pk_id = d.id
           and v.object_id = bo.id
           and v.view_type = 'properties'
           and va.object_view_id = v.id
           and va.attribute_id = a.id
           and n.pk_id = va.id
           and n.table_name = 'CMN_VIEW_ATTRIBUTES'
           and n.language_code = lower('@P_LANGUAGE@')
           and av.attribute_value is not null
           for xml path('parameter'), root('parameter'), type)
  from cmn_sch_jobs            j,
       cmn_sch_job_definitions d
 where d.id = j.job_definition_id
   and j.status_code = 'SCHEDULED'
   for xml path('scheduled_job'), root('scheduled_jobs')
:SQLSERVER@