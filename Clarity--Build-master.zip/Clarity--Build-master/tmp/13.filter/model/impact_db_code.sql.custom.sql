<?xml version="1.0" encoding="UTF-8"?>
<QueryResult order="93"
             name="Oracle Source Code"
             description="Potential Impact on Oracle objects during migration"
             action="Analyze each Oracle Object and see if there is an impact during migration"
             th1="Name"
             th2="Type"
             th3="Line"
             th4="Code"
             th5="Script"/>
