<?xml version="1.0" encoding="UTF-8"?>
<QueryResult order="92"
             name="Oracle Custom Objects"
             description="Detect Custom Tables on current schema"
             action="Convert each table into an object Clarity"
             th1="Name"
             th2="Type"
             th3="Created"
             th4="Flag"/>
