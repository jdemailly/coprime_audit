<?xml version="1.0" encoding="UTF-8"?>
<QueryResult order="90"
             name="Oracle Custom Objects"
             description="Detect Custom Objects on current schema"
             action="Review each object and see if there is an impact or not before upgrade"
             th1="Name"
             th2="Type"
             th3="Created"
             th4="Script"/>
