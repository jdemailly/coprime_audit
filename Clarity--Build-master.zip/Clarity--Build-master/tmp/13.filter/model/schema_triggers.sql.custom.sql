<?xml version="1.0" encoding="UTF-8"?>
<QueryResult order="91"
             name="Oracle Custom Objects"
             description="Detect Custom Triggers on current schema"
             action="Disable each trigger before upgrading and reactivate them"
             th1="Name"
             th2="Type"
             th3="Trigger Type"
             th4="Object Type"
             th5="Table"
             th6="Status"
             th7="Created"
             th8="Flag"
             th9="Script"/>
