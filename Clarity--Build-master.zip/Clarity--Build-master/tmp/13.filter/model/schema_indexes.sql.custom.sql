<?xml version="1.0" encoding="UTF-8"?>
<QueryResult order="93"
             name="Oracle Custom Objects"
             description="Detect Custom Indexes on Current Schema"
             action="If the table is not custom, drop or disable index"
             th1="Name"
             th2="Type"
             th3="Table"
             th4="Index Type"
             th5="Status"
             th6="Created"
             th7="Flag"
             th8="Script"/>
