

          CoPrime Build 4 CA Clarity PPM


  What is it ?
  ------------
  
  This program is designed to help the administrator to :
  
  - Select XOG and SQL objects to extract
  - Extract XOG and SQL objects
  - Transform XOG files
  - Package XOG and SQL files in one executable distribution
  - Install XOG and SQL files
  - Audit a Clarity Database
  
  Languages used : ANT, PL/SQL, T-SQL, XSLT 1.0 (XALAN), XSLT 2.0 (SAXON), HTML, Javascript.


  How to ?
  --------
  
  --Set your workspace--
  
  First, create a new workspace in the folder wsp.
  
  Copy-paste an existing environment, use the __TEMPLATE__ folder if needed.
  Rename it with the name of your project (e.g. MY_WSP).
  
    Rename the copied folder __DEV__ with your development environment name
    (MY_DEV for instance) and fill the following properties in the xog.properties file :
    
    - servername=<Environment IP or Name>
    - portnumber=<Clarity APP Port>
    - sslenabled=<false if no https is used, true otherwise>
    - fipsenabled=false
    - username=<Clarity login with sufficient rights to XOG>
    - password=<Clarity login password>
  
    Do the same for your testing (__TEST__) and production (__PROD__) environments.
  
  Open the configuration file wsp/MY_WSP/ws.properties.
  
    Select the folder where the program will write the source code.
      On Windows platform, for instance :
      - folder.clarity.source=C:\\Source\\MY_WSP
      On Unix platform, for instance :
      - folder.clarity.source=/source/MY_WSP
      
    If no source folder is entered, the program will store files in ./src folder.

    Write your environments in the file :
      - folder.environment.source.relative=MY_DEV
      - folder.environment.target.relative=MY_TEST
  
  Open the configuration file build.properties.

    Select your new workspace in the build.properties file :
    - folder.workspace.relative=MY_WSP

  You are good to go !
  
  --Run the program--
  
  You can run the program with executable :
  - build.bat (on Windows platforms)
  - build.sh  (on Unix platforms)
  
  Type :
  - [1] to select Clarity and Database objects 
  - [2] to extract Clarity and Database objects
  - [3] to transform Clarity and Database objects
  - [4] to build a Package from Clarity source
  - [5] to install a Clarity environment
  - [6] to audit a Clarity environment
  
  Enter 'y' at the prompt.  
  Wait for the end of the program and see generated log/report.


  Features
  --------
  
  --[1] Select--
  
  Objective : select Clarity (XOG) and Database (SQL) objects.
  
  Configure file wsp/MY_WSP/ws.properties in your workspace :
  
  - select.only     : SQL Files pattern in cfg/sql/select folder :
    **/Admin/By_User_And_Date/**/*  to search by User and Date
    **/Admin/By_Date/**/*           to search by Date
    **/Admin/By_User/**/*           to search by User
    **/Admin/All/**/*               to search All
  - select.except   : XOG Files to exclude, comma separated (e.g. **/CSP_RPT*.xml)
  - select.date     : Date format yyyymmdd hh24:mi:ss
  - select.user     : User login (xtd_deploy by default)
  - select.language : User language code (en by default)
  
  Workflow :
  
    Operation               Source            Destination
  - Copy SQL files          01.query\select   10.input
  - Execute SQL files       10.input          11.output
  - Check SQL results       11.output         12.check
  - Filter SQL results      11.output         13.filter
  - Init XOG files          13.filter         14.trans
  - Select new XOG files    14.trans          15.sort

  TODO

  --[2] Extract--

  TODO
  
  --[3] Transform--

  TODO

  --[4] Package--

  TODO

  --[5] Install--

  TODO

  --[6] Audit--

  TODO

  
  File Organization
  -----------------
  
  --Folders--
  
  - cfg              : Configuration folder
  - cfg/html         : HTML content (for report and readme files)
  - cfg/schema       : Oracle and SQL Server objects for each version of Clarity
  - cfg/sql          : SQL templates
  - cfg/xsl          : XSLT files
  - lib              : Libraries
  - tmp              : Temporary folders
  - wsp              : Workspace
  - wsp/__TEMPLATE__ : Environment template
  
  --XSLT stylesheets--
  
  - html/content.xsl       : Content for report.html and readme.html
  - inc/functions.xsl      : Common functions
  - inc/header.xsl         : Common header
  - inc/parameters.xsl     : Common parameters
  - xog/check.xsl          : Check XOGOutput
  - xog/filter_result.xsl  : Filter XOG result
  - xog/filter.xsl         : Filter XOG result
  - xog/getter.xsl         : Read XOG object
  - xog/sort.xsl           : Sort XOG file
  - xog/split.xsl          : Split "big" XOG files
  - xog/transform.xsl      : Transform XOG files
  - sql/compare_schema.xsl : Compares Database schema with Clarity schema
  - sql/getter.xsl         : Read SQL object
  - audit.xsl              : Database audit report
  - readme.xsl             : Install readme
  - report.xsl             : HTML report after installation
  - select.xsl             : Select XOG and SQL files
  

  Debug
  -----
  
  See file wsp/MY_WSP/ws.properties, you can edit the following properties :
  
  - debug.log.level       : Log Debug Level verbose > debug > info > warn > error (by default, info)
  - debug.resume.on.error : If true, the program continues even if an error occurs
  - debug.skip.notepad    : If true, skip execution of Notepad++ (Windows only)
  - debug.skip.winmerge   : If true, skip execution of Winmerge (Windows only)
  - debug.sql.only        : SQL Files pattern to extract, comma separated (e.g. **/Tables/**/*)
  - debug.sql.except      : SQL Files pattern to exclude, comma separated (e.g. **/Tables/**/*)
  - debug.xog.only        : XOG Files pattern to extract, comma separated (e.g. **/Portlets/**/*)
  - debug.xog.except      : XOG Files pattern to exclude, comma separated (e.g. **/Portlets/**/*)

  You can copy-paste file cfg/directory.xml in your workspace folder wsp/MY_WSP.
  The program will use the properties in this file rather than the global file.


  Requirements
  ------------
  
  - Running operating system (Microsoft Windows XP/Vista/7, Unix, Linux, Red Hat)
  - At least free 100 Mb on hard drive
  - Running Clarity PPM environment v8, v12, v13
  - Access to the Database Oracle, SQL Server


  Compatibility
  -------------
  
  --Tested on--
  
  - Clarity PPM v8, v12, v13
  - Oracle v10, v11, v11R2
  - SQL Server 2005, 2008, 2008R2
  - Microsoft Windows XP Vista 7
  - CA Clarity PPM Client XOG v8, v12, v13
  - Java JRE 1.6.0_20, 1.7.0_25 for Unix, 1.7.0_25 for Windows
  - Apache Ant 1.8.2

  --Libraries--
  
  - Microsoft SQL Server JDBC Driver 3.0.1301.101
  - Oracle Client ojdbc6.jar
  - Ant Contrib 1.0b3
  - Ant XMLTask 1.16
  - SAXON 9 Home Edition
  
  
  Contact
  -------

  Please report any issue at email CentreServices@coprime.fr.

  Thanks for using this program, enjoy it.


          The CoPrime Team
        <http://www.coprime.fr>